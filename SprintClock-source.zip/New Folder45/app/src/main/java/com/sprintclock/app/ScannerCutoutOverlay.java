package com.sprintclock.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

/** Translucent dark scanner mask with a clean rounded-square cutout and white corner guides. */
public class ScannerCutoutOverlay extends View {
    private final Paint shade = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint clear = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glassRim = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint corners = new Paint(Paint.ANTI_ALIAS_FLAG);

    public ScannerCutoutOverlay(Context context) {
        super(context);
        init();
    }

    public ScannerCutoutOverlay(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public ScannerCutoutOverlay(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        shade.setColor(0xD9070B10);
        clear.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));

        glassRim.setColor(0x38FFFFFF);
        glassRim.setStyle(Paint.Style.STROKE);
        glassRim.setStrokeWidth(dp(1.2f));

        corners.setColor(Color.WHITE);
        corners.setStyle(Paint.Style.STROKE);
        corners.setStrokeWidth(dp(3.2f));
        corners.setStrokeCap(Paint.Cap.ROUND);
        corners.setStrokeJoin(Paint.Join.ROUND);
    }

    private float dp(float v) {
        return v * getResources().getDisplayMetrics().density;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float side = Math.min(getWidth() - dp(64), getHeight() * 0.42f);
        side = Math.min(side, dp(286));
        float l = (getWidth() - side) / 2f;
        float t = (getHeight() - side) / 2f;
        float r = l + side;
        float b = t + side;
        float radius = dp(24);
        float arm = dp(30);

        canvas.drawRect(0, 0, getWidth(), getHeight(), shade);
        canvas.drawRoundRect(l, t, r, b, radius, radius, clear);
        canvas.drawRoundRect(l, t, r, b, radius, radius, glassRim);

        // Four separate L-shaped corner guides; no horizontal center line.
        Path path = new Path();
        path.moveTo(l, t + arm);
        path.lineTo(l, t + radius);
        path.quadTo(l, t, l + radius, t);
        path.lineTo(l + arm, t);

        path.moveTo(r - arm, t);
        path.lineTo(r - radius, t);
        path.quadTo(r, t, r, t + radius);
        path.lineTo(r, t + arm);

        path.moveTo(r, b - arm);
        path.lineTo(r, b - radius);
        path.quadTo(r, b, r - radius, b);
        path.lineTo(r - arm, b);

        path.moveTo(l + arm, b);
        path.lineTo(l + radius, b);
        path.quadTo(l, b, l, b - radius);
        path.lineTo(l, b - arm);

        canvas.drawPath(path, corners);
    }
}
