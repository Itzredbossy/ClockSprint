package com.sprintclock.app;

import android.Manifest;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.media.AudioAttributes;
import android.media.MediaMetadataRetriever;
import android.media.SoundPool;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Range;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Space;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.camera2.interop.Camera2Interop;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.video.FallbackStrategy;
import androidx.camera.video.FileOutputOptions;
import androidx.camera.video.PendingRecording;
import androidx.camera.video.Quality;
import androidx.camera.video.QualitySelector;
import androidx.camera.video.Recorder;
import androidx.camera.video.Recording;
import androidx.camera.video.VideoCapture;
import androidx.camera.video.VideoRecordEvent;
import androidx.camera.view.PreviewView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.common.util.concurrent.ListenableFuture;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.common.BitMatrix;
import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanOptions;

import java.io.File;
import java.util.Arrays;
import java.util.Collections;
import java.util.EnumMap;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import eightbitlab.com.blurview.BlurView;

/**
 * SprintClock - offline two-phone sprint timer with frosted dark/white glassmorphism,
 * 3-second pre/post trigger capture buffer, manual photo-finish scrubbing, and QR sync.
 */
public class MainActivity extends AppCompatActivity {
    private static final int REQUEST_CAMERA = 740;
    private static final long PRE_POST_WINDOW_MS = 3000L;

    private static final int BG_VOID = Color.rgb(6, 9, 14);
    private static final int MINT = Color.rgb(122, 242, 198);
    private static final int ICE_WHITE = Color.rgb(244, 248, 255);
    private static final int MUTED = Color.rgb(162, 177, 194);

    private enum Role { NONE, START, STOP }
    private Role role = Role.NONE;

    private FrameLayout root;
    private FrameLayout screenHost;
    private int screenTransitionToken = 0;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private SoundPool soundPool;
    private ActivityResultLauncher<ScanOptions> scanLauncher;
    private String pendingScanPrompt = null;
    private int bangSoundId;
    private CameraManager cameraManager;
    private String cameraId;

    // START phone timing data
    private long startWallMs;
    private long startElapsedNanos;
    private String runId = "";
    private boolean startTriggered = false;

    // STOP phone calibration and imported run data
    private String syncNonce = "";
    private long syncStopT1 = 0L;
    private long clockOffsetStartMinusStopMs = 0L;
    private long syncUncertaintyMs = -1L;
    private boolean clockCalibrated = false;
    private long importedStartWallMs = -1L;
    private String importedRunId = "";

    // Camera & 3s pre/post rolling capture state
    private PreviewView previewView;
    private ProcessCameraProvider cameraProvider;
    private VideoCapture<Recorder> videoCapture;
    private Recording activeRecording;
    private File currentVideoFile;
    private long videoStartWallMs = 0L;
    private long videoStartElapsedNs = 0L;
    private long triggerOffsetMs = -1L;
    private long reviewWindowStartMs = 0L;
    private long reviewWindowEndMs = 0L;
    private boolean postTriggerCountdownActive = false;
    private boolean recordingFinished = false;
    private long videoDurationMs = 0L;
    private float frameRate = 30f;
    private int frameIndex = 0;
    private int frameCount = 1;
    private MediaMetadataRetriever retriever;
    private final ExecutorService frameExecutor = Executors.newSingleThreadExecutor();
    private ImageView reviewImage;
    private TextView reviewTimestamp;
    private TextView reviewRelativeBadge;
    private SeekBar reviewSeek;
    private boolean ignoreSeekCallback = false;

    private final Runnable timerTicker = new Runnable() {
        @Override
        public void run() {
            if (role == Role.START && startTriggered) {
                long elapsed = SystemClock.elapsedRealtimeNanos() - startElapsedNanos;
                TextView timer = findViewById(0x531001);
                if (timer != null) timer.setText(formatDurationNanos(elapsed));
                handler.postDelayed(this, 12L);
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        scanLauncher = registerForActivityResult(new ScanContract(), result -> {
            if (result != null && result.getContents() != null) {
                handleQrPayload(result.getContents());
            } else {
                Toast.makeText(this, "QR scan cancelled.", Toast.LENGTH_SHORT).show();
            }
        });

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setNavigationBarColor(BG_VOID);
        getWindow().setStatusBarColor(BG_VOID);

        loadCalibration();
        cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        try {
            if (cameraManager != null) {
                for (String id : cameraManager.getCameraIdList()) {
                    CameraCharacteristics c = cameraManager.getCameraCharacteristics(id);
                    Integer facing = c.get(CameraCharacteristics.LENS_FACING);
                    if (facing != null && facing == CameraCharacteristics.LENS_FACING_BACK) {
                        cameraId = id;
                        break;
                    }
                }
            }
        } catch (Exception ignored) { }

        AudioAttributes attrs = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
        soundPool = new SoundPool.Builder().setMaxStreams(2).setAudioAttributes(attrs).build();
        bangSoundId = soundPool.load(this, R.raw.bang, 1);

        // Root holds an ambient luminous dark mesh so BlurView refracts real depth & highlights.
        root = new FrameLayout(this);
        root.setBackgroundColor(BG_VOID);
        root.addView(new AmbientGlassBackdrop(this), new FrameLayout.LayoutParams(-1, -1));

        screenHost = new FrameLayout(this);
        root.addView(screenHost, new FrameLayout.LayoutParams(-1, -1));

        setContentView(root);
        showRolePicker();
    }

    // ---------------------------------------------------------------------
    // Navigation & Glassmorphism UI Kit
    // ---------------------------------------------------------------------

    private void setScreen(View view) {
        final int token = ++screenTransitionToken;
        View previous = screenHost.getChildCount() == 0 ? null : screenHost.getChildAt(screenHost.getChildCount() - 1);
        Runnable install = () -> {
            if (token != screenTransitionToken) return;
            screenHost.removeAllViews();
            screenHost.addView(view, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            animateIn(view);
        };
        if (previous == null) {
            install.run();
        } else {
            previous.animate().cancel();
            previous.animate().alpha(0f).translationY(-dp(8)).scaleX(0.99f).scaleY(0.99f)
                    .setDuration(110).setInterpolator(new DecelerateInterpolator())
                    .withEndAction(install).start();
        }
    }

    private void animateIn(View view) {
        view.setAlpha(0f);
        view.setTranslationY(dp(16));
        view.setScaleX(0.985f);
        view.setScaleY(0.985f);
        AnimatorSet set = new AnimatorSet();
        set.playTogether(
                ObjectAnimator.ofFloat(view, View.ALPHA, 0f, 1f),
                ObjectAnimator.ofFloat(view, View.TRANSLATION_Y, dp(16), 0f),
                ObjectAnimator.ofFloat(view, View.SCALE_X, 0.985f, 1f),
                ObjectAnimator.ofFloat(view, View.SCALE_Y, 0.985f, 1f));
        set.setDuration(300);
        set.setInterpolator(new DecelerateInterpolator());
        set.start();
    }

    private LinearLayout page() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setGravity(Gravity.CENTER_HORIZONTAL);
        page.setPadding(dp(22), dp(26), dp(22), dp(22));
        return page;
    }

    private ScrollView wrapScroll(LinearLayout content) {
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.setVerticalScrollBarEnabled(false);
        sv.addView(content, new FrameLayout.LayoutParams(-1, -2));
        return sv;
    }

    private TextView label(String value, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        t.setIncludeFontPadding(false);
        t.setTypeface(Typeface.create("sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL));
        return t;
    }

    private GradientDrawable rounded(int[] colors, int radiusDp, int strokeColor, int strokeDp) {
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR, colors);
        bg.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) bg.setStroke(dp(strokeDp), strokeColor);
        return bg;
    }

    private GradientDrawable ovalBackground(int[] colors, int strokeColor, int strokeDp) {
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR, colors);
        bg.setShape(GradientDrawable.OVAL);
        if (strokeDp > 0) bg.setStroke(dp(strokeDp), strokeColor);
        return bg;
    }

    /**
     * Frosted Glass Card container with real hardware BlurView + specular white rim.
     */
    private FrameLayout glassCard(int radiusDp, boolean lightFrost) {
        FrameLayout shell = new FrameLayout(this);
        shell.setBackground(rounded(
                lightFrost
                        ? new int[]{0x38FFFFFF, 0x1AFFFFFF}
                        : new int[]{0x421E293B, 0x260F172A},
                radiusDp,
                lightFrost ? 0x80FFFFFF : 0x45FFFFFF,
                1));
        shell.setClipToOutline(true);
        shell.setOutlineProvider(ViewOutlineProvider.BACKGROUND);
        shell.setElevation(dp(8));

        BlurView blur = new BlurView(this);
        blur.setupWith(root)
                .setFrameClearDrawable(root.getBackground())
                .setBlurRadius(24f)
                .setBlurEnabled(true)
                .setOverlayColor(lightFrost ? 0x24FFFFFF : 0x380B111A);
        shell.addView(blur, new FrameLayout.LayoutParams(-1, -1));
        return shell;
    }

    /**
     * Frosted glass action button: primary uses bright ice-white/mint frosted glass;
     * secondary uses smoked dark glass with a crisp white hairline border.
     */
    private View glassButton(String text, boolean primary, Runnable action) {
        FrameLayout shell = new FrameLayout(this);
        shell.setBackground(rounded(
                primary
                        ? new int[]{0xE6F6FAFF, 0xCCB8F5DF}
                        : new int[]{0x38273446, 0x22141C27},
                20,
                primary ? 0xFFFFFFFF : 0x55FFFFFF,
                1));
        shell.setClipToOutline(true);
        shell.setOutlineProvider(ViewOutlineProvider.BACKGROUND);
        shell.setElevation(dp(primary ? 10 : 4));

        BlurView blur = new BlurView(this);
        blur.setupWith(root)
                .setFrameClearDrawable(root.getBackground())
                .setBlurRadius(20f)
                .setBlurEnabled(true)
                .setOverlayColor(primary ? 0x20FFFFFF : 0x330C121B);
        shell.addView(blur, new FrameLayout.LayoutParams(-1, -1));

        TextView b = label(text, 14, primary ? Color.rgb(8, 18, 24) : ICE_WHITE, true);
        b.setLetterSpacing(0.06f);
        b.setPadding(dp(18), dp(15), dp(18), dp(15));
        shell.addView(b, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));

        shell.setOnClickListener(v -> {
            v.animate().scaleX(0.97f).scaleY(0.97f).setDuration(75)
                    .withEndAction(() -> v.animate().scaleX(1f).scaleY(1f).setDuration(110).start()).start();
            action.run();
        });
        return shell;
    }

    private View glassTriggerOrb(String caption, boolean dangerRed, Runnable action) {
        FrameLayout shell = new FrameLayout(this);
        shell.setBackground(ovalBackground(
                dangerRed
                        ? new int[]{0x66FF5A6E, 0x33B91C1C}
                        : new int[]{0x557AF2C6, 0x2A2563EB},
                dangerRed ? 0xCCFF9AA6 : 0xCCFFFFFF,
                2));
        shell.setClipToOutline(true);
        shell.setOutlineProvider(ViewOutlineProvider.BACKGROUND);
        shell.setElevation(dp(14));

        BlurView blur = new BlurView(this);
        blur.setupWith(root)
                .setFrameClearDrawable(root.getBackground())
                .setBlurRadius(24f)
                .setBlurEnabled(true)
                .setOverlayColor(dangerRed ? 0x33450A0A : 0x26102A27);
        shell.addView(blur, new FrameLayout.LayoutParams(-1, -1));

        if (caption == null || caption.isEmpty()) {
            View tick = new View(this) {
                private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
                @Override
                protected void onDraw(Canvas c) {
                    super.onDraw(c);
                    p.setColor(ICE_WHITE);
                    p.setStrokeWidth(dp(3.4f));
                    p.setStrokeCap(Paint.Cap.ROUND);
                    p.setStrokeJoin(Paint.Join.ROUND);
                    p.setStyle(Paint.Style.STROKE);
                    float cx = getWidth() / 2f, cy = getHeight() / 2f;
                    c.drawLine(cx - dp(11), cy, cx - dp(3), cy + dp(8), p);
                    c.drawLine(cx - dp(3), cy + dp(8), cx + dp(13), cy - dp(10), p);
                }
            };
            shell.addView(tick, new FrameLayout.LayoutParams(-1, -1));
        } else {
            TextView lbl = label(caption, 14, ICE_WHITE, true);
            lbl.setLetterSpacing(0.12f);
            shell.addView(lbl, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));
        }

        shell.setOnClickListener(v -> {
            v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(80)
                    .withEndAction(() -> {
                        v.animate().scaleX(1f).scaleY(1f).setDuration(140).start();
                        action.run();
                    }).start();
        });
        return shell;
    }

    private void addSpace(LinearLayout parent, int heightDp) {
        Space s = new Space(this);
        parent.addView(s, new LinearLayout.LayoutParams(1, dp(heightDp)));
    }

    private void addHeader(LinearLayout page, String title, String subtitle) {
        FrameLayout pill = glassCard(99, true);
        TextView top = label("SPRINTCLOCK", 11, ICE_WHITE, true);
        top.setLetterSpacing(0.22f);
        top.setPadding(dp(16), dp(6), dp(16), dp(6));
        pill.addView(top, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));
        page.addView(pill, new LinearLayout.LayoutParams(-2, -2));

        addSpace(page, 14);
        page.addView(label(title, 26, Color.WHITE, true), new LinearLayout.LayoutParams(-1, -2));
        if (subtitle != null && !subtitle.isEmpty()) {
            addSpace(page, 6);
            TextView sub = label(subtitle, 13, MUTED, false);
            sub.setLineSpacing(dp(3), 1f);
            page.addView(sub, new LinearLayout.LayoutParams(-1, -2));
        }
    }

    // ---------------------------------------------------------------------
    // 1. Role Selection Screen
    // ---------------------------------------------------------------------

    private void showRolePicker() {
        role = Role.NONE;
        LinearLayout p = page();
        p.setGravity(Gravity.CENTER);
        addHeader(p, "SELECT DEVICE ROLE", "Two-phone photo-finish & acoustic starter system.");
        addSpace(p, 28);

        p.addView(glassRoleCard(
                "START PHONE",
                "Starter pistol flash + sound with random delay & true local timestamp",
                true,
                () -> { role = Role.START; showStartHome(); }),
                new LinearLayout.LayoutParams(-1, -2));

        addSpace(p, 16);

        p.addView(glassRoleCard(
                "STOP PHONE",
                "3s pre/post rolling finish camera, chest-to-line scrubber & QR sync",
                false,
                () -> { role = Role.STOP; showStopHome(); }),
                new LinearLayout.LayoutParams(-1, -2));

        setScreen(wrapScroll(p));
    }

    private View glassRoleCard(String title, String subtitle, boolean accentWhite, Runnable action) {
        FrameLayout card = glassCard(26, accentWhite);
        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setPadding(dp(24), dp(24), dp(24), dp(24));

        TextView badge = label(accentWhite ? "STARTER GATE" : "FINISH LINE CAMERA", 10,
                accentWhite ? MINT : ICE_WHITE, true);
        badge.setLetterSpacing(0.18f);
        badge.setGravity(Gravity.START);
        inner.addView(badge, new LinearLayout.LayoutParams(-1, -2));

        addSpace(inner, 8);
        TextView t = label(title, 22, Color.WHITE, true);
        t.setGravity(Gravity.START);
        inner.addView(t, new LinearLayout.LayoutParams(-1, -2));

        addSpace(inner, 6);
        TextView sub = label(subtitle, 13, MUTED, false);
        sub.setGravity(Gravity.START);
        sub.setLineSpacing(dp(3), 1f);
        inner.addView(sub, new LinearLayout.LayoutParams(-1, -2));

        card.addView(inner, new FrameLayout.LayoutParams(-1, -2));
        card.setOnClickListener(v -> v.animate().scaleX(0.98f).scaleY(0.98f).alpha(0.85f).setDuration(85)
                .withEndAction(() -> {
                    v.setAlpha(1f);
                    v.setScaleX(1f);
                    v.setScaleY(1f);
                    action.run();
                }).start());
        return card;
    }

    // ---------------------------------------------------------------------
    // 2. START PHONE Screens
    // ---------------------------------------------------------------------

    private void showStartHome() {
        startTriggered = false;
        LinearLayout p = page();
        addHeader(p, "START PHONE", "Emits flash + starter bang and locks local true time.");
        addSpace(p, 26);

        FrameLayout hero = glassCard(28, false);
        LinearLayout heroInner = new LinearLayout(this);
        heroInner.setOrientation(LinearLayout.VERTICAL);
        heroInner.setGravity(Gravity.CENTER);
        heroInner.setPadding(dp(24), dp(32), dp(24), dp(32));

        TextView ready = label("READY", 13, MINT, true);
        ready.setLetterSpacing(0.22f);
        heroInner.addView(ready, new LinearLayout.LayoutParams(-1, -2));
        addSpace(heroInner, 10);
        heroInner.addView(label("00:00.000", 40, ICE_WHITE, true), new LinearLayout.LayoutParams(-1, -2));
        addSpace(heroInner, 8);
        heroInner.addView(label("Random 0–6s hold after SET", 12, MUTED, false), new LinearLayout.LayoutParams(-1, -2));

        hero.addView(heroInner, new FrameLayout.LayoutParams(-1, -2));
        p.addView(hero, new LinearLayout.LayoutParams(-1, -2));

        addSpace(p, 26);
        p.addView(glassButton("START TIMING", true, this::beginStartSequence),
                new LinearLayout.LayoutParams(-1, dp(58)));
        addSpace(p, 14);
        p.addView(glassButton("SYNC WITH STOP PHONE", false, () -> launchScanner("Scan the STOP phone's sync QR")),
                new LinearLayout.LayoutParams(-1, dp(54)));
        addSpace(p, 18);

        TextView back = label("CHANGE PHONE ROLE", 11, MUTED, true);
        back.setLetterSpacing(0.12f);
        back.setPadding(0, dp(12), 0, dp(12));
        back.setOnClickListener(v -> showRolePicker());
        p.addView(back, new LinearLayout.LayoutParams(-1, -2));
        setScreen(wrapScroll(p));
    }

    private void beginStartSequence() {
        if (!hasCameraPermission()) {
            requestCameraPermission();
            Toast.makeText(this, "Camera permission is needed for the start flash.", Toast.LENGTH_LONG).show();
            return;
        }
        startTriggered = false;
        FrameLayout setScreen = new FrameLayout(this);
        setScreen.setBackgroundColor(ICE_WHITE);

        FrameLayout centerGlass = glassCard(32, false);
        TextView set = label("SET", 54, Color.rgb(12, 24, 34), true);
        set.setLetterSpacing(0.16f);
        set.setPadding(dp(44), dp(28), dp(44), dp(28));
        centerGlass.addView(set, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));
        setScreen.addView(centerGlass, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));
        setScreen(setScreen);

        int delayMs = new Random().nextInt(6001);
        handler.postDelayed(this::fireStartSignal, delayMs);
    }

    private void fireStartSignal() {
        if (isFinishing() || role != Role.START) return;
        startWallMs = System.currentTimeMillis();
        startElapsedNanos = SystemClock.elapsedRealtimeNanos();
        runId = UUID.randomUUID().toString().substring(0, 8).toUpperCase(Locale.US);
        startTriggered = true;
        try {
            if (soundPool != null && bangSoundId != 0) {
                soundPool.play(bangSoundId, 1f, 1f, 1, 0, 1f);
            }
        } catch (Exception ignored) { }
        setTorch(true);
        handler.postDelayed(() -> setTorch(false), 320L);
        showStartTimer();
    }

    private void showStartTimer() {
        LinearLayout p = page();
        addHeader(p, "START SIGNAL SENT", "Local true start timestamp locked.");
        addSpace(p, 26);

        FrameLayout timerCard = glassCard(28, true);
        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setGravity(Gravity.CENTER);
        inner.setPadding(dp(20), dp(30), dp(20), dp(30));

        TextView t = label("00:00.000", 44, Color.WHITE, true);
        t.setId(0x531001);
        inner.addView(t, new LinearLayout.LayoutParams(-1, -2));
        addSpace(inner, 10);
        inner.addView(label("RUN " + runId, 12, MINT, true), new LinearLayout.LayoutParams(-1, -2));

        timerCard.addView(inner, new FrameLayout.LayoutParams(-1, -2));
        p.addView(timerCard, new LinearLayout.LayoutParams(-1, -2));

        addSpace(p, 28);
        p.addView(glassTriggerOrb("", false, this::showRunQr), new LinearLayout.LayoutParams(dp(86), dp(86)));
        addSpace(p, 10);
        p.addView(label("TAP TO GENERATE START QR", 11, MUTED, true), new LinearLayout.LayoutParams(-1, -2));
        addSpace(p, 22);
        p.addView(glassButton("NEW RUN", false, this::showStartHome), new LinearLayout.LayoutParams(-1, dp(52)));

        setScreen(wrapScroll(p));
        handler.removeCallbacks(timerTicker);
        handler.post(timerTicker);
    }

    private void showRunQr() {
        String payload = "RUN|" + runId + "|" + startWallMs;
        showQrPage("START DATA QR",
                "Scan this QR code with the STOP phone to calculate the sprint result.",
                payload,
                "BACK TO TIMER",
                this::showStartTimer);
    }

    // ---------------------------------------------------------------------
    // 3. STOP PHONE Screens, 3s Pre/Post Rolling Buffer & Scrubber
    // ---------------------------------------------------------------------

    private void showStopHome() {
        LinearLayout p = page();
        addHeader(p, "STOP PHONE", "Rolling 3s pre/post finish camera & manual chest-line scrub.");
        addSpace(p, 20);

        FrameLayout statusCard = glassCard(20, false);
        LinearLayout statusInner = new LinearLayout(this);
        statusInner.setOrientation(LinearLayout.VERTICAL);
        statusInner.setPadding(dp(18), dp(16), dp(18), dp(16));

        TextView status = label(clockCalibrated
                        ? "CLOCKS CALIBRATED  ·  ±" + syncUncertaintyMs + " ms"
                        : "CLOCKS NOT CALIBRATED",
                12, clockCalibrated ? MINT : Color.rgb(251, 191, 36), true);
        statusInner.addView(status, new LinearLayout.LayoutParams(-1, -2));

        if (importedStartWallMs > 0) {
            addSpace(statusInner, 6);
            statusInner.addView(label("READY WITH RUN " + importedRunId, 11, ICE_WHITE, true),
                    new LinearLayout.LayoutParams(-1, -2));
        }
        statusCard.addView(statusInner, new FrameLayout.LayoutParams(-1, -2));
        p.addView(statusCard, new LinearLayout.LayoutParams(-1, -2));

        addSpace(p, 22);
        p.addView(glassButton("OPEN FINISH CAMERA", true, this::openCameraAndRecord),
                new LinearLayout.LayoutParams(-1, dp(60)));
        addSpace(p, 14);
        p.addView(glassButton("CALIBRATE PHONES", false, this::showStopSyncQr),
                new LinearLayout.LayoutParams(-1, dp(54)));
        addSpace(p, 12);
        p.addView(glassButton("SCAN START QR", false, () -> launchScanner("Scan START phone run QR")),
                new LinearLayout.LayoutParams(-1, dp(54)));

        addSpace(p, 22);
        TextView change = label("CHANGE PHONE ROLE", 11, MUTED, true);
        change.setLetterSpacing(0.12f);
        change.setPadding(0, dp(10), 0, dp(10));
        change.setOnClickListener(v -> showRolePicker());
        p.addView(change, new LinearLayout.LayoutParams(-1, -2));
        setScreen(wrapScroll(p));
    }

    private void showStopSyncQr() {
        syncNonce = UUID.randomUUID().toString().substring(0, 10);
        syncStopT1 = System.currentTimeMillis();
        String payload = "SYNC1|" + syncNonce + "|" + syncStopT1;
        showQrPage("CALIBRATE PHONES",
                "1. On START PHONE, tap “SYNC WITH STOP PHONE” and scan this code.\n2. Then tap below to scan START PHONE's response.",
                payload,
                "SCAN START RESPONSE",
                () -> launchScanner("Scan START phone sync response"));
    }

    private void openCameraAndRecord() {
        if (!hasCameraPermission()) {
            requestCameraPermission();
            return;
        }
        showCameraScreen();
    }

    private void showCameraScreen() {
        triggerOffsetMs = -1L;
        postTriggerCountdownActive = false;

        FrameLayout screen = new FrameLayout(this);
        screen.setBackgroundColor(Color.BLACK);

        previewView = new PreviewView(this);
        previewView.setImplementationMode(PreviewView.ImplementationMode.PERFORMANCE);
        previewView.setScaleType(PreviewView.ScaleType.FILL_CENTER);
        screen.addView(previewView, new FrameLayout.LayoutParams(-1, -1));
        screen.addView(new FinishLineOverlay(this), new FrameLayout.LayoutParams(-1, -1));

        // Top glass HUD pill
        FrameLayout topGlass = glassCard(22, false);
        LinearLayout topCol = new LinearLayout(this);
        topCol.setOrientation(LinearLayout.VERTICAL);
        topCol.setPadding(dp(18), dp(14), dp(18), dp(14));

        TextView recStatus = label("INITIALIZING FINISH CAMERA…", 12, ICE_WHITE, true);
        recStatus.setLetterSpacing(0.12f);
        topCol.addView(recStatus, new LinearLayout.LayoutParams(-1, -2));

        addSpace(topCol, 4);
        TextView recSub = label("Align vertical white line with finish line. Tap STOP as runner crosses.", 11, MUTED, false);
        topCol.addView(recSub, new LinearLayout.LayoutParams(-1, -2));

        topGlass.addView(topCol, new FrameLayout.LayoutParams(-1, -2));
        FrameLayout.LayoutParams topLp = new FrameLayout.LayoutParams(-1, -2, Gravity.TOP);
        topLp.setMargins(dp(18), dp(22), dp(18), 0);
        screen.addView(topGlass, topLp);

        // Bottom frosted glass trigger dock
        FrameLayout bottomGlass = glassCard(28, true);
        LinearLayout bottomRow = new LinearLayout(this);
        bottomRow.setOrientation(LinearLayout.VERTICAL);
        bottomRow.setGravity(Gravity.CENTER);
        bottomRow.setPadding(dp(18), dp(16), dp(18), dp(16));

        View stopOrb = glassTriggerOrb("STOP", true, () -> triggerStopWindow(recStatus, recSub));
        bottomRow.addView(stopOrb, new LinearLayout.LayoutParams(dp(84), dp(84)));

        addSpace(bottomRow, 8);
        TextView dockHint = label("CAPTURES 3s BEFORE + 3s AFTER TAP", 10, ICE_WHITE, true);
        dockHint.setLetterSpacing(0.14f);
        bottomRow.addView(dockHint, new LinearLayout.LayoutParams(-1, -2));

        bottomGlass.addView(bottomRow, new FrameLayout.LayoutParams(-1, -2));
        FrameLayout.LayoutParams bottomLp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        bottomLp.setMargins(dp(18), 0, dp(18), dp(22));
        screen.addView(bottomGlass, bottomLp);

        setScreen(screen);
        bindCameraAndStartRecording(recStatus);
    }

    private void bindCameraAndStartRecording(TextView recStatus) {
        ListenableFuture<ProcessCameraProvider> future = ProcessCameraProvider.getInstance(this);
        future.addListener(() -> {
            try {
                cameraProvider = future.get();
                Preview preview = new Preview.Builder().build();
                preview.setSurfaceProvider(previewView.getSurfaceProvider());

                Recorder recorder = new Recorder.Builder()
                        .setQualitySelector(QualitySelector.fromOrderedList(
                                Arrays.asList(Quality.FHD, Quality.HD, Quality.SD),
                                FallbackStrategy.lowerQualityOrHigherThan(Quality.SD)))
                        .build();

                VideoCapture.Builder<Recorder> captureBuilder = new VideoCapture.Builder<>(recorder);
                try {
                    CameraCharacteristics chars = cameraManager.getCameraCharacteristics(cameraId);
                    Range<Integer>[] ranges = chars.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES);
                    Range<Integer> best = null;
                    if (ranges != null) {
                        for (Range<Integer> range : ranges) {
                            if (range.getUpper() >= 60 && (best == null || range.getUpper() > best.getUpper())) {
                                best = range;
                            }
                        }
                    }
                    if (best != null) {
                        new Camera2Interop.Extender<>(captureBuilder)
                                .setCaptureRequestOption(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, best);
                    }
                } catch (Exception ignored) { }

                videoCapture = captureBuilder.build();
                cameraProvider.unbindAll();
                cameraProvider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, videoCapture);
                handler.postDelayed(() -> startVideoRecording(recStatus), 350L);
            } catch (Exception e) {
                Toast.makeText(this, "Could not open camera: " + e.getMessage(), Toast.LENGTH_LONG).show();
                showStopHome();
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private void startVideoRecording(TextView recStatus) {
        if (videoCapture == null || isFinishing()) return;
        try {
            File dir = getExternalFilesDir(Environment.DIRECTORY_MOVIES);
            if (dir == null) dir = getFilesDir();
            if (!dir.exists()) dir.mkdirs();
            currentVideoFile = new File(dir, "sprint_" + System.currentTimeMillis() + ".mp4");
            FileOutputOptions options = new FileOutputOptions.Builder(currentVideoFile).build();
            PendingRecording pending = videoCapture.getOutput().prepareRecording(this, options);
            recordingFinished = false;

            activeRecording = pending.start(ContextCompat.getMainExecutor(this), event -> {
                if (event instanceof VideoRecordEvent.Start) {
                    videoStartWallMs = System.currentTimeMillis();
                    videoStartElapsedNs = SystemClock.elapsedRealtimeNanos();
                    recStatus.setText("ARMED · ROLLING 3s BUFFER");
                    recStatus.setTextColor(MINT);
                } else if (event instanceof VideoRecordEvent.Finalize) {
                    VideoRecordEvent.Finalize f = (VideoRecordEvent.Finalize) event;
                    recordingFinished = true;
                    if (f.hasError()) {
                        Toast.makeText(this, "Video capture failed. Try again.", Toast.LENGTH_LONG).show();
                        showStopHome();
                    } else {
                        openFrameReview();
                    }
                }
            });
        } catch (Exception e) {
            Toast.makeText(this, "Could not start recording: " + e.getMessage(), Toast.LENGTH_LONG).show();
            showStopHome();
        }
    }

    /**
     * Marks the exact tap instant so the review window isolates [tap - 3s, tap + 3s],
     * continues recording for 3 full seconds after the click, and then opens review.
     */
    private void triggerStopWindow(TextView recStatus, TextView recSub) {
        if (activeRecording == null) {
            Toast.makeText(this, "Camera is still arming…", Toast.LENGTH_SHORT).show();
            return;
        }
        if (postTriggerCountdownActive) return;

        postTriggerCountdownActive = true;
        triggerOffsetMs = Math.max(0L, (SystemClock.elapsedRealtimeNanos() - videoStartElapsedNs) / 1_000_000L);
        recStatus.setTextColor(Color.rgb(255, 130, 145));
        recSub.setText("Keeping 3.0s before tap and recording 3.0s after tap…");

        final long postDeadline = SystemClock.elapsedRealtime() + PRE_POST_WINDOW_MS;
        Runnable countdown = new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || activeRecording == null) return;
                long rem = postDeadline - SystemClock.elapsedRealtime();
                if (rem > 0) {
                    recStatus.setText(String.format(Locale.US, "CAPTURING +%.1fs POST-TAP…", rem / 1000f));
                    handler.postDelayed(this, 60L);
                } else {
                    recStatus.setText("FINALIZING 6s PHOTO-FINISH CLIP…");
                    finalizeRecordingNow();
                }
            }
        };
        handler.post(countdown);
    }

    private void finalizeRecordingNow() {
        if (activeRecording != null) {
            try {
                activeRecording.stop();
            } catch (Exception ignored) { }
            activeRecording = null;
        }
    }

    // ---------------------------------------------------------------------
    // 4. Frame-by-Frame Chest-to-Line Scrubber (3s Before -> 3s After)
    // ---------------------------------------------------------------------

    private void openFrameReview() {
        if (cameraProvider != null) {
            try { cameraProvider.unbindAll(); } catch (Exception ignored) { }
        }
        if (currentVideoFile == null || !currentVideoFile.exists()) {
            Toast.makeText(this, "No recorded video found.", Toast.LENGTH_LONG).show();
            showStopHome();
            return;
        }
        if (retriever != null) {
            try { retriever.release(); } catch (Exception ignored) { }
        }
        retriever = new MediaMetadataRetriever();
        try {
            retriever.setDataSource(currentVideoFile.getAbsolutePath());
            String dur = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            videoDurationMs = dur == null ? 0L : Long.parseLong(dur);
            String fps = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_CAPTURE_FRAMERATE);
            if (fps != null) {
                frameRate = Math.max(24f, Math.min(120f, Float.parseFloat(fps)));
            }
        } catch (Exception e) {
            videoDurationMs = Math.max(0L, (SystemClock.elapsedRealtimeNanos() - videoStartElapsedNs) / 1_000_000L);
            frameRate = 30f;
        }

        if (triggerOffsetMs < 0L) {
            triggerOffsetMs = Math.max(0L, videoDurationMs - PRE_POST_WINDOW_MS);
        }

        // Trim scrubber strictly to [trigger - 3000ms, trigger + 3000ms]
        reviewWindowStartMs = Math.max(0L, triggerOffsetMs - PRE_POST_WINDOW_MS);
        reviewWindowEndMs = Math.min(videoDurationMs, triggerOffsetMs + PRE_POST_WINDOW_MS);
        if (reviewWindowEndMs <= reviewWindowStartMs) {
            reviewWindowStartMs = 0L;
            reviewWindowEndMs = Math.max(100L, videoDurationMs);
        }

        long windowSpanMs = reviewWindowEndMs - reviewWindowStartMs;
        frameCount = Math.max(1, (int) Math.ceil(windowSpanMs * frameRate / 1000f));

        // Start scrub cursor right at the tap moment (0.000s offset)
        long initialOffsetInWindow = Math.max(0L, triggerOffsetMs - reviewWindowStartMs);
        frameIndex = Math.max(0, Math.min(frameCount - 1, Math.round(initialOffsetInWindow * frameRate / 1000f)));

        showFrameReview();
        setReviewFrame(frameIndex);
    }

    private void showFrameReview() {
        LinearLayout p = page();
        addHeader(p, "PHOTO FINISH", "Scrub 3s before/after tap. Stop when the chest touches the white line.");
        addSpace(p, 14);

        FrameLayout imageShell = glassCard(24, false);
        reviewImage = new ImageView(this);
        reviewImage.setScaleType(ImageView.ScaleType.FIT_CENTER);
        imageShell.addView(reviewImage, new FrameLayout.LayoutParams(-1, -1));
        imageShell.addView(new FinishLineOverlay(this), new FrameLayout.LayoutParams(-1, -1));

        LinearLayout.LayoutParams imageLp = new LinearLayout.LayoutParams(dp(296), dp(296));
        imageLp.gravity = Gravity.CENTER_HORIZONTAL;
        p.addView(imageShell, imageLp);

        addSpace(p, 14);

        FrameLayout scrubCard = glassCard(22, true);
        LinearLayout scrubInner = new LinearLayout(this);
        scrubInner.setOrientation(LinearLayout.VERTICAL);
        scrubInner.setPadding(dp(16), dp(14), dp(16), dp(14));

        reviewTimestamp = label("00:00.000", 24, MINT, true);
        scrubInner.addView(reviewTimestamp, new LinearLayout.LayoutParams(-1, -2));

        reviewRelativeBadge = label("0.000s FROM TAP", 11, ICE_WHITE, true);
        reviewRelativeBadge.setLetterSpacing(0.12f);
        scrubInner.addView(reviewRelativeBadge, new LinearLayout.LayoutParams(-1, -2));

        addSpace(scrubInner, 8);
        reviewSeek = new SeekBar(this);
        reviewSeek.setMax(Math.max(1, frameCount - 1));
        reviewSeek.setProgress(frameIndex);
        reviewSeek.setProgressTintList(ColorStateList.valueOf(MINT));
        reviewSeek.setThumbTintList(ColorStateList.valueOf(Color.WHITE));
        reviewSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser && !ignoreSeekCallback) setReviewFrame(progress);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        });
        scrubInner.addView(reviewSeek, new LinearLayout.LayoutParams(-1, dp(34)));

        LinearLayout controls = new LinearLayout(this);
        controls.setGravity(Gravity.CENTER);
        View prev = glassButton("‹ PREV FRAME", false, () -> setReviewFrame(Math.max(0, frameIndex - 1)));
        View next = glassButton("NEXT FRAME ›", false, () -> setReviewFrame(Math.min(frameCount - 1, frameIndex + 1)));
        LinearLayout.LayoutParams ctrl = new LinearLayout.LayoutParams(0, dp(46), 1f);
        ctrl.setMargins(dp(4), dp(4), dp(4), 0);
        controls.addView(prev, ctrl);
        controls.addView(next, ctrl);
        scrubInner.addView(controls, new LinearLayout.LayoutParams(-1, -2));

        scrubCard.addView(scrubInner, new FrameLayout.LayoutParams(-1, -2));
        p.addView(scrubCard, new LinearLayout.LayoutParams(-1, -2));

        addSpace(p, 14);
        p.addView(glassButton("LOCK CHEST-ON-LINE FRAME", true, this::showFinishResult),
                new LinearLayout.LayoutParams(-1, dp(56)));
        addSpace(p, 10);
        p.addView(glassButton("SCAN START PHONE QR", false, () -> launchScanner("Scan START phone run QR")),
                new LinearLayout.LayoutParams(-1, dp(48)));

        setScreen(wrapScroll(p));
    }

    private long getSelectedVideoOffsetMs() {
        long relMs = Math.round(frameIndex * 1000f / frameRate);
        return Math.min(reviewWindowEndMs, reviewWindowStartMs + relMs);
    }

    private void setReviewFrame(int index) {
        frameIndex = Math.max(0, Math.min(frameCount - 1, index));
        long videoMs = getSelectedVideoOffsetMs();
        long deltaFromTapMs = videoMs - triggerOffsetMs;

        if (reviewTimestamp != null) {
            reviewTimestamp.setText(formatMillis(videoMs));
        }
        if (reviewRelativeBadge != null) {
            String sign = deltaFromTapMs >= 0 ? "+" : "-";
            reviewRelativeBadge.setText(String.format(Locale.US, "%s%.3fs RELATIVE TO STOP TAP",
                    sign, Math.abs(deltaFromTapMs) / 1000.0));
        }
        if (reviewSeek != null) {
            ignoreSeekCallback = true;
            reviewSeek.setProgress(frameIndex);
            ignoreSeekCallback = false;
        }
        loadReviewFrame(videoMs);
    }

    private void loadReviewFrame(long videoMs) {
        if (retriever == null) return;
        final long timeUs = Math.max(0L, videoMs * 1000L);
        frameExecutor.execute(() -> {
            Bitmap bitmap = null;
            try {
                bitmap = retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST);
            } catch (Exception ignored) { }
            final Bitmap result = bitmap;
            runOnUiThread(() -> {
                if (reviewImage != null && result != null) reviewImage.setImageBitmap(result);
            });
        });
    }

    // ---------------------------------------------------------------------
    // 5. Final Result Screen ("Your time is:\n<Number>")
    // ---------------------------------------------------------------------

    private void showFinishResult() {
        long finishOffsetMs = getSelectedVideoOffsetMs();
        long finishStopWall = videoStartWallMs + finishOffsetMs;
        boolean hasStart = importedStartWallMs > 0L;
        long elapsedMs = hasStart
                ? Math.max(0L, finishStopWall - (importedStartWallMs - clockOffsetStartMinusStopMs))
                : -1L;

        LinearLayout p = page();
        addHeader(p, "OFFICIAL RESULT", "Calibrated two-phone photo-finish measurement.");
        addSpace(p, 24);

        FrameLayout resultCard = glassCard(30, true);
        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setGravity(Gravity.CENTER);
        inner.setPadding(dp(24), dp(34), dp(24), dp(34));

        if (hasStart) {
            TextView promptLbl = label("Your time is:", 20, ICE_WHITE, false);
            inner.addView(promptLbl, new LinearLayout.LayoutParams(-1, -2));

            addSpace(inner, 14);

            TextView bigTime = label(formatMillis(elapsedMs), 46, MINT, true);
            inner.addView(bigTime, new LinearLayout.LayoutParams(-1, -2));

            addSpace(inner, 16);
            inner.addView(label("RUN " + importedRunId + "  ·  FINISH CLIP " + formatMillis(finishOffsetMs),
                    11, MUTED, true), new LinearLayout.LayoutParams(-1, -2));

            addSpace(inner, 6);
            if (clockCalibrated) {
                inner.addView(label("CLOCK OFFSET " + signed(clockOffsetStartMinusStopMs)
                                + " ms  ·  ±" + syncUncertaintyMs + " ms", 11, ICE_WHITE, false),
                        new LinearLayout.LayoutParams(-1, -2));
            } else {
                inner.addView(label("UN-CALIBRATED (Run Calibrate Phones for sub-frame sync)",
                        11, Color.rgb(251, 191, 36), false), new LinearLayout.LayoutParams(-1, -2));
            }
        } else {
            inner.addView(label("Finish Frame Locked: " + formatMillis(finishOffsetMs), 18, MINT, true),
                    new LinearLayout.LayoutParams(-1, -2));
            addSpace(inner, 12);
            inner.addView(label("Scan the START phone's QR code to compute your sprint time.",
                    14, ICE_WHITE, false), new LinearLayout.LayoutParams(-1, -2));
        }

        resultCard.addView(inner, new FrameLayout.LayoutParams(-1, -2));
        p.addView(resultCard, new LinearLayout.LayoutParams(-1, -2));

        addSpace(p, 22);
        if (!hasStart) {
            p.addView(glassButton("SCAN START QR NOW", true, () -> launchScanner("Scan START phone run QR")),
                    new LinearLayout.LayoutParams(-1, dp(56)));
            addSpace(p, 12);
        }
        p.addView(glassButton("ADJUST FRAME", false, this::showFrameReview),
                new LinearLayout.LayoutParams(-1, dp(52)));
        addSpace(p, 12);
        p.addView(glassButton("DONE", hasStart, this::showStopHome),
                new LinearLayout.LayoutParams(-1, dp(52)));

        setScreen(wrapScroll(p));
    }

    private void loadCalibration() {
        SharedPreferences prefs = getSharedPreferences("sprintclock", MODE_PRIVATE);
        clockCalibrated = prefs.getBoolean("clock_calibrated", false);
        clockOffsetStartMinusStopMs = prefs.getLong("clock_offset_ms", 0L);
        syncUncertaintyMs = prefs.getLong("sync_uncertainty_ms", -1L);
    }

    private void saveCalibration() {
        getSharedPreferences("sprintclock", MODE_PRIVATE).edit()
                .putBoolean("clock_calibrated", true)
                .putLong("clock_offset_ms", clockOffsetStartMinusStopMs)
                .putLong("sync_uncertainty_ms", syncUncertaintyMs)
                .apply();
    }

    // ---------------------------------------------------------------------
    // 6. QR Generation & Crash-Safe Scanner Launcher
    // ---------------------------------------------------------------------

    private void showQrPage(String title, String description, String payload, String buttonText, Runnable action) {
        LinearLayout p = page();
        addHeader(p, title, description);
        addSpace(p, 22);

        FrameLayout qrPanel = glassCard(28, true);
        qrPanel.setPadding(dp(18), dp(18), dp(18), dp(18));
        ImageView image = new ImageView(this);
        image.setImageBitmap(makeQr(payload, 720));
        image.setBackground(rounded(new int[]{Color.WHITE, Color.WHITE}, 16, 0xFFFFFFFF, 1));
        image.setPadding(dp(12), dp(12), dp(12), dp(12));
        qrPanel.addView(image, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout.LayoutParams qlp = new LinearLayout.LayoutParams(dp(276), dp(276));
        qlp.gravity = Gravity.CENTER_HORIZONTAL;
        p.addView(qrPanel, qlp);

        addSpace(p, 24);
        p.addView(glassButton(buttonText, true, action), new LinearLayout.LayoutParams(-1, dp(56)));
        addSpace(p, 12);

        TextView back = label("BACK", 11, MUTED, true);
        back.setLetterSpacing(0.14f);
        back.setPadding(0, dp(12), 0, dp(12));
        back.setOnClickListener(v -> {
            if (role == Role.START) showStartHome();
            else showStopHome();
        });
        p.addView(back, new LinearLayout.LayoutParams(-1, -2));
        setScreen(wrapScroll(p));
    }

    private Bitmap makeQr(String payload, int size) {
        try {
            Map<EncodeHintType, Object> hints = new EnumMap<>(EncodeHintType.class);
            hints.put(EncodeHintType.MARGIN, 1);
            BitMatrix matrix = new MultiFormatWriter().encode(payload, BarcodeFormat.QR_CODE, size, size, hints);
            Bitmap bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
            for (int y = 0; y < size; y++) {
                for (int x = 0; x < size; x++) {
                    bmp.setPixel(x, y, matrix.get(x, y) ? Color.BLACK : Color.WHITE);
                }
            }
            return bmp;
        } catch (Exception e) {
            return Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888);
        }
    }

    private void launchScanner(String prompt) {
        if (!hasCameraPermission()) {
            pendingScanPrompt = prompt;
            requestCameraPermission();
            return;
        }
        try {
            ScanOptions options = new ScanOptions();
            options.setDesiredBarcodeFormats(Collections.singletonList(ScanOptions.QR_CODE));
            options.setCaptureActivity(SprintScannerActivity.class);
            options.setPrompt(prompt);
            options.setCameraId(0);
            options.setBeepEnabled(false);
            options.setOrientationLocked(true);
            scanLauncher.launch(options);
        } catch (Exception e) {
            Toast.makeText(this, "Scanner error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void handleQrPayload(String payload) {
        try {
            String[] parts = payload.split("\\|");
            if (parts.length == 3 && "SYNC1".equals(parts[0]) && role == Role.START) {
                String nonce = parts[1];
                long t1 = Long.parseLong(parts[2]);
                long t2 = System.currentTimeMillis();
                long t3 = System.currentTimeMillis();
                String response = "SYNC2|" + nonce + "|" + t1 + "|" + t2 + "|" + t3;
                showQrPage("SYNC RESPONSE",
                        "Let the STOP phone scan this response to lock in the clock offset.",
                        response,
                        "DONE",
                        this::showStartHome);
                return;
            }
            if (parts.length == 5 && "SYNC2".equals(parts[0]) && role == Role.STOP) {
                String nonce = parts[1];
                if (!syncNonce.isEmpty() && !syncNonce.equals(nonce)) {
                    Toast.makeText(this, "This QR belongs to a different pairing attempt.", Toast.LENGTH_LONG).show();
                    return;
                }
                long t1 = Long.parseLong(parts[2]);
                long t2 = Long.parseLong(parts[3]);
                long t3 = Long.parseLong(parts[4]);
                long t4 = System.currentTimeMillis();
                clockOffsetStartMinusStopMs = Math.round(((t2 - t1) + (t3 - t4)) / 2.0);
                long rtt = Math.max(0L, (t4 - t1) - (t3 - t2));
                syncUncertaintyMs = Math.round(rtt / 2.0);
                clockCalibrated = true;
                saveCalibration();
                Toast.makeText(this, "Phones calibrated (±" + syncUncertaintyMs + " ms)", Toast.LENGTH_LONG).show();
                showStopHome();
                return;
            }
            if (parts.length == 3 && "RUN".equals(parts[0]) && role == Role.STOP) {
                importedRunId = parts[1];
                importedStartWallMs = Long.parseLong(parts[2]);
                Toast.makeText(this, "Start data imported (Run " + importedRunId + ").", Toast.LENGTH_SHORT).show();
                if (recordingFinished && currentVideoFile != null && currentVideoFile.exists()) {
                    showFinishResult();
                } else {
                    showStopHome();
                }
                return;
            }
            Toast.makeText(this, "That QR code is not for this screen.", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Could not read SprintClock QR data.", Toast.LENGTH_LONG).show();
        }
    }

    // ---------------------------------------------------------------------
    // Utilities, Permissions, Torch & Custom Glass Backdrops
    // ---------------------------------------------------------------------

    private boolean hasCameraPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestCameraPermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, REQUEST_CAMERA);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CAMERA && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            if (pendingScanPrompt != null) {
                String p = pendingScanPrompt;
                pendingScanPrompt = null;
                launchScanner(p);
                return;
            }
            if (role == Role.STOP) showStopHome();
            else Toast.makeText(this, "Camera access enabled. Tap START TIMING again.", Toast.LENGTH_SHORT).show();
        }
    }

    private void setTorch(boolean enabled) {
        if (cameraId == null || cameraManager == null) return;
        try {
            cameraManager.setTorchMode(cameraId, enabled);
        } catch (Exception ignored) { }
    }

    private String formatDurationNanos(long nanos) {
        long millis = Math.max(0L, nanos / 1_000_000L);
        return formatMillis(millis);
    }

    private String formatMillis(long millis) {
        if (millis < 0) return "—";
        long minutes = millis / 60000L;
        long seconds = (millis % 60000L) / 1000L;
        long ms = millis % 1000L;
        return String.format(Locale.US, "%02d:%02d.%03d", minutes, seconds, ms);
    }

    private String signed(long value) {
        return (value >= 0 ? "+" : "") + value;
    }

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    public void onBackPressed() {
        if (role == Role.START) {
            handler.removeCallbacks(timerTicker);
            setTorch(false);
            showStartHome();
        } else if (role == Role.STOP) {
            if (activeRecording != null) {
                Toast.makeText(this, "Tap STOP to capture the finish window.", Toast.LENGTH_SHORT).show();
            } else {
                showStopHome();
            }
        } else {
            showRolePicker();
        }
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        setTorch(false);
        if (soundPool != null) soundPool.release();
        if (retriever != null) {
            try { retriever.release(); } catch (Exception ignored) { }
        }
        frameExecutor.shutdown();
        super.onDestroy();
    }

    /** Ambient dark-obsidian & ice-white light mesh behind BlurView for real glass refraction. */
    private static class AmbientGlassBackdrop extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        AmbientGlassBackdrop(Context context) {
            super(context);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();
            if (w <= 0 || h <= 0) return;

            paint.setShader(new LinearGradient(0, 0, w, h,
                    new int[]{Color.rgb(5, 8, 13), Color.rgb(11, 17, 26), Color.rgb(6, 9, 14)},
                    null, Shader.TileMode.CLAMP));
            canvas.drawRect(0, 0, w, h, paint);

            // Top-left cool white/cyan luminous orb for glass refraction
            paint.setShader(new RadialGradient(w * 0.18f, h * 0.16f, w * 0.65f,
                    new int[]{0x38E2F1FF, 0x147AF2C6, 0x00000000},
                    null, Shader.TileMode.CLAMP));
            canvas.drawCircle(w * 0.18f, h * 0.16f, w * 0.65f, paint);

            // Bottom-right soft white/slate orb
            paint.setShader(new RadialGradient(w * 0.85f, h * 0.78f, w * 0.70f,
                    new int[]{0x2EFFFFFF, 0x1038BDF8, 0x00000000},
                    null, Shader.TileMode.CLAMP));
            canvas.drawCircle(w * 0.85f, h * 0.78f, w * 0.70f, paint);
            paint.setShader(null);
        }
    }

    /** Vertical white finish line reference overlay for camera & photo-finish scrubber. */
    private class FinishLineOverlay extends View {
        private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);

        FinishLineOverlay(Context context) {
            super(context);
            line.setColor(Color.WHITE);
            line.setStrokeWidth(dp(2));
            line.setStyle(Paint.Style.STROKE);

            glow.setColor(0x44FFFFFF);
            glow.setStrokeWidth(dp(10));
            glow.setStyle(Paint.Style.STROKE);
            setBackgroundColor(Color.TRANSPARENT);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float x = getWidth() * 0.50f;
            canvas.drawLine(x, getHeight() * 0.05f, x, getHeight() * 0.95f, glow);
            canvas.drawLine(x, getHeight() * 0.05f, x, getHeight() * 0.95f, line);
        }
    }
}
