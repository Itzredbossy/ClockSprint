package com.sprintclock.app;

import android.graphics.Color;
import android.os.Bundle;
import android.view.WindowManager;

import com.journeyapps.barcodescanner.CaptureActivity;
import com.journeyapps.barcodescanner.DecoratedBarcodeView;

/** Minimal dark QR scanner with a frosted rounded-square scan window. */
public class SprintScannerActivity extends CaptureActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        super.onCreate(savedInstanceState);
    }

    @Override
    protected DecoratedBarcodeView initializeContent() {
        setContentView(R.layout.sprint_scanner);
        DecoratedBarcodeView scanner = findViewById(R.id.zxing_barcode_scanner);
        if (scanner != null && scanner.getStatusView() != null) {
            scanner.getStatusView().setBackgroundColor(0x6610161F);
            scanner.getStatusView().setTextColor(Color.WHITE);
        }
        return scanner;
    }
}
