# SprintClock

Offline two-phone sprint timer with dark/white frosted glassmorphism, starter flash + sound (`R.raw.bang`), 3-second pre/post rolling finish capture buffer, frame-by-frame chest-to-line scrubbing, and two-step QR clock calibration.

## Build APK via GitHub Actions

1. Push the project files (`build.gradle`, `settings.gradle`, `gradle.properties`, `app/`, and `.github/workflows/build-apk.yml`) to your GitHub repository.
2. Open **Actions** → **Build SprintClock APK** → **Run workflow**.
3. Download the `app-debug.apk` artifact once the workflow completes.
