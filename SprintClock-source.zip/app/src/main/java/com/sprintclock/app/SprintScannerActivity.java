package com.sprintclock.app;

import com.journeyapps.barcodescanner.CaptureActivity;
import com.journeyapps.barcodescanner.DecoratedBarcodeView;

/** Minimal black QR scanner with a quiet, rounded-square scan window. */
public class SprintScannerActivity extends CaptureActivity {
    @Override
    protected DecoratedBarcodeView initializeContent() {
        setContentView(R.layout.sprint_scanner);
        return findViewById(R.id.zxing_barcode_scanner);
    }
}
