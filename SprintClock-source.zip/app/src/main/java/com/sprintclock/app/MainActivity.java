package com.sprintclock.app;

import android.Manifest;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RenderEffect;
import android.graphics.Shader;
import android.graphics.drawable.GradientDrawable;
import android.hardware.camera2.CameraManager;
import android.media.AudioAttributes;
import android.media.SoundPool;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Space;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.camera2.interop.Camera2Interop;
import android.hardware.camera2.CaptureRequest;
import android.util.Range;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.video.FallbackStrategy;
import androidx.camera.video.FileOutputOptions;
import androidx.camera.video.PendingRecording;
import androidx.camera.video.Quality;
import androidx.camera.video.QualitySelector;
import androidx.camera.video.Recorder;
import androidx.camera.video.Recording;
import androidx.camera.video.VideoCapture;
import androidx.camera.video.VideoRecordEvent;
import androidx.camera.view.PreviewView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.common.util.concurrent.ListenableFuture;
import eightbitlab.com.blurview.BlurView;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.common.BitMatrix;
import androidx.activity.result.ActivityResultLauncher;
import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanOptions;

import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.util.TypedValue;
import android.widget.Button;
import android.widget.SeekBar;

import java.io.File;
import java.util.EnumMap;
import java.util.Collections;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * SprintClock - offline two-phone sprint timer.
 * STOP phone records video; START phone emits a delayed sound/flash start cue.
 * A short QR clock handshake estimates the offset between the two devices.
 */
public class MainActivity extends AppCompatActivity {
    private static final int REQUEST_CAMERA = 740;
    private static final int DARK = Color.BLACK;
    private static final int PANEL = Color.rgb(18, 18, 18);
    private static final int MINT = Color.rgb(117, 218, 180);
    private static final int MUTED = Color.rgb(150, 164, 177);

    private enum Role { NONE, START, STOP }
    private Role role = Role.NONE;

    private FrameLayout root;
    private int screenTransitionToken = 0;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private SoundPool soundPool;
    private ActivityResultLauncher<ScanOptions> scanLauncher;
    private int bangSoundId;
    private CameraManager cameraManager;
    private String cameraId;
    private boolean torchOn = false;

    // START phone timing data. elapsedRealtime is used for the live timer so wall-clock
    // changes during a run cannot make the displayed duration jump.
    private long startWallMs;
    private long startElapsedNanos;
    private String runId = "";
    private boolean startTriggered = false;

    // STOP phone calibration and imported run data.
    private String syncNonce = "";
    private long syncStopT1 = 0L;
    private long clockOffsetStartMinusStopMs = 0L;
    private long syncUncertaintyMs = -1L;
    private boolean clockCalibrated = false;
    private long importedStartWallMs = -1L;
    private String importedRunId = "";

    // Camera/video state.
    private PreviewView previewView;
    private ProcessCameraProvider cameraProvider;
    private VideoCapture<Recorder> videoCapture;
    private Recording activeRecording;
    private File currentVideoFile;
    private long videoStartWallMs = 0L;
    private long videoStartElapsedNs = 0L;
    private boolean recordingFinished = false;
    private long videoDurationMs = 0L;
    private float frameRate = 30f;
    private int frameIndex = 0;
    private int frameCount = 1;
    private MediaMetadataRetriever retriever;
    private final ExecutorService frameExecutor = Executors.newSingleThreadExecutor();
    private ImageView reviewImage;
    private TextView reviewTimestamp;
    private SeekBar reviewSeek;
    private boolean ignoreSeekCallback = false;

    private final Runnable timerTicker = new Runnable() {
        @Override public void run() {
            if (role == Role.START && startTriggered) {
                long elapsed = SystemClock.elapsedRealtimeNanos() - startElapsedNanos;
                TextView timer = findViewById(0x531001);
                if (timer != null) timer.setText(formatDurationNanos(elapsed));
                handler.postDelayed(this, 12L);
            }
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        scanLauncher = registerForActivityResult(new ScanContract(), result -> {
            if (result.getContents() != null) handleQrPayload(result.getContents());
            else Toast.makeText(this, "QR scan cancelled.", Toast.LENGTH_SHORT).show();
        });
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().setNavigationBarColor(DARK);
        getWindow().setStatusBarColor(DARK);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE);

        loadCalibration();
        cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        try {
            String[] ids = cameraManager.getCameraIdList();
            for (String id : ids) {
                android.hardware.camera2.CameraCharacteristics c = cameraManager.getCameraCharacteristics(id);
                Integer facing = c.get(android.hardware.camera2.CameraCharacteristics.LENS_FACING);
                if (facing != null && facing == android.hardware.camera2.CameraCharacteristics.LENS_FACING_BACK) {
                    cameraId = id;
                    break;
                }
            }
        } catch (Exception ignored) { }

        AudioAttributes attrs = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
        soundPool = new SoundPool.Builder().setMaxStreams(2).setAudioAttributes(attrs).build();
        bangSoundId = soundPool.load(this, R.raw.bang, 1);

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        setContentView(root);
        showRolePicker();
    }

    // ---------------------------------------------------------------------
    // Navigation and visual system
    // ---------------------------------------------------------------------

    private void setScreen(View view) {
        final int token = ++screenTransitionToken;
        View previous = root.getChildCount() == 0 ? null : root.getChildAt(root.getChildCount() - 1);
        Runnable install = () -> {
            if (token != screenTransitionToken) return;
            root.removeAllViews();
            root.addView(view, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            animateIn(view);
        };
        if (previous == null) {
            install.run();
        } else {
            previous.animate().cancel();
            previous.animate().alpha(0f).translationY(-dp(9)).scaleX(0.99f).scaleY(0.99f)
                    .setDuration(115).setInterpolator(new DecelerateInterpolator())
                    .withEndAction(install).start();
        }
    }

    private void animateIn(View view) {
        view.setAlpha(0f);
        view.setTranslationY(dp(18));
        view.setScaleX(0.985f);
        view.setScaleY(0.985f);
        AnimatorSet set = new AnimatorSet();
        set.playTogether(
                ObjectAnimator.ofFloat(view, View.ALPHA, 0f, 1f),
                ObjectAnimator.ofFloat(view, View.TRANSLATION_Y, dp(18), 0f),
                ObjectAnimator.ofFloat(view, View.SCALE_X, 0.985f, 1f),
                ObjectAnimator.ofFloat(view, View.SCALE_Y, 0.985f, 1f));
        set.setDuration(340);
        set.setInterpolator(new DecelerateInterpolator());
        set.start();
    }

    private LinearLayout page() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setGravity(Gravity.CENTER_HORIZONTAL);
        page.setPadding(dp(24), dp(28), dp(24), dp(24));
        return page;
    }

    private TextView label(String value, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        t.setIncludeFontPadding(false);
        if (bold) t.setTypeface(android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD));
        else t.setTypeface(android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL));
        return t;
    }

    private GradientDrawable rounded(int[] colors, int radiusDp, int strokeColor, int strokeDp) {
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR, colors);
        bg.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) bg.setStroke(dp(strokeDp), strokeColor);
        return bg;
    }

    private GradientDrawable ovalBackground(int[] colors, int strokeColor, int strokeDp) {
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR, colors);
        bg.setShape(GradientDrawable.OVAL);
        if (strokeDp > 0) bg.setStroke(dp(strokeDp), strokeColor);
        return bg;
    }

    private TextView pillButton(String text, boolean primary, Runnable action) {
        TextView b = label(text, 15, primary ? Color.rgb(7, 23, 18) : Color.rgb(227, 235, 242), true);
        b.setPadding(dp(18), dp(16), dp(18), dp(16));
        b.setBackground(rounded(primary
                ? new int[]{Color.rgb(151, 237, 204), MINT}
                : new int[]{Color.rgb(31, 42, 53), Color.rgb(22, 31, 40)},
                20, primary ? Color.rgb(161, 240, 212) : Color.rgb(57, 72, 86), 1));
        b.setElevation(dp(5));
        b.setOnClickListener(v -> {
            v.animate().scaleX(0.97f).scaleY(0.97f).setDuration(80)
                    .withEndAction(() -> v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()).start();
            action.run();
        });
        return b;
    }

    private View glassCheck(Runnable action) {
        FrameLayout shell = new FrameLayout(this);
        shell.setBackground(ovalBackground(new int[]{0x553B9BFF, 0x332C6FC0}, 0x99B8DFFF, 1));
        shell.setClipToOutline(true);
        shell.setElevation(dp(12));
        BlurView blur = new BlurView(this);
        blur.setupWith(root).setFrameClearDrawable(root.getBackground())
                .setBlurRadius(22f).setBlurEnabled(true).setOverlayColor(0x332E78B7);
        shell.addView(blur, new FrameLayout.LayoutParams(-1, -1));
        View tick = new View(this) {
            private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            @Override protected void onDraw(Canvas c) {
                super.onDraw(c);
                p.setColor(Color.rgb(82, 224, 139));
                p.setStrokeWidth(dp(3.2f));
                p.setStrokeCap(Paint.Cap.ROUND);
                p.setStrokeJoin(Paint.Join.ROUND);
                p.setStyle(Paint.Style.STROKE);
                float cx = getWidth()/2f, cy = getHeight()/2f;
                c.drawLine(cx-dp(11), cy, cx-dp(3), cy+dp(8), p);
                c.drawLine(cx-dp(3), cy+dp(8), cx+dp(13), cy-dp(10), p);
            }
        };
        shell.addView(tick, new FrameLayout.LayoutParams(-1, -1));
        shell.setOnClickListener(v -> {
            v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(85)
                    .withEndAction(() -> { v.animate().scaleX(1f).scaleY(1f).setDuration(150).start(); action.run(); }).start();
        });
        shell.setContentDescription("Confirm");
        return shell;
    }

    private FrameLayout glassPanel() {
        FrameLayout panel = new FrameLayout(this);
        panel.setBackground(rounded(new int[]{0x553A485B, 0x33202B3B}, 22, 0x66FFFFFF, 1));
        panel.setClipToOutline(true);
        panel.setElevation(dp(8));
        BlurView blur = new BlurView(this);
        blur.setupWith(root).setFrameClearDrawable(root.getBackground())
                .setBlurRadius(24f).setBlurEnabled(true).setOverlayColor(0x331B2638);
        panel.addView(blur, new FrameLayout.LayoutParams(-1, -1));
        return panel;
    }

    private void addSpace(LinearLayout parent, int heightDp) {
        Space s = new Space(this);
        parent.addView(s, new LinearLayout.LayoutParams(1, dp(heightDp)));
    }

    private void addHeader(LinearLayout page, String title, String subtitle) {
        TextView top = label("SPRINTCLOCK", 12, MINT, true);
        top.setLetterSpacing(0.18f);
        page.addView(top, new LinearLayout.LayoutParams(-1, dp(24)));
        addSpace(page, 12);
        page.addView(label(title, 25, Color.WHITE, true), new LinearLayout.LayoutParams(-1, -2));
        if (subtitle != null && !subtitle.isEmpty()) {
            addSpace(page, 8);
            TextView sub = label(subtitle, 13, MUTED, false);
            sub.setLineSpacing(dp(3), 1f);
            page.addView(sub, new LinearLayout.LayoutParams(-1, -2));
        }
    }

    // ---------------------------------------------------------------------
    // First screen: role selection
    // ---------------------------------------------------------------------

    private void showRolePicker() {
        role = Role.NONE;
        LinearLayout p = page();
        p.setPadding(dp(22), dp(24), dp(22), dp(24));
        p.setGravity(Gravity.CENTER);
        LinearLayout roleColumn = new LinearLayout(this);
        roleColumn.setOrientation(LinearLayout.VERTICAL);
        roleColumn.setGravity(Gravity.CENTER);
        roleColumn.addView(roleSquare("START PHONE", "", true,
                () -> { role = Role.START; showStartHome(); }), new LinearLayout.LayoutParams(-1, dp(112)));
        addSpace(roleColumn, 16);
        roleColumn.addView(roleSquare("STOP PHONE", "", false,
                () -> { role = Role.STOP; showStopHome(); }), new LinearLayout.LayoutParams(-1, dp(112)));
        p.addView(roleColumn, new LinearLayout.LayoutParams(-1, -2));
        setScreen(p);
    }

    private View roleSquare(String title, String subtitle, boolean primary, Runnable action) {
        TextView card = label(title, 19, Color.WHITE, true);
        card.setBackground(rounded(new int[]{Color.rgb(20, 20, 20), Color.rgb(13, 13, 13)},
                18, 0xFF303030, 1));
        card.setElevation(dp(2));
        card.setOnClickListener(v -> v.animate().alpha(0.7f).setDuration(80)
                .withEndAction(() -> { v.setAlpha(1f); action.run(); }).start());
        return card;
    }

    private View roleCard(String title, String subtitle, boolean primary, Runnable action) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(23), dp(20), dp(23), dp(20));
        card.setBackground(rounded(primary
                ? new int[]{Color.rgb(37, 72, 63), Color.rgb(19, 43, 39)}
                : new int[]{Color.rgb(38, 49, 63), Color.rgb(20, 29, 40)},
                27, primary ? 0x6659BD98 : 0x665A748D, 1));
        card.setElevation(dp(6));
        TextView t = label(title, 22, primary ? Color.rgb(179, 245, 218) : Color.WHITE, true);
        t.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        card.addView(t, new LinearLayout.LayoutParams(-1, -2));
        addSpace(card, 9);
        TextView sub = label(subtitle, 13, Color.rgb(178, 193, 205), false);
        sub.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        card.addView(sub, new LinearLayout.LayoutParams(-1, -2));
        card.setOnClickListener(v -> {
            v.animate().alpha(0.75f).scaleX(0.98f).scaleY(0.98f).setDuration(90)
                    .withEndAction(() -> action.run()).start();
        });
        return card;
    }

    // ---------------------------------------------------------------------
    // START PHONE screens and start signal
    // ---------------------------------------------------------------------

    private void showStartHome() {
        startTriggered = false;
        LinearLayout p = page();
        addHeader(p, "START PHONE", "");
        addSpace(p, 48);
        TextView time = label("READY", 15, MINT, true);
        time.setLetterSpacing(0.2f);
        p.addView(time, new LinearLayout.LayoutParams(-1, dp(30)));
        addSpace(p, 12);
        TextView main = label("SET\n\n—", 33, Color.WHITE, true);
        main.setLineSpacing(dp(5), 1f);
        p.addView(main, new LinearLayout.LayoutParams(-1, dp(160)));
        addSpace(p, 32);
        p.addView(pillButton("START TIMING", true, this::beginStartSequence),
                new LinearLayout.LayoutParams(-1, dp(58)));
        addSpace(p, 15);
        p.addView(pillButton("SYNC WITH STOP PHONE", false, this::scanStopSyncQr),
                new LinearLayout.LayoutParams(-1, dp(54)));
        addSpace(p, 14);
        TextView back = label("CHANGE PHONE ROLE", 11, MUTED, true);
        back.setPadding(0, dp(13), 0, dp(13));
        back.setOnClickListener(v -> showRolePicker());
        p.addView(back, new LinearLayout.LayoutParams(-1, -2));
        setScreen(p);
    }

    private void beginStartSequence() {
        if (!hasCameraPermission()) {
            requestCameraPermission();
            Toast.makeText(this, "Camera permission is needed for the start flash.", Toast.LENGTH_LONG).show();
            return;
        }
        startTriggered = false;
        LinearLayout setPage = new LinearLayout(this);
        setPage.setGravity(Gravity.CENTER);
        setPage.setOrientation(LinearLayout.VERTICAL);
        setPage.setBackgroundColor(Color.WHITE);
        TextView set = label("SET", 48, Color.rgb(32, 147, 84), true);
        set.setLetterSpacing(0.12f);
        setPage.addView(set, new LinearLayout.LayoutParams(-1, -2));
        setScreen(setPage);

        // Random starter delay requested: uniformly selected from 0 to 6 seconds.
        int delayMs = new Random().nextInt(6001);
        handler.postDelayed(() -> fireStartSignal(), delayMs);
    }

    private void fireStartSignal() {
        if (isFinishing() || role != Role.START) return;
        startWallMs = System.currentTimeMillis();
        startElapsedNanos = SystemClock.elapsedRealtimeNanos();
        runId = UUID.randomUUID().toString().substring(0, 8).toUpperCase(Locale.US);
        startTriggered = true;
        try {
            if (soundPool != null && bangSoundId != 0) soundPool.play(bangSoundId, 1f, 1f, 1, 0, 1f);
        } catch (Exception ignored) { }
        setTorch(true);
        handler.postDelayed(() -> setTorch(false), 320L);
        showStartTimer();
    }

    private void showStartTimer() {
        LinearLayout p = page();
        addHeader(p, "START SIGNAL SENT", "The timer uses the phone's monotonic clock, not the changing wall clock.");
        addSpace(p, 62);
        TextView t = label("00:00.000", 43, Color.WHITE, true);
        t.setId(0x531001);
        t.setTypeface(android.graphics.Typeface.create("sans-serif-light", android.graphics.Typeface.NORMAL));
        p.addView(t, new LinearLayout.LayoutParams(-1, dp(88)));
        addSpace(p, 22);
        p.addView(label("RUN " + runId, 12, MUTED, true), new LinearLayout.LayoutParams(-1, -2));
        addSpace(p, 44);
        p.addView(glassCheck(this::showRunQr), new LinearLayout.LayoutParams(dp(84), dp(84)));
        addSpace(p, 28);
        p.addView(pillButton("NEW RUN", false, this::showStartHome), new LinearLayout.LayoutParams(-1, dp(52)));
        setScreen(p);
        handler.removeCallbacks(timerTicker);
        handler.post(timerTicker);
    }

    private void showRunQr() {
        String payload = "RUN|" + runId + "|" + startWallMs;
        showQrPage("START DATA", "Let the STOP phone scan this code. It carries the exact start event timestamp.", payload,
                "BACK TO TIMER", this::showStartTimer);
    }

    private void scanStopSyncQr() {
        launchScanner("Scan the STOP phone's sync QR");
    }

    // ---------------------------------------------------------------------
    // STOP PHONE screens, calibration, and capture
    // ---------------------------------------------------------------------

    private void showStopHome() {
        LinearLayout p = page();
        addHeader(p, "STOP PHONE", "");
        addSpace(p, 32);
        TextView status = label(clockCalibrated
                ? "CLOCK SYNCED  ·  ±" + syncUncertaintyMs + " ms estimated"
                : "CLOCK NOT CALIBRATED", 12, clockCalibrated ? MINT : Color.rgb(224, 184, 118), true);
        p.addView(status, new LinearLayout.LayoutParams(-1, dp(28)));
        addSpace(p, 16);
        p.addView(pillButton("START TIMING", true, this::openCameraAndRecord),
                new LinearLayout.LayoutParams(-1, dp(62)));
        addSpace(p, 14);
        p.addView(pillButton("CALIBRATE PHONES", false, this::showStopSyncQr),
                new LinearLayout.LayoutParams(-1, dp(54)));
        addSpace(p, 12);
        p.addView(pillButton("IMPORT START QR", false, () -> launchScanner("Scan START phone run QR")),
                new LinearLayout.LayoutParams(-1, dp(54)));
        if (importedStartWallMs > 0) {
            addSpace(p, 18);
            p.addView(label("RUN " + importedRunId + " IMPORTED", 11, MINT, true), new LinearLayout.LayoutParams(-1, -2));
        }
        addSpace(p, 18);
        TextView foot = label("Record the run, tap ✓ after the runner passes, then step through frames.", 12, MUTED, false);
        foot.setLineSpacing(dp(3), 1f);
        p.addView(foot, new LinearLayout.LayoutParams(-1, -2));
        addSpace(p, 20);
        TextView change = label("CHANGE PHONE ROLE", 11, MUTED, true);
        change.setOnClickListener(v -> showRolePicker());
        p.addView(change, new LinearLayout.LayoutParams(-1, -2));
        setScreen(p);
    }

    private void showStopSyncQr() {
        syncNonce = UUID.randomUUID().toString().substring(0, 10);
        syncStopT1 = System.currentTimeMillis();
        String payload = "SYNC1|" + syncNonce + "|" + syncStopT1;
        showQrPage("PAIR THE PHONES", "On START PHONE, tap “SYNC WITH STOP PHONE” and scan this code. Then scan its response below.",
                payload, "SCAN START RESPONSE", () -> launchScanner("Scan START phone sync response"));
    }

    private void openCameraAndRecord() {
        if (!hasCameraPermission()) {
            requestCameraPermission();
            return;
        }
        showCameraScreen();
    }

    private void showCameraScreen() {
        FrameLayout screen = new FrameLayout(this);
        screen.setBackgroundColor(Color.BLACK);
        previewView = new PreviewView(this);
        previewView.setImplementationMode(PreviewView.ImplementationMode.PERFORMANCE);
        previewView.setScaleType(PreviewView.ScaleType.FILL_CENTER);
        screen.addView(previewView, new FrameLayout.LayoutParams(-1, -1));
        screen.addView(new FinishLineOverlay(this), new FrameLayout.LayoutParams(-1, -1));

        FrameLayout top = glassPanel();
        TextView recStatus = label("PREPARING CAMERA", 12, Color.WHITE, true);
        recStatus.setLetterSpacing(0.12f);
        recStatus.setPadding(dp(18), dp(14), dp(18), dp(14));
        top.addView(recStatus, new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER));
        FrameLayout.LayoutParams topLp = new FrameLayout.LayoutParams(-1, -2, Gravity.TOP);
        topLp.setMargins(dp(18), dp(20), dp(18), 0);
        screen.addView(top, topLp);

        FrameLayout bottom = glassPanel();
        bottom.setPadding(dp(18), dp(18), dp(18), dp(18));
        View check = glassCheck(() -> stopCurrentRecording());
        FrameLayout.LayoutParams checkLp = new FrameLayout.LayoutParams(dp(76), dp(76), Gravity.CENTER);
        bottom.addView(check, checkLp);
        FrameLayout.LayoutParams bottomLp = new FrameLayout.LayoutParams(-1, dp(112), Gravity.BOTTOM);
        bottomLp.setMargins(dp(18), 0, dp(18), dp(22));
        screen.addView(bottom, bottomLp);
        setScreen(screen);
        bindCameraAndStartRecording(recStatus);
    }

    private void bindCameraAndStartRecording(TextView recStatus) {
        ListenableFuture<ProcessCameraProvider> future = ProcessCameraProvider.getInstance(this);
        future.addListener(() -> {
            try {
                cameraProvider = future.get();
                Preview preview = new Preview.Builder().build();
                preview.setSurfaceProvider(previewView.getSurfaceProvider());
                Recorder recorder = new Recorder.Builder()
                        .setQualitySelector(QualitySelector.fromOrderedList(java.util.Arrays.asList(
                                Quality.UHD, Quality.FHD, Quality.HD, Quality.SD),
                                FallbackStrategy.lowerQualityOrHigherThan(Quality.SD)))
                        .build();
                VideoCapture.Builder<Recorder> captureBuilder = new VideoCapture.Builder<>(recorder);
                // Ask Camera2 for a 60-fps-capable AE range when the rear camera advertises one.
                // Devices without a 60-fps range keep their normal supported frame rate.
                try {
                    android.hardware.camera2.CameraCharacteristics chars =
                            cameraManager.getCameraCharacteristics(cameraId);
                    Range<Integer>[] ranges = chars.get(android.hardware.camera2.CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES);
                    Range<Integer> best = null;
                    if (ranges != null) for (Range<Integer> range : ranges) {
                        if (range.getUpper() >= 60 && (best == null || range.getUpper() > best.getUpper())) best = range;
                    }
                    if (best != null) new Camera2Interop.Extender<>(captureBuilder)
                            .setCaptureRequestOption(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, best);
                } catch (Exception ignored) { }
                videoCapture = captureBuilder.build();
                cameraProvider.unbindAll();
                cameraProvider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, videoCapture);
                handler.postDelayed(() -> startVideoRecording(recStatus), 450L);
            } catch (Exception e) {
                Toast.makeText(this, "Could not open camera: " + e.getMessage(), Toast.LENGTH_LONG).show();
                showStopHome();
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private void startVideoRecording(TextView recStatus) {
        if (videoCapture == null || isFinishing()) return;
        try {
            File dir = getExternalFilesDir(Environment.DIRECTORY_MOVIES);
            if (dir == null) dir = getFilesDir();
            if (!dir.exists()) dir.mkdirs();
            currentVideoFile = new File(dir, "sprint_" + System.currentTimeMillis() + ".mp4");
            FileOutputOptions options = new FileOutputOptions.Builder(currentVideoFile).build();
            PendingRecording pending = videoCapture.getOutput().prepareRecording(this, options);
            recordingFinished = false;
            activeRecording = pending.start(ContextCompat.getMainExecutor(this), event -> {
                if (event instanceof VideoRecordEvent.Start) {
                    videoStartWallMs = System.currentTimeMillis();
                    videoStartElapsedNs = SystemClock.elapsedRealtimeNanos();
                    recStatus.setText("RECORDING");
                } else if (event instanceof VideoRecordEvent.Finalize) {
                    VideoRecordEvent.Finalize f = (VideoRecordEvent.Finalize) event;
                    recordingFinished = true;
                    if (f.hasError()) {
                        Toast.makeText(this, "Video recording failed. Try again.", Toast.LENGTH_LONG).show();
                        showStopHome();
                    } else {
                        openFrameReview();
                    }
                }
            });
        } catch (Exception e) {
            Toast.makeText(this, "Could not start recording: " + e.getMessage(), Toast.LENGTH_LONG).show();
            showStopHome();
        }
    }

    private void stopCurrentRecording() {
        if (activeRecording == null) {
            Toast.makeText(this, "Camera is still preparing.", Toast.LENGTH_SHORT).show();
            return;
        }
        activeRecording.stop();
        activeRecording = null;
    }

    // ---------------------------------------------------------------------
    // Frame-by-frame finish review
    // ---------------------------------------------------------------------

    private void openFrameReview() {
        if (cameraProvider != null) {
            try { cameraProvider.unbindAll(); } catch (Exception ignored) { }
        }
        if (currentVideoFile == null || !currentVideoFile.exists()) {
            Toast.makeText(this, "No recorded video was found.", Toast.LENGTH_LONG).show();
            showStopHome();
            return;
        }
        if (retriever != null) {
            try { retriever.release(); } catch (Exception ignored) { }
        }
        retriever = new MediaMetadataRetriever();
        try {
            retriever.setDataSource(currentVideoFile.getAbsolutePath());
            String dur = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            videoDurationMs = dur == null ? 0L : Long.parseLong(dur);
            String fps = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_CAPTURE_FRAMERATE);
            if (fps != null) frameRate = Math.max(15f, Math.min(120f, Float.parseFloat(fps)));
        } catch (Exception e) {
            videoDurationMs = Math.max(0, (SystemClock.elapsedRealtimeNanos() - videoStartElapsedNs) / 1_000_000L);
            frameRate = 30f;
        }
        frameCount = Math.max(1, (int) Math.ceil(videoDurationMs * frameRate / 1000f));
        frameIndex = Math.max(0, frameCount - 1);
        showFrameReview();
        loadReviewFrame(frameIndex);
    }

    private void showFrameReview() {
        LinearLayout p = page();
        addHeader(p, "PHOTO FINISH", "Move frame by frame. Choose the frame where the runner's chest first touches the white line.");
        addSpace(p, 18);

        FrameLayout imageShell = new FrameLayout(this);
        imageShell.setBackground(ovalBackground(new int[]{Color.rgb(18, 25, 33), Color.rgb(8, 12, 17)}, 0x88758C9E, 1));
        imageShell.setClipToOutline(true);
        imageShell.setOutlineProvider(ViewOutlineProvider.BACKGROUND);
        reviewImage = new ImageView(this);
        reviewImage.setScaleType(ImageView.ScaleType.FIT_CENTER);
        imageShell.addView(reviewImage, new FrameLayout.LayoutParams(-1, -1));
        imageShell.addView(new FinishLineOverlay(this), new FrameLayout.LayoutParams(-1, -1));
        LinearLayout.LayoutParams imageLp = new LinearLayout.LayoutParams(dp(292), dp(292));
        imageLp.gravity = Gravity.CENTER_HORIZONTAL;
        imageLp.bottomMargin = dp(15);
        p.addView(imageShell, imageLp);

        reviewTimestamp = label("00:00.000", 25, MINT, true);
        p.addView(reviewTimestamp, new LinearLayout.LayoutParams(-1, dp(38)));
        addSpace(p, 7);

        reviewSeek = new SeekBar(this);
        reviewSeek.setMax(Math.max(1, frameCount - 1));
        reviewSeek.setProgress(frameIndex);
        reviewSeek.setProgressTintList(android.content.res.ColorStateList.valueOf(MINT));
        reviewSeek.setThumbTintList(android.content.res.ColorStateList.valueOf(Color.WHITE));
        reviewSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser && !ignoreSeekCallback) setReviewFrame(progress);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        });
        p.addView(reviewSeek, new LinearLayout.LayoutParams(-1, dp(36)));

        LinearLayout controls = new LinearLayout(this);
        controls.setGravity(Gravity.CENTER);
        TextView prev = pillButton("‹  PREV", false, () -> setReviewFrame(Math.max(0, frameIndex - 1)));
        TextView next = pillButton("NEXT  ›", false, () -> setReviewFrame(Math.min(frameCount - 1, frameIndex + 1)));
        LinearLayout.LayoutParams ctrl = new LinearLayout.LayoutParams(0, dp(48), 1f);
        ctrl.setMargins(dp(4), dp(4), dp(4), dp(4));
        controls.addView(prev, ctrl);
        controls.addView(next, ctrl);
        p.addView(controls, new LinearLayout.LayoutParams(-1, dp(58)));
        addSpace(p, 10);
        p.addView(pillButton("USE THIS FRAME", true, this::showFinishResult), new LinearLayout.LayoutParams(-1, dp(54)));
        addSpace(p, 8);
        p.addView(pillButton("SCAN START QR", false, () -> launchScanner("Scan START phone run QR")),
                new LinearLayout.LayoutParams(-1, dp(48)));
        setScreen(p);
        // Seek bar listener can be used after the view is attached.
        if (reviewSeek != null) reviewSeek.setProgress(frameIndex);
    }

    private void setReviewFrame(int index) {
        frameIndex = Math.max(0, Math.min(frameCount - 1, index));
        long ms = Math.round(frameIndex * 1000f / frameRate);
        if (reviewTimestamp != null) reviewTimestamp.setText(formatMillis(ms));
        if (reviewSeek != null) {
            ignoreSeekCallback = true;
            reviewSeek.setProgress(frameIndex);
            ignoreSeekCallback = false;
        }
        loadReviewFrame(frameIndex);
    }

    private void loadReviewFrame(int index) {
        if (retriever == null) return;
        final long timeUs = Math.max(0L, Math.round(index * 1_000_000f / frameRate));
        frameExecutor.execute(() -> {
            Bitmap bitmap = null;
            try { bitmap = retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST); }
            catch (Exception ignored) { }
            final Bitmap result = bitmap;
            runOnUiThread(() -> {
                if (reviewImage != null && result != null) reviewImage.setImageBitmap(result);
            });
        });
    }

    private void showFinishResult() {
        long finishOffsetMs = Math.round(frameIndex * 1000f / frameRate);
        long finishStopWall = videoStartWallMs + finishOffsetMs;
        boolean hasStart = importedStartWallMs > 0L;
        long elapsedMs = hasStart
                ? finishStopWall - (importedStartWallMs - clockOffsetStartMinusStopMs)
                : -1L;

        LinearLayout p = page();
        addHeader(p, "FINISH SELECTED", "Frame timestamp from the recorded finish-line video.");
        addSpace(p, 56);
        TextView stamp = label(formatMillis(finishOffsetMs), 40, MINT, true);
        p.addView(stamp, new LinearLayout.LayoutParams(-1, dp(70)));
        addSpace(p, 15);
        if (hasStart) {
            p.addView(label(formatMillis(elapsedMs), 34, Color.WHITE, true), new LinearLayout.LayoutParams(-1, dp(60)));
            p.addView(label("SPRINT TIME", 11, MUTED, true), new LinearLayout.LayoutParams(-1, dp(25)));
            addSpace(p, 24);
            p.addView(label("RUN " + importedRunId, 12, MUTED, true), new LinearLayout.LayoutParams(-1, -2));
            if (clockCalibrated) {
                addSpace(p, 10);
                p.addView(label("CLOCK OFFSET " + signed(clockOffsetStartMinusStopMs) + " ms  ·  EST. ±" + syncUncertaintyMs + " ms",
                        10, MUTED, false), new LinearLayout.LayoutParams(-1, -2));
            } else {
                addSpace(p, 10);
                p.addView(label("UN-CALIBRATED: phones are assumed to have matching clocks.", 11,
                        Color.rgb(224, 184, 118), false), new LinearLayout.LayoutParams(-1, -2));
            }
        } else {
            p.addView(label("Scan the START phone's QR to calculate the sprint time.", 14, Color.WHITE, false),
                    new LinearLayout.LayoutParams(-1, -2));
            addSpace(p, 18);
            p.addView(pillButton("IMPORT START QR", true, () -> launchScanner("Scan START phone run QR")),
                    new LinearLayout.LayoutParams(-1, dp(54)));
        }
        addSpace(p, 38);
        p.addView(pillButton("DONE", false, this::showStopHome), new LinearLayout.LayoutParams(-1, dp(52)));
        setScreen(p);
    }

    private void loadCalibration() {
        SharedPreferences prefs = getSharedPreferences("sprintclock", MODE_PRIVATE);
        clockCalibrated = prefs.getBoolean("clock_calibrated", false);
        clockOffsetStartMinusStopMs = prefs.getLong("clock_offset_ms", 0L);
        syncUncertaintyMs = prefs.getLong("sync_uncertainty_ms", -1L);
    }

    private void saveCalibration() {
        getSharedPreferences("sprintclock", MODE_PRIVATE).edit()
                .putBoolean("clock_calibrated", true)
                .putLong("clock_offset_ms", clockOffsetStartMinusStopMs)
                .putLong("sync_uncertainty_ms", syncUncertaintyMs)
                .apply();
    }

    // ---------------------------------------------------------------------
    // QR screens, scanner and payload handling
    // ---------------------------------------------------------------------

    private void showQrPage(String title, String description, String payload, String buttonText, Runnable action) {
        LinearLayout p = page();
        p.setPadding(dp(22), dp(26), dp(22), dp(22));
        addHeader(p, title, description);
        addSpace(p, 30);
        FrameLayout qrPanel = glassPanel();
        qrPanel.setPadding(dp(18), dp(18), dp(18), dp(18));
        ImageView image = new ImageView(this);
        image.setImageBitmap(makeQr(payload, 720));
        image.setBackground(rounded(new int[]{Color.WHITE, Color.WHITE}, 14, 0x88FFFFFF, 1));
        image.setPadding(dp(12), dp(12), dp(12), dp(12));
        qrPanel.addView(image, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout.LayoutParams qlp = new LinearLayout.LayoutParams(dp(276), dp(276));
        qlp.gravity = Gravity.CENTER_HORIZONTAL;
        p.addView(qrPanel, qlp);
        addSpace(p, 24);
        p.addView(pillButton(buttonText, true, action), new LinearLayout.LayoutParams(-1, dp(54)));
        addSpace(p, 8);
        TextView back = label("BACK", 11, MUTED, true);
        back.setPadding(0, dp(12), 0, dp(12));
        back.setOnClickListener(v -> { if (role == Role.START) showStartHome(); else showStopHome(); });
        p.addView(back, new LinearLayout.LayoutParams(-1, -2));
        setScreen(p);
    }

    private Bitmap makeQr(String payload, int size) {
        try {
            Map<EncodeHintType, Object> hints = new EnumMap<>(EncodeHintType.class);
            hints.put(EncodeHintType.MARGIN, 1);
            BitMatrix matrix = new MultiFormatWriter().encode(payload, BarcodeFormat.QR_CODE, size, size, hints);
            Bitmap bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
            for (int y = 0; y < size; y++) {
                for (int x = 0; x < size; x++) bmp.setPixel(x, y, matrix.get(x, y) ? Color.BLACK : Color.WHITE);
            }
            return bmp;
        } catch (Exception e) { return Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888); }
    }

    private void launchScanner(String prompt) {
        ScanOptions options = new ScanOptions();
        options.setDesiredBarcodeFormats(Collections.singletonList("QR_CODE"));
        options.setCaptureActivity(SprintScannerActivity.class);
        options.setPrompt(prompt);
        options.setCameraId(0);
        options.setBeepEnabled(false);
        options.setOrientationLocked(true);
        scanLauncher.launch(options);
    }

    private void handleQrPayload(String payload) {
        try {
            String[] parts = payload.split("\\|");
            if (parts.length == 3 && "SYNC1".equals(parts[0]) && role == Role.START) {
                String nonce = parts[1];
                long t1 = Long.parseLong(parts[2]);
                long t2 = System.currentTimeMillis();
                long t3 = System.currentTimeMillis();
                String response = "SYNC2|" + nonce + "|" + t1 + "|" + t2 + "|" + t3;
                showQrPage("SYNC RESPONSE", "Now let the STOP phone scan this response. That phone calculates and stores the clock difference.",
                        response, "DONE", this::showStartHome);
                return;
            }
            if (parts.length == 5 && "SYNC2".equals(parts[0]) && role == Role.STOP) {
                String nonce = parts[1];
                if (!syncNonce.isEmpty() && !syncNonce.equals(nonce)) {
                    Toast.makeText(this, "This QR belongs to a different pairing attempt.", Toast.LENGTH_LONG).show();
                    return;
                }
                long t1 = Long.parseLong(parts[2]);
                long t2 = Long.parseLong(parts[3]);
                long t3 = Long.parseLong(parts[4]);
                long t4 = System.currentTimeMillis();
                clockOffsetStartMinusStopMs = Math.round(((t2 - t1) + (t3 - t4)) / 2.0);
                long rtt = Math.max(0L, (t4 - t1) - (t3 - t2));
                syncUncertaintyMs = Math.round(rtt / 2.0);
                clockCalibrated = true;
                saveCalibration();
                Toast.makeText(this, "Phones synced. Estimated uncertainty ±" + syncUncertaintyMs + " ms", Toast.LENGTH_LONG).show();
                showStopHome();
                return;
            }
            if (parts.length == 3 && "RUN".equals(parts[0]) && role == Role.STOP) {
                importedRunId = parts[1];
                importedStartWallMs = Long.parseLong(parts[2]);
                Toast.makeText(this, "Start data imported.", Toast.LENGTH_SHORT).show();
                if (recordingFinished && currentVideoFile != null && currentVideoFile.exists()) {
                    showFinishResult();
                } else {
                    showStopHome();
                }
                return;
            }
            Toast.makeText(this, "That QR code is not for this screen.", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Could not read SprintClock QR data.", Toast.LENGTH_LONG).show();
        }
    }

    // ---------------------------------------------------------------------
    // Camera permissions, flash, and small utilities
    // ---------------------------------------------------------------------

    private boolean hasCameraPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestCameraPermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, REQUEST_CAMERA);
    }

    @Override public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CAMERA && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            if (role == Role.STOP) showStopHome();
            else Toast.makeText(this, "Camera access enabled. Tap START TIMING again.", Toast.LENGTH_SHORT).show();
        }
    }

    private void setTorch(boolean enabled) {
        if (cameraId == null || cameraManager == null) return;
        try {
            cameraManager.setTorchMode(cameraId, enabled);
            torchOn = enabled;
        } catch (Exception e) {
            // Flash may be unavailable or temporarily busy with another camera operation.
        }
    }

    private String formatDurationNanos(long nanos) {
        long millis = Math.max(0L, nanos / 1_000_000L);
        return formatMillis(millis);
    }

    private String formatMillis(long millis) {
        if (millis < 0) return "—";
        long minutes = millis / 60000L;
        long seconds = (millis % 60000L) / 1000L;
        long ms = millis % 1000L;
        return String.format(Locale.US, "%02d:%02d.%03d", minutes, seconds, ms);
    }

    private String signed(long value) { return (value >= 0 ? "+" : "") + value; }

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    @Override public void onBackPressed() {
        if (role == Role.START) {
            handler.removeCallbacks(timerTicker);
            setTorch(false);
            showStartHome();
        } else if (role == Role.STOP) {
            if (activeRecording != null) {
                Toast.makeText(this, "Tap ✓ to stop and review the video.", Toast.LENGTH_SHORT).show();
            } else if (reviewImage != null) {
                showStopHome();
            } else {
                showStopHome();
            }
        } else {
            showRolePicker();
        }
    }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        setTorch(false);
        if (soundPool != null) soundPool.release();
        if (retriever != null) {
            try { retriever.release(); } catch (Exception ignored) { }
        }
        frameExecutor.shutdown();
        super.onDestroy();
    }

    /** Draws the vertical finish reference line over the camera or selected frame. */
    private class FinishLineOverlay extends View {
        private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
        FinishLineOverlay(Context context) {
            super(context);
            line.setColor(Color.WHITE);
            line.setStrokeWidth(dp(2));
            line.setStyle(Paint.Style.STROKE);
            glow.setColor(0x33FFFFFF);
            glow.setStrokeWidth(dp(8));
            glow.setStyle(Paint.Style.STROKE);
            setBackgroundColor(Color.TRANSPARENT);
        }
        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float x = getWidth() * 0.50f;
            canvas.drawLine(x, getHeight() * 0.06f, x, getHeight() * 0.94f, glow);
            canvas.drawLine(x, getHeight() * 0.06f, x, getHeight() * 0.94f, line);
        }
    }
}
