import 'package:flutter_test/flutter_test.dart';
import 'package:sprint_timer/main.dart';

void main() {
  testWidgets('Role select shows START and STOP', (tester) async {
    await tester.pumpWidget(const SprintTimerApp());
    expect(find.text('START PHONE'), findsOneWidget);
    expect(find.text('STOP PHONE'), findsOneWidget);
  });
}
