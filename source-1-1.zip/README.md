# Sprint Timer

Two-phone **100-meter sprint timing** system for Android (Flutter).

## Roles

| Role | Placement | Job |
|------|-----------|-----|
| **START PHONE** | Starting line | Random 0–6 s delay → gun sound + flashlight → locks high-resolution start timestamp |
| **STOP PHONE** | Finish line | Live camera with center guide → mark when chest crosses → frame-by-frame pick → locks frame capture timestamp |

Phones then **SYNC** over Bluetooth, estimate **clock offset**, exchange timestamps, and show the same **result**.

## Accuracy notes

- Start stamp is taken at the moment the bang/torch fire, not when the prepare screen opens.
- Finish stamp is the estimated capture time of the selected frame, not the confirm-button press.
- BLE clock sync uses multi-sample ping/pong (NTP-style). Uncertainty is reported on the result screen.
- Continuous true circular raw-frame buffers need deeper native CameraX work; this build uses rolling video segments + frame timeline stamps as a practical mobile approach.

## Build APK

```bash
flutter pub get
flutter build apk --release
```

Or zip this project as `source.zip` and use the GitHub Actions workflow.

## Single-device testing

On the SYNC screen, use **Simulate pair** to walk through the UI without a second phone. A synthetic remote timestamp is used so a demo result appears.

## Permissions

Camera, flashlight, Bluetooth (scan/connect/advertise), and location (legacy Android BT scan).

## Appearance and interaction updates

- Help alerts use a responsive iOS-inspired layout with iOS blue actions.
- App controls share a frosted-glass surface with backdrop blur, edge highlights, and restrained press feedback.
- Settings supports System, Light, and Dark appearance modes; the selection is saved between launches.
- Screen transitions and help alerts use short fade/scale animations.

## Build with GitHub Actions

The included `.github/workflows/build-apk.yml` builds a release APK on pushes to `main` or when manually started from the Actions tab. Download `sprint-timer-release-apk` from the completed workflow run.
