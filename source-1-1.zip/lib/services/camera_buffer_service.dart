import 'dart:async';
import 'dart:collection';

import 'package:camera/camera.dart';
import 'package:flutter/foundation.dart';

/// Rolling capture metadata for finish-line frame selection.
///
/// Continuous video into a true circular buffer of raw frames is limited on
/// mobile without custom native code. This service:
/// 1. Opens the rear camera at the highest practical FPS the device reports.
/// 2. Continuously records short overlapping segments so ~3 s of pre-roll
///    can be recovered when the user taps the mark button.
/// 3. Continues for 3 s after the mark, then finalizes a ~6 s clip.
/// 4. Stores per-frame approximate capture times for the review UI.
class CameraBufferService {
  CameraController? controller;
  List<CameraDescription> cameras = [];

  final ListQueue<_Segment> _segments = ListQueue();
  static const Duration preRoll = Duration(seconds: 3);
  static const Duration postRoll = Duration(seconds: 3);
  static const Duration segmentLength = Duration(milliseconds: 1500);

  bool _rolling = false;
  bool _finalizing = false;
  DateTime? markWallTime;
  int? markMonoMicros;
  String? finalizedPath;
  double reportedFps = 30;
  final List<FrameStamp> frameStamps = [];

  Future<void> initialize() async {
    cameras = await availableCameras();
    final rear = cameras.firstWhere(
      (c) => c.lensDirection == CameraLensDirection.back,
      orElse: () => cameras.first,
    );

    // Highest practical preset; device-reported FPS is read after init.
    controller = CameraController(
      rear,
      ResolutionPreset.high,
      enableAudio: false,
    );

    try {
      await controller!.initialize();
      // Platform-accurate FPS needs CameraX/native; 30 is a safe default.
      reportedFps = 30;
    } catch (e) {
      debugPrint('Camera init failed: $e');
      rethrow;
    }
  }

  Future<void> startRollingBuffer() async {
    if (_rolling || controller == null) return;
    _rolling = true;
    unawaited(_rollLoop());
  }

  Future<void> _rollLoop() async {
    while (_rolling && !_finalizing) {
      try {
        final start = DateTime.now();
        await controller!.startVideoRecording();
        await Future<void>.delayed(segmentLength);
        if (!_rolling) break;
        final path = await controller!.stopVideoRecording();
        final end = DateTime.now();
        _segments.add(_Segment(path: path.path, start: start, end: end));
        while (_segments.length > 6) {
          _segments.removeFirst();
        }
        debugPrint(
          'Buffered segment ${path.path} (${end.difference(start).inMilliseconds} ms)',
        );
      } catch (e) {
        debugPrint('Roll segment error: $e');
        await Future<void>.delayed(const Duration(milliseconds: 200));
      }
    }
  }

  /// User pressed the finish mark. Capture post-roll then finalize.
  Future<String?> markAndFinalize({
    required int Function() monoNow,
  }) async {
    if (controller == null || _finalizing) return null;
    _finalizing = true;
    markWallTime = DateTime.now();
    markMonoMicros = monoNow();

    // Finish current segment if recording.
    try {
      if (controller!.value.isRecordingVideo) {
        final path = await controller!.stopVideoRecording();
        final now = DateTime.now();
        _segments.add(_Segment(
          path: path.path,
          start: markWallTime!.subtract(segmentLength),
          end: now,
        ));
      }
    } catch (e) {
      debugPrint('Stop current segment: $e');
    }

    // Post-roll continuous recording.
    try {
      await controller!.startVideoRecording();
      await Future<void>.delayed(postRoll);
      final post = await controller!.stopVideoRecording();
      final end = DateTime.now();
      _segments.add(_Segment(
        path: post.path,
        start: markWallTime!,
        end: end,
      ));
    } catch (e) {
      debugPrint('Post-roll error: $e');
    }

    _rolling = false;
    _finalizing = false;

    // Prefer the segment that covers the mark instant; otherwise last segment.
    final chosen = _segments.isEmpty
        ? null
        : _segments.lastWhere(
            (s) =>
                !s.end.isBefore(markWallTime!) &&
                !s.start.isAfter(markWallTime!),
            orElse: () => _segments.last,
          );

    finalizedPath = chosen?.path;
    _buildFrameStamps(chosen);
    return finalizedPath;
  }

  void _buildFrameStamps(_Segment? segment) {
    frameStamps.clear();
    if (segment == null || markWallTime == null) return;
    final fps = reportedFps > 0 ? reportedFps : 30.0;
    final durationMs = segment.end.difference(segment.start).inMilliseconds;
    final totalFrames = (durationMs / 1000.0 * fps).round().clamp(1, 2000);
    for (var i = 0; i < totalFrames; i++) {
      final t = segment.start.add(
        Duration(microseconds: (i / fps * 1e6).round()),
      );
      frameStamps.add(FrameStamp(
        index: i,
        wallMicros: t.microsecondsSinceEpoch,
        relativeSeconds: i / fps,
      ));
    }
  }

  /// Wall-clock micros for a selected frame (original capture estimate).
  int? captureWallMicrosForFrame(int index) {
    if (index < 0 || index >= frameStamps.length) return null;
    return frameStamps[index].wallMicros;
  }

  Future<void> dispose() async {
    _rolling = false;
    try {
      if (controller?.value.isRecordingVideo == true) {
        await controller?.stopVideoRecording();
      }
    } catch (_) {}
    await controller?.dispose();
    controller = null;
  }
}

class _Segment {
  _Segment({required this.path, required this.start, required this.end});
  final String path;
  final DateTime start;
  final DateTime end;
}

class FrameStamp {
  FrameStamp({
    required this.index,
    required this.wallMicros,
    required this.relativeSeconds,
  });
  final int index;
  final int wallMicros;
  final double relativeSeconds;
}
