import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:nearby_connections/nearby_connections.dart';
import 'package:permission_handler/permission_handler.dart';

import '../models/timing_data.dart';
import '../utils/precision_clock.dart';

enum SyncPhase { idle, hosting, joining, connected }

/// Phone-to-phone link via Google Nearby Connections.
class NearbySyncService {
  NearbySyncService({PrecisionClock? clock}) : _clock = clock ?? PrecisionClock();

  final PrecisionClock _clock;
  final Nearby _nearby = Nearby();
  static const String serviceId = 'com.sprinttimer.link';

  SyncPhase phase = SyncPhase.idle;
  String sessionCode = '';
  String peerName = '';
  String? error;
  bool online = false;
  String? _peerId;

  TimingData? localTiming;
  TimingData? remoteTiming;
  ClockSyncResult? clockSync;

  final _phaseCtrl = StreamController<SyncPhase>.broadcast();
  Stream<SyncPhase> get onPhase => _phaseCtrl.stream;

  final _msgCtrl = StreamController<Map<String, dynamic>>.broadcast();
  Stream<Map<String, dynamic>> get onMessage => _msgCtrl.stream;

  String generateSessionCode() {
    sessionCode =
        (1000 + DateTime.now().millisecondsSinceEpoch % 9000).toString();
    return sessionCode;
  }

  Future<void> requestPermissions() async {
    await [
      Permission.bluetooth,
      Permission.bluetoothAdvertise,
      Permission.bluetoothConnect,
      Permission.bluetoothScan,
      Permission.locationWhenInUse,
      Permission.nearbyWifiDevices,
    ].request();
  }

  Future<void> host({required String deviceName}) async {
    await stop();
    await requestPermissions();
    phase = SyncPhase.hosting;
    _phaseCtrl.add(phase);
    error = null;
    try {
      final ok = await _nearby.startAdvertising(
        deviceName,
        Strategy.P2P_POINT_TO_POINT,
        onConnectionInitiated: _onInitiated,
        onConnectionResult: _onResult,
        onDisconnected: _onDisconnected,
        serviceId: serviceId,
      );
      if (!ok) {
        error = 'Could not start hosting';
        phase = SyncPhase.idle;
        _phaseCtrl.add(phase);
      }
    } catch (e) {
      error = e.toString();
      phase = SyncPhase.idle;
      _phaseCtrl.add(phase);
      debugPrint('host error: $e');
    }
  }

  Future<void> join({required String deviceName}) async {
    await stop();
    await requestPermissions();
    phase = SyncPhase.joining;
    _phaseCtrl.add(phase);
    error = null;
    try {
      final ok = await _nearby.startDiscovery(
        deviceName,
        Strategy.P2P_POINT_TO_POINT,
        onEndpointFound: (id, name, sid) async {
          debugPrint('found $name ($id)');
          try {
            await _nearby.requestConnection(
              deviceName,
              id,
              onConnectionInitiated: _onInitiated,
              onConnectionResult: _onResult,
              onDisconnected: _onDisconnected,
            );
          } catch (e) {
            debugPrint('requestConnection: $e');
          }
        },
        onEndpointLost: (_) {},
        serviceId: serviceId,
      );
      if (!ok) {
        error = 'Could not start discovery';
        phase = SyncPhase.idle;
        _phaseCtrl.add(phase);
      }
    } catch (e) {
      error = e.toString();
      phase = SyncPhase.idle;
      _phaseCtrl.add(phase);
      debugPrint('join error: $e');
    }
  }

  void _onInitiated(String id, ConnectionInfo info) {
    peerName = info.endpointName;
    _peerId = id;
    _nearby.acceptConnection(
      id,
      onPayLoadRecieved: (endid, payload) {
        if (payload.type == PayloadType.BYTES && payload.bytes != null) {
          _handleBytes(payload.bytes!);
        }
      },
      onPayloadTransferUpdate: (_, __) {},
    );
  }

  void _onResult(String id, Status status) {
    _peerId = id;
    if (status == Status.CONNECTED) {
      online = true;
      phase = SyncPhase.connected;
      _phaseCtrl.add(phase);
      _nearby.stopAdvertising();
      _nearby.stopDiscovery();
      sendJson({
        'type': 'hello',
        'sessionCode': sessionCode,
        'role': localTiming?.role,
      });
    } else {
      error = 'Connection failed';
      online = false;
      phase = SyncPhase.idle;
      _phaseCtrl.add(phase);
    }
  }

  void _onDisconnected(String id) {
    online = false;
    if (phase == SyncPhase.connected) {
      phase = SyncPhase.idle;
      _phaseCtrl.add(phase);
    }
  }

  void _handleBytes(Uint8List bytes) {
    try {
      final map = jsonDecode(utf8.decode(bytes)) as Map<String, dynamic>;
      _msgCtrl.add(map);
      final type = map['type'];
      if (type == 'hello') {
        final remoteCode = map['sessionCode'] as String?;
        if (remoteCode != null && remoteCode.isNotEmpty && sessionCode.isEmpty) {
          sessionCode = remoteCode;
        }
      } else if (type == 'timing') {
        remoteTiming =
            TimingData.fromJson(map['payload'] as Map<String, dynamic>);
      } else if (type == 'ping') {
        final t2 = _clock.wallClockMicros;
        final t3 = _clock.wallClockMicros;
        sendJson({'type': 'pong', 'id': map['id'], 't2': t2, 't3': t3});
      }
    } catch (e) {
      debugPrint('payload parse: $e');
    }
  }

  Future<void> sendJson(Map<String, dynamic> map) async {
    final bytes = Uint8List.fromList(utf8.encode(jsonEncode(map)));
    if (_peerId == null) return;
    try {
      await _nearby.sendBytesPayload(_peerId!, bytes);
    } catch (e) {
      debugPrint('sendJson: $e');
    }
  }

  Future<void> sendTiming(TimingData data) async {
    localTiming = data;
    await sendJson({'type': 'timing', 'payload': data.toJson()});
  }

  Future<ClockSyncResult> estimateClockOffset({int samples = 8}) async {
    final offsets = <int>[];
    final rtts = <int>[];
    for (var i = 0; i < samples; i++) {
      final t1 = _clock.wallClockMicros;
      final id = 'p$i-${DateTime.now().microsecondsSinceEpoch}';
      final completer = Completer<Map<String, dynamic>>();
      late StreamSubscription sub;
      sub = onMessage.listen((m) {
        if (m['type'] == 'pong' && m['id'] == id && !completer.isCompleted) {
          completer.complete(m);
        }
      });
      await sendJson({'type': 'ping', 'id': id, 't1': t1});
      Map<String, dynamic>? pong;
      try {
        pong = await completer.future.timeout(const Duration(seconds: 2));
      } catch (_) {}
      await sub.cancel();
      if (pong == null) continue;
      final t4 = _clock.wallClockMicros;
      final t2 = (pong['t2'] as num).toInt();
      final t3 = (pong['t3'] as num).toInt();
      offsets.add(((t2 - t1) + (t3 - t4)) ~/ 2);
      rtts.add((t4 - t1) - (t3 - t2));
      await Future<void>.delayed(const Duration(milliseconds: 30));
    }
    if (offsets.isEmpty) {
      clockSync = ClockSyncResult(
        offsetMicros: 0,
        rttMicros: 0,
        uncertaintyMicros: 30000,
        samples: 0,
      );
      return clockSync!;
    }
    offsets.sort();
    rtts.sort();
    final mid = offsets.length ~/ 2;
    clockSync = ClockSyncResult(
      offsetMicros: offsets[mid],
      rttMicros: rtts[mid],
      uncertaintyMicros:
          ((offsets.last - offsets.first) ~/ 2).clamp(500, 200000) +
              rtts[mid] ~/ 2,
      samples: offsets.length,
    );
    return clockSync!;
  }

  SprintResult? computeResult({required bool localIsStart}) {
    final start = localIsStart ? localTiming : remoteTiming;
    final finish = localIsStart ? remoteTiming : localTiming;
    final sync = clockSync;
    if (start == null || finish == null || sync == null) return null;
    if (start.role != 'start' || finish.role != 'stop') return null;

    int align(TimingData t, bool isLocal) {
      if (isLocal) return t.wallClockMicros;
      return t.wallClockMicros - sync.offsetMicros;
    }

    final startAligned = align(start, localIsStart);
    final finishAligned = align(finish, !localIsStart);
    final delta = finishAligned - startAligned;
    final unc = (sync.uncertaintyMicros +
            (start.uncertaintyMicros ?? 0) +
            (finish.uncertaintyMicros ?? 1000)) /
        1e6;

    return SprintResult(
      timeSeconds: delta / 1e6,
      uncertaintySeconds: unc,
      sessionCode: sessionCode.isNotEmpty ? sessionCode : start.sessionId,
      startWallMicros: startAligned,
      finishWallMicros: finishAligned,
      clockOffsetMicros: sync.offsetMicros,
    );
  }

  Future<void> stop() async {
    try {
      await _nearby.stopAdvertising();
    } catch (_) {}
    try {
      await _nearby.stopDiscovery();
    } catch (_) {}
    try {
      await _nearby.stopAllEndpoints();
    } catch (_) {}
    online = false;
    phase = SyncPhase.idle;
    _peerId = null;
  }

  Future<void> dispose() async {
    await stop();
    await _phaseCtrl.close();
    await _msgCtrl.close();
  }
}
