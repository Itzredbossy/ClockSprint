import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SettingsService extends ChangeNotifier {
  static const _kPopups = 'help_popups_enabled';
  static const _kHaptics = 'haptics_enabled';

  bool helpPopupsEnabled = true;
  bool hapticsEnabled = true;
  bool _loaded = false;

  Future<void> load() async {
    if (_loaded) return;
    final p = await SharedPreferences.getInstance();
    helpPopupsEnabled = p.getBool(_kPopups) ?? true;
    hapticsEnabled = p.getBool(_kHaptics) ?? true;
    _loaded = true;
    notifyListeners();
  }

  Future<void> setHelpPopups(bool v) async {
    helpPopupsEnabled = v;
    final p = await SharedPreferences.getInstance();
    await p.setBool(_kPopups, v);
    notifyListeners();
  }

  Future<void> setHaptics(bool v) async {
    hapticsEnabled = v;
    final p = await SharedPreferences.getInstance();
    await p.setBool(_kHaptics, v);
    notifyListeners();
  }
}
