import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SettingsService extends ChangeNotifier {
  static const _kPopups = 'help_popups_enabled';
  static const _kHaptics = 'haptics_enabled';
  static const _kThemeMode = 'appearance_theme_mode';

  bool helpPopupsEnabled = true;
  bool hapticsEnabled = true;
  ThemeMode themeMode = ThemeMode.system;
  bool _loaded = false;

  Future<void> load() async {
    if (_loaded) return;
    final p = await SharedPreferences.getInstance();
    helpPopupsEnabled = p.getBool(_kPopups) ?? true;
    hapticsEnabled = p.getBool(_kHaptics) ?? true;
    final savedMode = p.getString(_kThemeMode) ?? 'system';
    themeMode = switch (savedMode) {
      'light' => ThemeMode.light,
      'dark' => ThemeMode.dark,
      _ => ThemeMode.system,
    };
    _loaded = true;
    notifyListeners();
  }

  Future<void> setHelpPopups(bool value) async {
    helpPopupsEnabled = value;
    final p = await SharedPreferences.getInstance();
    await p.setBool(_kPopups, value);
    notifyListeners();
  }

  Future<void> setHaptics(bool value) async {
    hapticsEnabled = value;
    final p = await SharedPreferences.getInstance();
    await p.setBool(_kHaptics, value);
    notifyListeners();
  }

  Future<void> setThemeMode(ThemeMode value) async {
    themeMode = value;
    final p = await SharedPreferences.getInstance();
    final name = switch (value) {
      ThemeMode.light => 'light',
      ThemeMode.dark => 'dark',
      ThemeMode.system => 'system',
    };
    await p.setString(_kThemeMode, name);
    notifyListeners();
  }
}
