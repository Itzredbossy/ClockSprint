import 'dart:async';
import 'dart:math';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/foundation.dart';
import 'package:torch_light/torch_light.dart';

import '../utils/precision_clock.dart';

/// Handles random delay, preloaded gun sound, flashlight, and precise start stamp.
class StartSignalService {
  StartSignalService({PrecisionClock? clock})
      : _clock = clock ?? PrecisionClock();

  final PrecisionClock _clock;
  final AudioPlayer _player = AudioPlayer();
  final Random _rng = Random.secure();

  bool _preloaded = false;
  int? startMonotonicMicros;
  int? startWallMicros;

  Future<void> preload() async {
    if (_preloaded) return;
    try {
      await _player.setReleaseMode(ReleaseMode.stop);
      await _player.setSource(AssetSource('sounds/start_bang.wav'));
      await _player.setVolume(1.0);
      _preloaded = true;
    } catch (e) {
      debugPrint('Audio preload failed: $e');
    }
  }

  /// Random wait 0–6 s, then fire bang + torch and stamp the start time.
  Future<void> armAndFire({
    void Function(Duration remaining)? onTick,
  }) async {
    await preload();
    final delayMs = _rng.nextInt(6001); // 0..6000 inclusive
    final end = DateTime.now().add(Duration(milliseconds: delayMs));

    while (DateTime.now().isBefore(end)) {
      final left = end.difference(DateTime.now());
      onTick?.call(left.isNegative ? Duration.zero : left);
      await Future<void>.delayed(const Duration(milliseconds: 50));
    }
    onTick?.call(Duration.zero);

    // Fire signal as simultaneously as the platform allows.
    final sample = _clock.sample();
    startMonotonicMicros = sample.mono;
    startWallMicros = sample.wall;

    // Kick audio and torch without awaiting each other first.
    final audioFuture =
        _player.play(AssetSource('sounds/start_bang.wav')).catchError((Object e) {
      debugPrint('Audio play error: $e');
    });
    final torchFuture = _flashTorch();

    await Future.wait([audioFuture, torchFuture]);
  }

  Future<void> _flashTorch() async {
    try {
      final available = await TorchLight.isTorchAvailable();
      if (!available) return;
      await TorchLight.enableTorch();
      await Future<void>.delayed(const Duration(milliseconds: 250));
      await TorchLight.disableTorch();
    } catch (e) {
      debugPrint('Torch error: $e');
    }
  }

  Future<void> dispose() async {
    try {
      await TorchLight.disableTorch();
    } catch (_) {}
    await _player.dispose();
  }
}
