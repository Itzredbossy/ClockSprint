/// High-precision timing payload exchanged over BLE.
class TimingData {
  TimingData({
    required this.role,
    required this.sessionId,
    required this.monotonicMicros,
    required this.wallClockMicros,
    this.frameIndex,
    this.frameRate,
    this.uncertaintyMicros,
  });

  final String role; // 'start' | 'stop'
  final String sessionId;
  /// Monotonic / high-resolution capture instant (microseconds).
  final int monotonicMicros;
  /// Wall-clock epoch microseconds at capture.
  final int wallClockMicros;
  final int? frameIndex;
  final double? frameRate;
  final int? uncertaintyMicros;

  Map<String, dynamic> toJson() => {
        'role': role,
        'sessionId': sessionId,
        'monotonicMicros': monotonicMicros,
        'wallClockMicros': wallClockMicros,
        if (frameIndex != null) 'frameIndex': frameIndex,
        if (frameRate != null) 'frameRate': frameRate,
        if (uncertaintyMicros != null) 'uncertaintyMicros': uncertaintyMicros,
      };

  factory TimingData.fromJson(Map<String, dynamic> json) => TimingData(
        role: json['role'] as String,
        sessionId: json['sessionId'] as String,
        monotonicMicros: (json['monotonicMicros'] as num).toInt(),
        wallClockMicros: (json['wallClockMicros'] as num).toInt(),
        frameIndex: (json['frameIndex'] as num?)?.toInt(),
        frameRate: (json['frameRate'] as num?)?.toDouble(),
        uncertaintyMicros: (json['uncertaintyMicros'] as num?)?.toInt(),
      );

  /// Demo helper: synthesize the opposite role with a wall-clock delta.
  TimingData copyWithRole({
    required String role,
    required int wallDeltaMicros,
  }) {
    return TimingData(
      role: role,
      sessionId: sessionId,
      monotonicMicros: monotonicMicros + wallDeltaMicros,
      wallClockMicros: wallClockMicros + wallDeltaMicros,
      frameIndex: role == 'stop' ? (frameIndex ?? 0) : null,
      frameRate: frameRate,
      uncertaintyMicros: uncertaintyMicros,
    );
  }
}

/// Result of clock offset estimation between two phones.
class ClockSyncResult {
  ClockSyncResult({
    required this.offsetMicros,
    required this.rttMicros,
    required this.uncertaintyMicros,
    required this.samples,
  });

  /// remote_wall - local_wall estimate (add to remote timestamps to align to local).
  final int offsetMicros;
  final int rttMicros;
  final int uncertaintyMicros;
  final int samples;
}

/// Final computed sprint result shown on both phones.
class SprintResult {
  SprintResult({
    required this.timeSeconds,
    required this.uncertaintySeconds,
    required this.sessionCode,
    required this.startWallMicros,
    required this.finishWallMicros,
    required this.clockOffsetMicros,
  });

  final double timeSeconds;
  final double uncertaintySeconds;
  final String sessionCode;
  final int startWallMicros;
  final int finishWallMicros;
  final int clockOffsetMicros;

  String get formattedTime {
    if (timeSeconds < 0) return '—';
    // Show hundredths, and thousandths when uncertainty supports it.
    if (uncertaintySeconds <= 0.005) {
      return timeSeconds.toStringAsFixed(3);
    }
    return timeSeconds.toStringAsFixed(2);
  }
}
