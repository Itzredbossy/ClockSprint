enum DeviceRole {
  start,
  stop;

  String get label => switch (this) {
        DeviceRole.start => 'START PHONE',
        DeviceRole.stop => 'STOP PHONE',
      };

  String get subtitle => switch (this) {
        DeviceRole.start => 'Starting line · gun & flash',
        DeviceRole.stop => 'Finish line · camera & frames',
      };
}
