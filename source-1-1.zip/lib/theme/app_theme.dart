import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';

class AppColors {
  static const Color black = Color(0xFF000000);
  static const Color white = Color(0xFFFFFFFF);
  static const Color background = Color(0xFFF2F2F7);
  static const Color surface = Color(0xFFFFFFFF);
  static const Color label = Color(0xFF000000);
  static const Color secondaryLabel = Color(0xFF8E8E93);
  static const Color separator = Color(0xFFC6C6C8);
  static const Color glassFill = Color(0x99FFFFFF);
  static const Color glassBorder = Color(0x66FFFFFF);
  static const Color setGreen = Color(0xFF34C759);
  static const Color cyan = Color(0xFF00C7BE);
  static const Color popupScrim = Color(0x66000000);
}

class AppTheme {
  static ThemeData get light {
    final base = ThemeData(
      useMaterial3: true,
      brightness: Brightness.light,
      scaffoldBackgroundColor: AppColors.background,
      colorScheme: const ColorScheme.light(
        primary: AppColors.black,
        onPrimary: AppColors.white,
        surface: AppColors.surface,
        onSurface: AppColors.label,
      ),
      cupertinoOverrideTheme: const CupertinoThemeData(
        primaryColor: AppColors.black,
      ),
    );

    return base.copyWith(
      textTheme: base.textTheme.apply(
        bodyColor: AppColors.label,
        displayColor: AppColors.label,
        fontFamily: '.SF Pro Text',
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.transparent,
        elevation: 0,
        foregroundColor: AppColors.black,
        centerTitle: true,
      ),
      dividerColor: AppColors.separator,
    );
  }
}
