import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../services/session_controller.dart';
import 'glass.dart';

mixin HelpPopupMixin<T extends StatefulWidget> on State<T> {
  bool _helpShown = false;

  void maybeShowHelp(String title, String body) {
    final settings = context.read<SessionController>().settings;
    if (!settings.helpPopupsEnabled || _helpShown) return;
    _helpShown = true;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (ctx) => ApplePopup(
          title: title,
          body: body,
          onClose: () => Navigator.of(ctx).pop(),
          onToggleOff: () {
            settings.setHelpPopups(false);
            Navigator.of(ctx).pop();
          },
        ),
      );
    });
  }
}
