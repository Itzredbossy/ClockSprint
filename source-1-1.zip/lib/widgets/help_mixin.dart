import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../services/session_controller.dart';
import 'glass.dart';

mixin HelpPopupMixin<T extends StatefulWidget> on State<T> {
  bool _helpShown = false;

  void maybeShowHelp(String title, String body) {
    final settings = context.read<SessionController>().settings;
    if (!settings.helpPopupsEnabled || _helpShown) return;
    _helpShown = true;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      showGeneralDialog<void>(
        context: context,
        barrierDismissible: false,
        barrierLabel: 'Help',
        barrierColor: Colors.black.withOpacity(.42),
        transitionDuration: const Duration(milliseconds: 280),
        pageBuilder: (dialogContext, animation, secondaryAnimation) {
          return SafeArea(
            child: Center(
              child: ApplePopup(
                title: title,
                body: body,
                onClose: () => Navigator.of(dialogContext).pop(),
                onToggleOff: () {
                  settings.setHelpPopups(false);
                  Navigator.of(dialogContext).pop();
                },
              ),
            ),
          );
        },
        transitionBuilder: (context, animation, secondaryAnimation, child) {
          final eased = CurvedAnimation(
            parent: animation,
            curve: Curves.easeOutCubic,
            reverseCurve: Curves.easeInCubic,
          );
          return FadeTransition(
            opacity: eased,
            child: ScaleTransition(
              scale: Tween<double>(begin: .96, end: 1).animate(eased),
              child: SlideTransition(
                position: Tween<Offset>(
                  begin: const Offset(0, .018),
                  end: Offset.zero,
                ).animate(eased),
                child: child,
              ),
            ),
          );
        },
      );
    });
  }
}
