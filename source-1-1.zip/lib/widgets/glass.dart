import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../theme/app_theme.dart';

/// Glass panel matching OfflineLink frost style adapted for Flutter:
/// translucent fill + light border + backdrop blur.
class Glass extends StatelessWidget {
  const Glass({
    super.key,
    required this.child,
    this.borderRadius = 22,
    this.padding = EdgeInsets.zero,
    this.onTap,
    this.circle = false,
  });

  final Widget child;
  final double borderRadius;
  final EdgeInsets padding;
  final VoidCallback? onTap;
  final bool circle;

  @override
  Widget build(BuildContext context) {
    final radius =
        circle ? BorderRadius.circular(999) : BorderRadius.circular(borderRadius);

    final content = ClipRRect(
      borderRadius: radius,
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 24, sigmaY: 24),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            borderRadius: radius,
            color: AppColors.glassFill,
            border: Border.all(color: AppColors.glassBorder, width: 1),
            boxShadow: const [
              BoxShadow(
                color: Color(0x14000000),
                blurRadius: 16,
                offset: Offset(0, 6),
              ),
            ],
          ),
          child: child,
        ),
      ),
    );

    if (onTap == null) return content;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: () {
          HapticFeedback.selectionClick();
          onTap!();
        },
        borderRadius: radius,
        child: content,
      ),
    );
  }
}

/// Top bar: glass back + glass menu (3 lines).
class AppTopBar extends StatelessWidget {
  const AppTopBar({
    super.key,
    this.onBack,
    this.onMenu,
    this.title,
  });

  final VoidCallback? onBack;
  final VoidCallback? onMenu;
  final String? title;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
      child: Row(
        children: [
          Glass(
            circle: true,
            onTap: onBack ?? () => Navigator.of(context).maybePop(),
            padding: const EdgeInsets.all(12),
            child: const Icon(Icons.arrow_back_ios_new_rounded, size: 18, color: AppColors.black),
          ),
          const SizedBox(width: 10),
          Glass(
            circle: true,
            onTap: onMenu,
            padding: const EdgeInsets.all(12),
            child: const Icon(Icons.menu_rounded, size: 20, color: AppColors.black),
          ),
          if (title != null) ...[
            const SizedBox(width: 14),
            Expanded(
              child: Text(
                title!,
                style: const TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.w600,
                  color: AppColors.black,
                  letterSpacing: -0.2,
                ),
              ),
            ),
          ] else
            const Spacer(),
        ],
      ),
    );
  }
}

/// Large green SET control on white (Apple-like).
class SetButton extends StatelessWidget {
  const SetButton({super.key, required this.onPressed, this.label = 'SET'});

  final VoidCallback onPressed;
  final String label;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 64,
      child: Material(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(16),
        child: InkWell(
          onTap: () {
            HapticFeedback.mediumImpact();
            onPressed();
          },
          borderRadius: BorderRadius.circular(16),
          child: Container(
            alignment: Alignment.center,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: AppColors.separator.withOpacity(0.5)),
            ),
            child: Text(
              label,
              style: const TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.w700,
                color: AppColors.setGreen,
                letterSpacing: 2,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// Primary black filled button (Apple proportions ~50pt height).
class AppleButton extends StatelessWidget {
  const AppleButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.filled = true,
  });

  final String label;
  final VoidCallback? onPressed;
  final bool filled;

  @override
  Widget build(BuildContext context) {
    final child = Text(
      label,
      style: TextStyle(
        fontSize: 17,
        fontWeight: FontWeight.w600,
        color: filled ? AppColors.white : AppColors.black,
      ),
    );

    return SizedBox(
      width: double.infinity,
      height: 50,
      child: filled
          ? ElevatedButton(
              onPressed: onPressed,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.black,
                foregroundColor: AppColors.white,
                elevation: 0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
              ),
              child: child,
            )
          : OutlinedButton(
              onPressed: onPressed,
              style: OutlinedButton.styleFrom(
                foregroundColor: AppColors.black,
                side: const BorderSide(color: AppColors.separator),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
              ),
              child: child,
            ),
    );
  }
}

/// White Apple-style alert with two cyan actions.
class ApplePopup extends StatelessWidget {
  const ApplePopup({
    super.key,
    required this.title,
    required this.body,
    required this.onClose,
    required this.onToggleOff,
  });

  final String title;
  final String body;
  final VoidCallback onClose;
  final VoidCallback onToggleOff;

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 40),
      child: Container(
        decoration: BoxDecoration(
          color: AppColors.white,
          borderRadius: BorderRadius.circular(14),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 22, 20, 8),
              child: Text(
                title,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.w700,
                  color: AppColors.black,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 18),
              child: Text(
                body,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 13,
                  height: 1.35,
                  color: AppColors.black,
                  fontWeight: FontWeight.w400,
                ),
              ),
            ),
            const Divider(height: 1, color: AppColors.separator),
            SizedBox(
              height: 48,
              child: Row(
                children: [
                  Expanded(
                    child: TextButton(
                      onPressed: onClose,
                      style: TextButton.styleFrom(
                        foregroundColor: AppColors.white,
                        backgroundColor: AppColors.cyan,
                        shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.only(
                            bottomLeft: Radius.circular(14),
                          ),
                        ),
                      ),
                      child: const Text(
                        'CLOSE',
                        style: TextStyle(
                          fontWeight: FontWeight.w700,
                          fontSize: 15,
                          color: AppColors.white,
                        ),
                      ),
                    ),
                  ),
                  Container(width: 1, color: AppColors.separator),
                  Expanded(
                    child: TextButton(
                      onPressed: onToggleOff,
                      style: TextButton.styleFrom(
                        foregroundColor: AppColors.white,
                        backgroundColor: AppColors.cyan,
                        shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.only(
                            bottomRight: Radius.circular(14),
                          ),
                        ),
                      ),
                      child: const Text(
                        'TOGGLE OFF',
                        style: TextStyle(
                          fontWeight: FontWeight.w700,
                          fontSize: 15,
                          color: AppColors.white,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Circular check control in black (no green accents except SET).
class CheckButton extends StatelessWidget {
  const CheckButton({super.key, required this.onPressed, this.size = 72});

  final VoidCallback onPressed;
  final double size;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColors.black,
      shape: const CircleBorder(),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: () {
          HapticFeedback.mediumImpact();
          onPressed();
        },
        child: SizedBox(
          width: size,
          height: size,
          child: const Icon(Icons.check_rounded, color: AppColors.white, size: 36),
        ),
      ),
    );
  }
}
