import 'dart:math' as math;
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../theme/app_theme.dart';

/// Shared frosted-glass surface. On Android this uses a real backdrop blur,
/// translucent material, layered edge highlights and a restrained shadow.
class Glass extends StatelessWidget {
  const Glass({
    super.key,
    required this.child,
    this.borderRadius = 22,
    this.padding = EdgeInsets.zero,
    this.onTap,
    this.circle = false,
    this.tintColor,
    this.blur = 22,
  });

  final Widget child;
  final double borderRadius;
  final EdgeInsets padding;
  final VoidCallback? onTap;
  final bool circle;
  final Color? tintColor;
  final double blur;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final radius = circle
        ? BorderRadius.circular(999)
        : BorderRadius.circular(borderRadius);
    final fill = tintColor ??
        (isDark
            ? Colors.white.withOpacity(.105)
            : Colors.white.withOpacity(.42));
    final border = isDark
        ? Colors.white.withOpacity(.19)
        : Colors.white.withOpacity(.78);

    final surface = ClipRRect(
      borderRadius: radius,
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: blur, sigmaY: blur),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            color: fill,
            borderRadius: radius,
            border: Border.all(color: border, width: 1),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(isDark ? .24 : .095),
                blurRadius: 19,
                offset: const Offset(0, 7),
              ),
              BoxShadow(
                color: Colors.white.withOpacity(isDark ? .055 : .36),
                blurRadius: 1,
                offset: const Offset(0, 1),
              ),
            ],
          ),
          child: Stack(
            children: [
              Positioned.fill(
                child: IgnorePointer(
                  child: DecoratedBox(
                    decoration: BoxDecoration(
                      borderRadius: radius,
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                          Colors.white.withOpacity(isDark ? .13 : .34),
                          Colors.white.withOpacity(.025),
                          Colors.white.withOpacity(isDark ? .015 : .10),
                        ],
                        stops: const [0, .48, 1],
                      ),
                    ),
                  ),
                ),
              ),
              child,
            ],
          ),
        ),
      ),
    );

    if (onTap == null) return surface;
    return _PressScale(
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () {
            HapticFeedback.selectionClick();
            onTap!();
          },
          borderRadius: radius,
          splashColor: Colors.white.withOpacity(.16),
          highlightColor: Colors.white.withOpacity(.06),
          child: surface,
        ),
      ),
    );
  }
}

class _PressScale extends StatefulWidget {
  const _PressScale({required this.child});
  final Widget child;

  @override
  State<_PressScale> createState() => _PressScaleState();
}

class _PressScaleState extends State<_PressScale> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return Listener(
      onPointerDown: (_) => setState(() => _pressed = true),
      onPointerUp: (_) => setState(() => _pressed = false),
      onPointerCancel: (_) => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? .982 : 1,
        duration: const Duration(milliseconds: 125),
        curve: Curves.easeOutCubic,
        child: widget.child,
      ),
    );
  }
}

/// Glass back/menu controls used by every screen.
class AppTopBar extends StatelessWidget {
  const AppTopBar({
    super.key,
    this.onBack,
    this.onMenu,
    this.title,
    this.foregroundColor,
    this.glassTint,
  });

  final VoidCallback? onBack;
  final VoidCallback? onMenu;
  final String? title;
  final Color? foregroundColor;
  final Color? glassTint;

  @override
  Widget build(BuildContext context) {
    final foreground = foregroundColor ?? Theme.of(context).colorScheme.onSurface;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
      child: Row(
        children: [
          Glass(
            circle: true,
            onTap: onBack ?? () => Navigator.of(context).maybePop(),
            padding: const EdgeInsets.all(12),
            tintColor: glassTint,
            child: Icon(Icons.arrow_back_ios_new_rounded,
                size: 18, color: foreground),
          ),
          const SizedBox(width: 10),
          Glass(
            circle: true,
            onTap: onMenu,
            padding: const EdgeInsets.all(12),
            tintColor: glassTint,
            child: Icon(Icons.menu_rounded, size: 20, color: foreground),
          ),
          if (title != null) ...[
            const SizedBox(width: 14),
            Expanded(
              child: Text(
                title!,
                style: TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.w600,
                  color: foreground,
                  letterSpacing: -.2,
                ),
              ),
            ),
          ] else
            const Spacer(),
        ],
      ),
    );
  }
}

/// The SET action keeps its original green label and proportions, now on glass.
class SetButton extends StatelessWidget {
  const SetButton({super.key, required this.onPressed, this.label = 'SET'});

  final VoidCallback onPressed;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Glass(
      onTap: onPressed,
      borderRadius: 17,
      tintColor: AppColors.setGreen.withOpacity(
        Theme.of(context).brightness == Brightness.dark ? .16 : .10,
      ),
      padding: const EdgeInsets.symmetric(vertical: 17),
      child: SizedBox(
        width: double.infinity,
        child: Center(
          child: Text(
            label,
            style: const TextStyle(
              fontSize: 28,
              fontWeight: FontWeight.w700,
              color: AppColors.setGreen,
              letterSpacing: 2,
            ),
          ),
        ),
      ),
    );
  }
}

/// Primary and secondary app actions now share the Liquid Glass material.
class AppleButton extends StatelessWidget {
  const AppleButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.filled = true,
  });

  final String label;
  final VoidCallback? onPressed;
  final bool filled;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final primary = isDark ? AppColors.iosBlueDark : AppColors.iosBlue;
    return Opacity(
      opacity: onPressed == null ? .48 : 1,
      child: Glass(
        onTap: onPressed,
        borderRadius: 16,
        blur: 20,
        tintColor: filled
            ? primary.withOpacity(isDark ? .57 : .76)
            : null,
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 13),
        child: SizedBox(
          width: double.infinity,
          height: 24,
          child: Center(
            child: Text(
              label,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                letterSpacing: -.1,
                color: filled ? Colors.white : Theme.of(context).colorScheme.primary,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// Responsive iOS-inspired alert. Width is constrained by the available
/// display width rather than fixed to one phone size.
class ApplePopup extends StatelessWidget {
  const ApplePopup({
    super.key,
    required this.title,
    required this.body,
    required this.onClose,
    required this.onToggleOff,
  });

  final String title;
  final String body;
  final VoidCallback onClose;
  final VoidCallback onToggleOff;

  @override
  Widget build(BuildContext context) {
    final media = MediaQuery.sizeOf(context);
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final width = math.min(320.0, media.width - 48).clamp(180.0, 320.0).toDouble();
    final compact = media.height < 640;
    final buttonHeight = compact ? 44.0 : 48.0;
    final surface = theme.colorScheme.surface;
    final secondaryFill = isDark
        ? const Color(0xFF303034)
        : const Color(0xFFF0F5FB);

    return Dialog(
      backgroundColor: Colors.transparent,
      elevation: 0,
      insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: width, maxHeight: media.height * .82),
        child: Container(
          width: width,
          decoration: BoxDecoration(
            color: surface,
            borderRadius: BorderRadius.circular(28),
            border: Border.all(
              color: isDark ? Colors.white.withOpacity(.10) : Colors.white,
              width: 1,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(isDark ? .48 : .22),
                blurRadius: 42,
                offset: const Offset(0, 18),
              ),
            ],
          ),
          padding: EdgeInsets.fromLTRB(22, compact ? 19 : 24, 22, 14),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  title,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.w700,
                    letterSpacing: -.25,
                    height: 1.3,
                    color: theme.colorScheme.onSurface,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  body,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w400,
                    height: 1.4,
                    color: isDark
                        ? const Color(0xFFB8B8BE)
                        : const Color(0xFF666A73),
                  ),
                ),
                SizedBox(height: compact ? 16 : 20),
                _PopupAction(
                  label: 'CLOSE',
                  height: buttonHeight,
                  primary: true,
                  onPressed: onClose,
                ),
                const SizedBox(height: 8),
                _PopupAction(
                  label: 'TOGGLE OFF',
                  height: buttonHeight,
                  primary: false,
                  fill: secondaryFill,
                  onPressed: onToggleOff,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _PopupAction extends StatefulWidget {
  const _PopupAction({
    required this.label,
    required this.height,
    required this.primary,
    required this.onPressed,
    this.fill,
  });

  final String label;
  final double height;
  final bool primary;
  final Color? fill;
  final VoidCallback onPressed;

  @override
  State<_PopupAction> createState() => _PopupActionState();
}

class _PopupActionState extends State<_PopupAction> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final blue = Theme.of(context).colorScheme.primary;
    return Listener(
      onPointerDown: (_) => setState(() => _pressed = true),
      onPointerUp: (_) => setState(() => _pressed = false),
      onPointerCancel: (_) => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? .985 : 1,
        duration: const Duration(milliseconds: 115),
        curve: Curves.easeOutCubic,
        child: SizedBox(
          width: double.infinity,
          height: widget.height,
          child: Material(
            color: widget.primary
                ? blue
                : (widget.fill ?? Theme.of(context).colorScheme.surface),
            borderRadius: BorderRadius.circular(15),
            child: InkWell(
              onTap: widget.onPressed,
              borderRadius: BorderRadius.circular(15),
              splashColor: Colors.white.withOpacity(.16),
              child: Center(
                child: Text(
                  widget.label,
                  style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w600,
                    letterSpacing: -.1,
                    color: widget.primary ? Colors.white : blue,
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class CheckButton extends StatelessWidget {
  const CheckButton({super.key, required this.onPressed, this.size = 72});

  final VoidCallback onPressed;
  final double size;

  @override
  Widget build(BuildContext context) {
    final blue = Theme.of(context).colorScheme.primary;
    return Glass(
      circle: true,
      onTap: onPressed,
      tintColor: blue.withOpacity(.76),
      padding: EdgeInsets.zero,
      child: SizedBox(
        width: size,
        height: size,
        child: const Icon(Icons.check_rounded, color: Colors.white, size: 36),
      ),
    );
  }
}
