import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../theme/app_theme.dart';

/// Glass panel matching OfflineLink frost style adapted for Flutter:
/// translucent fill + light border + backdrop blur.
class Glass extends StatelessWidget {
  const Glass({
    super.key,
    required this.child,
    this.borderRadius = 22,
    this.padding = EdgeInsets.zero,
    this.onTap,
    this.circle = false,
  });

  final Widget child;
  final double borderRadius;
  final EdgeInsets padding;
  final VoidCallback? onTap;
  final bool circle;

  @override
  Widget build(BuildContext context) {
    final radius =
        circle ? BorderRadius.circular(999) : BorderRadius.circular(borderRadius);

    final content = ClipRRect(
      borderRadius: radius,
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 24, sigmaY: 24),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            borderRadius: radius,
            color: AppColors.glassFill,
            border: Border.all(color: AppColors.glassBorder, width: 1),
            boxShadow: const [
              BoxShadow(
                color: Color(0x14000000),
                blurRadius: 16,
                offset: Offset(0, 6),
              ),
            ],
          ),
          child: child,
        ),
      ),
    );

    if (onTap == null) return content;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: () {
          HapticFeedback.selectionClick();
          onTap!();
        },
        borderRadius: radius,
        child: content,
      ),
    );
  }
}

/// Top bar: glass back + glass menu (3 lines).
class AppTopBar extends StatelessWidget {
  const AppTopBar({
    super.key,
    this.onBack,
    this.onMenu,
    this.title,
  });

  final VoidCallback? onBack;
  final VoidCallback? onMenu;
  final String? title;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
      child: Row(
        children: [
          Glass(
            circle: true,
            onTap: onBack ?? () => Navigator.of(context).maybePop(),
            padding: const EdgeInsets.all(12),
            child: const Icon(Icons.arrow_back_ios_new_rounded, size: 18, color: AppColors.black),
          ),
          const SizedBox(width: 10),
          Glass(
            circle: true,
            onTap: onMenu,
            padding: const EdgeInsets.all(12),
            child: const Icon(Icons.menu_rounded, size: 20, color: AppColors.black),
          ),
          if (title != null) ...[
            const SizedBox(width: 14),
            Expanded(
              child: Text(
                title!,
                style: const TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.w600,
                  color: AppColors.black,
                  letterSpacing: -0.2,
                ),
              ),
            ),
          ] else
            const Spacer(),
        ],
      ),
    );
  }
}

/// Large green SET control on white (Apple-like).
class SetButton extends StatelessWidget {
  const SetButton({super.key, required this.onPressed, this.label = 'SET'});

  final VoidCallback onPressed;
  final String label;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 64,
      child: Material(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(16),
        child: InkWell(
          onTap: () {
            HapticFeedback.mediumImpact();
            onPressed();
          },
          borderRadius: BorderRadius.circular(16),
          child: Container(
            alignment: Alignment.center,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: AppColors.separator.withOpacity(0.5)),
            ),
            child: Text(
              label,
              style: const TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.w700,
                color: AppColors.setGreen,
                letterSpacing: 2,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// Primary black filled button (Apple proportions ~50pt height).
class AppleButton extends StatelessWidget {
  const AppleButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.filled = true,
  });

  final String label;
  final VoidCallback? onPressed;
  final bool filled;

  @override
  Widget build(BuildContext context) {
    final child = Text(
      label,
      style: TextStyle(
        fontSize: 17,
        fontWeight: FontWeight.w600,
        color: filled ? AppColors.white : AppColors.black,
      ),
    );

    return SizedBox(
      width: double.infinity,
      height: 50,
      child: filled
          ? ElevatedButton(
              onPressed: onPressed,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.black,
                foregroundColor: AppColors.white,
                elevation: 0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
              ),
              child: child,
            )
          : OutlinedButton(
              onPressed: onPressed,
              style: OutlinedButton.styleFrom(
                foregroundColor: AppColors.black,
                side: const BorderSide(color: AppColors.separator),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
              ),
              child: child,
            ),
    );
  }
}

/// White Apple-style alert with two cyan actions.
class ApplePopup extends StatelessWidget {
  const ApplePopup({
    super.key,
    required this.title,
    required this.body,
    required this.onClose,
    required this.onToggleOff,
  });

  final String title;
  final String body;
  final VoidCallback onClose;
  final VoidCallback onToggleOff;

  @override
  Widget build(BuildContext context) {
    // iOS-style alert: ~270pt wide, continuous-corner "squircle" (~14–18).
    // Actions sit inside as rounded cyan pills so the outer radius stays intact.
    return Dialog(
      backgroundColor: Colors.transparent,
      elevation: 0,
      insetPadding: const EdgeInsets.symmetric(horizontal: 52),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 270),
        child: Container(
          decoration: BoxDecoration(
            color: const Color(0xF2F2F2F7), // iOS system grouped / alert fill
            borderRadius: BorderRadius.circular(28), // squircle-like
            boxShadow: const [
              BoxShadow(
                color: Color(0x33000000),
                blurRadius: 40,
                offset: Offset(0, 16),
              ),
            ],
          ),
          padding: const EdgeInsets.fromLTRB(16, 22, 16, 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                title,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.w700,
                  color: AppColors.black,
                  letterSpacing: -0.2,
                  height: 1.25,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                body,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w400,
                  color: AppColors.black,
                  height: 1.35,
                ),
              ),
              const SizedBox(height: 18),
              Row(
                children: [
                  Expanded(
                    child: _CyanPill(label: 'CLOSE', onPressed: onClose),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: _CyanPill(label: 'TOGGLE OFF', onPressed: onToggleOff),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _CyanPill extends StatelessWidget {
  const _CyanPill({required this.label, required this.onPressed});
  final String label;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 44,
      child: Material(
        color: AppColors.cyan,
        borderRadius: BorderRadius.circular(14),
        child: InkWell(
          onTap: onPressed,
          borderRadius: BorderRadius.circular(14),
          child: Center(
            child: Text(
              label,
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w700,
                color: AppColors.white,
                letterSpacing: 0.2,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class CheckButton extends StatelessWidget {
  const CheckButton({super.key, required this.onPressed, this.size = 72});

  final VoidCallback onPressed;
  final double size;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColors.black,
      shape: const CircleBorder(),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: () {
          HapticFeedback.mediumImpact();
          onPressed();
        },
        child: SizedBox(
          width: size,
          height: size,
          child: const Icon(Icons.check_rounded, color: AppColors.white, size: 36),
        ),
      ),
    );
  }
}
