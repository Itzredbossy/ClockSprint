import 'package:flutter/material.dart';

import '../theme/app_theme.dart';
import 'glass.dart';

/// Shared glass action retained for callers that prefer the PrimaryButton API.
class PrimaryButton extends StatelessWidget {
  const PrimaryButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.icon,
    this.filled = true,
    this.expand = true,
  });

  final String label;
  final VoidCallback? onPressed;
  final IconData? icon;
  final bool filled;
  final bool expand;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final blue = isDark ? AppColors.iosBlueDark : AppColors.iosBlue;
    final action = Glass(
      onTap: onPressed,
      borderRadius: 16,
      tintColor: filled ? blue.withOpacity(isDark ? .57 : .76) : null,
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 13),
      child: Row(
        mainAxisSize: expand ? MainAxisSize.max : MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          if (icon != null) ...[
            Icon(icon, size: 22, color: filled ? Colors.white : blue),
            const SizedBox(width: 10),
          ],
          Text(
            label,
            style: TextStyle(
              fontWeight: FontWeight.w600,
              color: filled ? Colors.white : blue,
            ),
          ),
        ],
      ),
    );
    return Opacity(
      opacity: onPressed == null ? .48 : 1,
      child: expand ? SizedBox(width: double.infinity, child: action) : action,
    );
  }
}

class CheckCircleButton extends StatelessWidget {
  const CheckCircleButton({
    super.key,
    required this.onPressed,
    this.size = 88,
    this.color = AppColors.setGreen,
  });

  final VoidCallback onPressed;
  final double size;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Glass(
      circle: true,
      onTap: onPressed,
      tintColor: color.withOpacity(.78),
      padding: EdgeInsets.zero,
      child: SizedBox(
        width: size,
        height: size,
        child: const Icon(Icons.check_rounded, color: Colors.white, size: 40),
      ),
    );
  }
}
