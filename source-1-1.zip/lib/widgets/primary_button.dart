import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../theme/app_theme.dart';

class PrimaryButton extends StatelessWidget {
  const PrimaryButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.icon,
    this.filled = true,
    this.expand = true,
  });

  final String label;
  final VoidCallback? onPressed;
  final IconData? icon;
  final bool filled;
  final bool expand;

  @override
  Widget build(BuildContext context) {
    final child = Row(
      mainAxisSize: expand ? MainAxisSize.max : MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        if (icon != null) ...[
          Icon(icon, size: 22),
          const SizedBox(width: 10),
        ],
        Text(label),
      ],
    );

    final btn = filled
        ? ElevatedButton(
            onPressed: onPressed == null
                ? null
                : () {
                    HapticFeedback.lightImpact();
                    onPressed!();
                  },
            child: child,
          )
        : OutlinedButton(
            onPressed: onPressed == null
                ? null
                : () {
                    HapticFeedback.selectionClick();
                    onPressed!();
                  },
            child: child,
          );

    if (!expand) return btn;
    return SizedBox(width: double.infinity, child: btn);
  }
}

class CheckCircleButton extends StatelessWidget {
  const CheckCircleButton({
    super.key,
    required this.onPressed,
    this.size = 88,
    this.color = AppTheme.success,
  });

  final VoidCallback onPressed;
  final double size;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: color,
      shape: const CircleBorder(),
      elevation: 0,
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: () {
          HapticFeedback.mediumImpact();
          onPressed();
        },
        child: SizedBox(
          width: size,
          height: size,
          child: const Icon(Icons.check_rounded, color: Colors.white, size: 40),
        ),
      ),
    );
  }
}
