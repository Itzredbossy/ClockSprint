/// High-resolution timing helpers.
///
/// Uses [Stopwatch] (monotonic) paired with wall-clock [DateTime] for BLE sync.
class PrecisionClock {
  PrecisionClock() {
    _stopwatch.start();
    _wallAnchorMicros = DateTime.now().microsecondsSinceEpoch;
    _monoAnchorMicros = _stopwatch.elapsedMicroseconds;
  }

  final Stopwatch _stopwatch = Stopwatch();
  late int _wallAnchorMicros;
  late int _monoAnchorMicros;

  /// Monotonic microseconds since process start (preferred for intervals).
  int get monotonicMicros => _stopwatch.elapsedMicroseconds;

  /// Estimated wall-clock microseconds (epoch).
  int get wallClockMicros {
    final monoDelta = monotonicMicros - _monoAnchorMicros;
    return _wallAnchorMicros + monoDelta;
  }

  /// Capture a simultaneous mono + wall sample.
  ({int mono, int wall}) sample() {
    final mono = monotonicMicros;
    final wall = _wallAnchorMicros + (mono - _monoAnchorMicros);
    return (mono: mono, wall: wall);
  }

  /// Re-anchor wall clock (call occasionally to reduce drift vs system clock).
  void reanchor() {
    _wallAnchorMicros = DateTime.now().microsecondsSinceEpoch;
    _monoAnchorMicros = _stopwatch.elapsedMicroseconds;
  }
}
