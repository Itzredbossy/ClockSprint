import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import 'screens/role_select_screen.dart';
import 'services/session_controller.dart';
import 'theme/app_theme.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);
  runApp(const SprintTimerApp());
}

class SprintTimerApp extends StatelessWidget {
  const SprintTimerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => SessionController(),
      child: Builder(
        builder: (context) {
          final session = context.read<SessionController>();
          return AnimatedBuilder(
            animation: session.settings,
            builder: (context, _) {
              final isDark = session.settings.themeMode == ThemeMode.dark ||
                  (session.settings.themeMode == ThemeMode.system &&
                      WidgetsBinding.instance.platformDispatcher.platformBrightness ==
                          Brightness.dark);
              SystemChrome.setSystemUIOverlayStyle(
                SystemUiOverlayStyle(
                  statusBarColor: Colors.transparent,
                  statusBarIconBrightness:
                      isDark ? Brightness.light : Brightness.dark,
                  systemNavigationBarColor: isDark
                      ? const Color(0xFF090A0D)
                      : const Color(0xFFF2F2F7),
                  systemNavigationBarIconBrightness:
                      isDark ? Brightness.light : Brightness.dark,
                ),
              );
              return MaterialApp(
                title: 'Sprint Timer',
                debugShowCheckedModeBanner: false,
                theme: AppTheme.light,
                darkTheme: AppTheme.dark,
                themeMode: session.settings.themeMode,
                home: const RoleSelectScreen(),
              );
            },
          );
        },
      ),
    );
  }
}
