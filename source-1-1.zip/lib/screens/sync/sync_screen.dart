import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/device_role.dart';
import '../../models/timing_data.dart';
import '../../services/nearby_sync_service.dart';
import '../../services/session_controller.dart';
import '../../widgets/glass.dart';
import '../../widgets/help_mixin.dart';
import '../result/result_screen.dart';
import '../settings_sheet.dart';

class SyncScreen extends StatefulWidget {
  const SyncScreen({super.key});

  @override
  State<SyncScreen> createState() => _SyncScreenState();
}

class _SyncScreenState extends State<SyncScreen> with HelpPopupMixin {
  bool _busy = false;
  String? _status;
  StreamSubscription? _phaseSub;
  bool _proceeded = false;

  @override
  void initState() {
    super.initState();
    maybeShowHelp(
      'Sync',
      'One phone hosts, the other joins. Confirm both show the same code, then proceed.',
    );
    final nearby = context.read<SessionController>().nearby;
    _phaseSub = nearby.onPhase.listen((p) {
      if (!mounted) return;
      setState(() {
        if (p == SyncPhase.connected) {
          _status = null;
          _busy = false;
        } else if (p == SyncPhase.hosting) {
          _status = 'Hosting…';
        } else if (p == SyncPhase.joining) {
          _status = 'Searching…';
        }
      });
    });
  }

  @override
  void dispose() {
    _phaseSub?.cancel();
    super.dispose();
  }

  String get _deviceName {
    final role = context.read<SessionController>().role;
    final tag = role == DeviceRole.start ? 'START' : 'STOP';
    return 'SprintTimer-$tag-${Platform.localHostname}';
  }

  Future<void> _host() async {
    setState(() {
      _busy = true;
      _status = 'Hosting…';
    });
    final session = context.read<SessionController>();
    await session.nearby.host(deviceName: _deviceName);
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _join() async {
    setState(() {
      _busy = true;
      _status = 'Searching…';
    });
    final session = context.read<SessionController>();
    await session.nearby.join(deviceName: _deviceName);
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _proceed() async {
    if (_proceeded) return;
    _proceeded = true;
    final session = context.read<SessionController>();
    setState(() => _status = 'Syncing clocks…');

    try {
      await session.nearby.estimateClockOffset(samples: 8);
    } catch (_) {
      session.nearby.clockSync = ClockSyncResult(
        offsetMicros: 0,
        rttMicros: 0,
        uncertaintyMicros: 25000,
        samples: 0,
      );
    }
    session.nearby.clockSync ??= ClockSyncResult(
      offsetMicros: 0,
      rttMicros: 0,
      uncertaintyMicros: 25000,
      samples: 0,
    );

    if (session.localTiming != null) {
      await session.nearby.sendTiming(session.localTiming!);
    }

    for (var i = 0; i < 30 && session.nearby.remoteTiming == null; i++) {
      await Future<void>.delayed(const Duration(milliseconds: 200));
    }

    final localIsStart = session.role == DeviceRole.start;
    final result = session.nearby.computeResult(localIsStart: localIsStart);
    if (result != null) {
      session.setResult(result);
    }

    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        pageBuilder: (_, __, ___) => const ResultScreen(),
        transitionsBuilder: (_, a, __, c) => FadeTransition(opacity: a, child: c),
        transitionDuration: const Duration(milliseconds: 400),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final session = context.watch<SessionController>();
    final nearby = session.nearby;
    final connected = nearby.phase == SyncPhase.connected;

    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            AppTopBar(
              onBack: () => Navigator.of(context).maybePop(),
              onMenu: () => openSettings(context),
            ),
            const Spacer(flex: 1),
            Text(
              'SYNC',
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.w700,
                letterSpacing: 4,
                color: Theme.of(context).colorScheme.onSurface,
              ),
            ),
            const Spacer(flex: 1),
            if (!connected) ...[
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 28),
                child: Column(
                  children: [
                    AppleButton(
                      label: 'Host',
                      onPressed: _busy ? null : _host,
                    ),
                    const SizedBox(height: 12),
                    AppleButton(
                      label: 'Join',
                      filled: false,
                      onPressed: _busy ? null : _join,
                    ),
                  ],
                ),
              ),
              if (_status != null) ...[
                const SizedBox(height: 16),
                Text(
                  _status!,
                  style: TextStyle(
                    color: Theme.of(context).colorScheme.onSurface.withOpacity(.58),
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
              if (nearby.error != null) ...[
                const SizedBox(height: 8),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 28),
                  child: Text(
                    nearby.error!,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Theme.of(context).colorScheme.onSurface.withOpacity(.58),
                      fontSize: 12,
                    ),
                  ),
                ),
              ],
            ] else ...[
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 28),
                child: Glass(
                  borderRadius: 18,
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    children: [
                      Text(
                        'Synced with ${nearby.sessionCode.isNotEmpty ? nearby.sessionCode : session.sessionId}',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w700,
                          color: Theme.of(context).colorScheme.onSurface,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        nearby.peerName.isEmpty ? 'Peer' : nearby.peerName,
                        style: TextStyle(
                          fontSize: 13,
                          color: Theme.of(context).colorScheme.onSurface.withOpacity(.58),
                        ),
                      ),
                      const SizedBox(height: 20),
                      AppleButton(label: 'PROCEED', onPressed: _proceed),
                    ],
                  ),
                ),
              ),
              if (_status != null) ...[
                const SizedBox(height: 12),
                Text(
                  _status!,
                  style: TextStyle(
                    color: Theme.of(context).colorScheme.onSurface.withOpacity(.58),
                    fontSize: 13,
                  ),
                ),
              ],
            ],
            const Spacer(flex: 2),
          ],
        ),
      ),
    );
  }
}
