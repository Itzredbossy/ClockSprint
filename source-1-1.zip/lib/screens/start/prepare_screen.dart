import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../services/session_controller.dart';
import '../../theme/app_theme.dart';
import '../../widgets/glass.dart';
import '../../widgets/help_mixin.dart';
import '../settings_sheet.dart';
import '../sync/sync_screen.dart';

class PrepareScreen extends StatefulWidget {
  const PrepareScreen({super.key});

  @override
  State<PrepareScreen> createState() => _PrepareScreenState();
}

class _PrepareScreenState extends State<PrepareScreen> with HelpPopupMixin {
  bool _armed = false;
  bool _fired = false;

  @override
  void initState() {
    super.initState();
    maybeShowHelp(
      'Ready',
      'Hold still. The starting signal will fire after a short random delay.',
    );
    WidgetsBinding.instance.addPostFrameCallback((_) => _arm());
  }

  Future<void> _arm() async {
    if (_armed) return;
    _armed = true;
    final session = context.read<SessionController>();
    await session.startSignal.preload();
    if (!mounted) return;
    await session.startSignal.armAndFire();
    await session.recordStartTimestamp();
    if (!mounted) return;
    setState(() => _fired = true);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.white,
      body: SafeArea(
        child: Column(
          children: [
            AppTopBar(
              onBack: () => Navigator.of(context).maybePop(),
              onMenu: () => openSettings(context),
            ),
            const Spacer(flex: 3),
            Text(
              'ΕΤΟΙΜΑΣΟΥ',
              style: TextStyle(
                fontSize: 34,
                fontWeight: FontWeight.w600,
                letterSpacing: 1.2,
                color: AppColors.black.withOpacity(_fired ? 0.35 : 1),
              ),
            ),
            const Spacer(flex: 3),
            if (_fired)
              Padding(
                padding: const EdgeInsets.only(bottom: 40),
                child: CheckButton(
                  onPressed: () {
                    Navigator.of(context).pushReplacement(
                      MaterialPageRoute(builder: (_) => const SyncScreen()),
                    );
                  },
                ),
              ),
          ],
        ),
      ),
    );
  }
}
