import 'package:flutter/material.dart';

import '../../theme/app_theme.dart';
import '../../widgets/glass.dart';
import '../../widgets/help_mixin.dart';
import '../role_select_screen.dart';
import '../settings_sheet.dart';
import 'prepare_screen.dart';

class StartHomeScreen extends StatefulWidget {
  const StartHomeScreen({super.key});

  @override
  State<StartHomeScreen> createState() => _StartHomeScreenState();
}

class _StartHomeScreenState extends State<StartHomeScreen> with HelpPopupMixin {
  @override
  void initState() {
    super.initState();
    maybeShowHelp(
      'Start phone',
      'Place this phone at the starting line, then press SET.',
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            AppTopBar(
              onBack: () {
                Navigator.of(context).pushReplacement(
                  MaterialPageRoute(builder: (_) => const RoleSelectScreen()),
                );
              },
              onMenu: () => openSettings(context),
            ),
            const Spacer(flex: 3),
            const Text(
              'START',
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.w700,
                letterSpacing: 4,
                color: AppColors.black,
              ),
            ),
            const Spacer(flex: 3),
            Padding(
              padding: const EdgeInsets.fromLTRB(28, 0, 28, 36),
              child: SetButton(
                onPressed: () {
                  Navigator.of(context).push(
                    PageRouteBuilder(
                      pageBuilder: (_, __, ___) => const PrepareScreen(),
                      transitionsBuilder: (_, a, __, c) =>
                          FadeTransition(opacity: a, child: c),
                      transitionDuration: const Duration(milliseconds: 350),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
