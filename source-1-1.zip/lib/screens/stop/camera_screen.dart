import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:provider/provider.dart';

import '../../services/session_controller.dart';
import '../../theme/app_theme.dart';
import '../../widgets/glass.dart';
import '../../widgets/help_mixin.dart';
import '../role_select_screen.dart';
import '../settings_sheet.dart';
import 'frame_select_screen.dart';

class CameraScreen extends StatefulWidget {
  const CameraScreen({super.key});

  @override
  State<CameraScreen> createState() => _CameraScreenState();
}

class _CameraScreenState extends State<CameraScreen> with HelpPopupMixin {
  String? _error;
  bool _ready = false;
  bool _marking = false;

  @override
  void initState() {
    super.initState();
    maybeShowHelp(
      'Finish line',
      'Point the camera at the finish line. Press the check when the athlete crosses.',
    );
    WidgetsBinding.instance.addPostFrameCallback((_) => _init());
  }

  Future<void> _init() async {
    final cam = await Permission.camera.request();
    if (!cam.isGranted) {
      setState(() => _error = 'Camera permission required');
      return;
    }
    try {
      final session = context.read<SessionController>();
      await session.cameraBuffer.initialize();
      await session.cameraBuffer.startRollingBuffer();
      if (!mounted) return;
      setState(() => _ready = true);
    } catch (e) {
      setState(() => _error = 'Camera failed');
    }
  }

  Future<void> _onMark() async {
    if (_marking) return;
    setState(() => _marking = true);
    final session = context.read<SessionController>();
    await session.cameraBuffer.markAndFinalize(
      monoNow: () => session.clock.monotonicMicros,
    );
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => const FrameSelectScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    final session = context.watch<SessionController>();
    final controller = session.cameraBuffer.controller;

    return Scaffold(
      backgroundColor: AppColors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          if (_ready && controller != null && controller.value.isInitialized)
            CameraPreview(controller)
          else
            Center(
              child: Text(
                _error ?? '',
                style: const TextStyle(color: AppColors.white),
              ),
            ),
          Center(
            child: Container(
              width: 2,
              color: AppColors.white.withOpacity(0.9),
            ),
          ),
          SafeArea(
            child: AppTopBar(
              onBack: () {
                Navigator.of(context).pushReplacement(
                  MaterialPageRoute(builder: (_) => const RoleSelectScreen()),
                );
              },
              onMenu: () => openSettings(context),
            ),
          ),
          Positioned(
            bottom: MediaQuery.paddingOf(context).bottom + 36,
            left: 0,
            right: 0,
            child: Column(
              children: [
                if (_ready && !_marking) CheckButton(onPressed: _onMark),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
