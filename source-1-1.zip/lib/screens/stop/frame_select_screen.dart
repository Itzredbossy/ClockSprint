import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:video_player/video_player.dart';

import '../../services/session_controller.dart';
import '../../theme/app_theme.dart';
import '../../widgets/glass.dart';
import '../../widgets/help_mixin.dart';
import '../settings_sheet.dart';
import '../sync/sync_screen.dart';

class FrameSelectScreen extends StatefulWidget {
  const FrameSelectScreen({super.key});

  @override
  State<FrameSelectScreen> createState() => _FrameSelectScreenState();
}

class _FrameSelectScreenState extends State<FrameSelectScreen>
    with HelpPopupMixin {
  int _index = 0;
  VideoPlayerController? _video;
  bool _ready = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    maybeShowHelp(
      'Select frame',
      'Step frame by frame and confirm the moment the chest crosses the line.',
    );
    final session = context.read<SessionController>();
    final stamps = session.cameraBuffer.frameStamps;
    if (stamps.isNotEmpty) _index = stamps.length ~/ 2;
    WidgetsBinding.instance.addPostFrameCallback((_) => _initVideo());
  }

  Future<void> _initVideo() async {
    final path = context.read<SessionController>().cameraBuffer.finalizedPath;
    if (path == null || !File(path).existsSync()) {
      setState(() => _error = 'No clip available');
      return;
    }
    try {
      final c = VideoPlayerController.file(File(path));
      await c.initialize();
      await c.setLooping(false);
      await c.pause();
      _video = c;
      setState(() => _ready = true);
      await _seekToIndex(_index);
    } catch (e) {
      setState(() => _error = 'Could not open clip');
    }
  }

  Future<void> _seekToIndex(int index) async {
    final session = context.read<SessionController>();
    final stamps = session.cameraBuffer.frameStamps;
    final v = _video;
    if (v == null || !v.value.isInitialized) return;

    Duration target;
    if (stamps.isNotEmpty && index >= 0 && index < stamps.length) {
      target = Duration(
        microseconds: (stamps[index].relativeSeconds * 1e6).round(),
      );
    } else {
      final total = v.value.duration;
      final frames = _frameCount;
      final t = frames <= 1 ? 0.0 : index / (frames - 1);
      target = total * t;
    }
    if (target > v.value.duration) target = v.value.duration;
    await v.seekTo(target);
    await v.pause();
    if (mounted) setState(() {});
  }

  int get _frameCount {
    final stamps =
        context.read<SessionController>().cameraBuffer.frameStamps;
    if (stamps.isNotEmpty) return stamps.length;
    final v = _video;
    if (v == null || !v.value.isInitialized) return 1;
    final fps = context.read<SessionController>().cameraBuffer.reportedFps;
    final n = (v.value.duration.inMilliseconds / 1000.0 * fps).round();
    return n.clamp(1, 2000);
  }

  Future<void> _setIndex(int i) async {
    final max = _frameCount - 1;
    final next = i.clamp(0, max);
    setState(() => _index = next);
    await _seekToIndex(next);
  }

  @override
  void dispose() {
    _video?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final total = _frameCount;
    final maxIdx = (total - 1).clamp(0, 99999);

    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            AppTopBar(
              onBack: () => Navigator.of(context).maybePop(),
              onMenu: () => openSettings(context),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(28),
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      Container(color: AppColors.black),
                      if (_ready && _video != null)
                        FittedBox(
                          fit: BoxFit.cover,
                          child: SizedBox(
                            width: _video!.value.size.width,
                            height: _video!.value.size.height,
                            child: VideoPlayer(_video!),
                          ),
                        )
                      else
                        Center(
                          child: Text(
                            _error ?? 'Loading…',
                            style: const TextStyle(
                              color: AppColors.white,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                      // Finish-line guide
                      Center(
                        child: Container(
                          width: 2,
                          color: AppColors.white.withOpacity(0.9),
                        ),
                      ),
                      // Frame counter
                      Positioned(
                        left: 0,
                        right: 0,
                        bottom: 12,
                        child: Text(
                          '$_index / $maxIdx',
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            color: AppColors.white,
                            fontSize: 15,
                            fontWeight: FontWeight.w600,
                            shadows: [
                              Shadow(blurRadius: 8, color: Colors.black54),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 0, 24, 8),
              child: CupertinoSlider(
                value: _index.toDouble().clamp(0, maxIdx.toDouble()),
                min: 0,
                max: maxIdx < 1 ? 1 : maxIdx.toDouble(),
                divisions: maxIdx < 1 ? 1 : maxIdx,
                activeColor: AppColors.black,
                onChanged: (v) => _setIndex(v.round()),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Glass(
                  circle: true,
                  onTap: _index > 0 ? () => _setIndex(_index - 1) : null,
                  padding: const EdgeInsets.all(14),
                  child: const Icon(Icons.chevron_left_rounded, size: 28),
                ),
                const SizedBox(width: 28),
                Glass(
                  circle: true,
                  onTap:
                      _index < maxIdx ? () => _setIndex(_index + 1) : null,
                  padding: const EdgeInsets.all(14),
                  child: const Icon(Icons.chevron_right_rounded, size: 28),
                ),
              ],
            ),
            const SizedBox(height: 20),
            CheckButton(
              onPressed: () {
                final session = context.read<SessionController>();
                session.recordFinishFromFrame(_index);
                Navigator.of(context).pushReplacement(
                  MaterialPageRoute(builder: (_) => const SyncScreen()),
                );
              },
            ),
            const SizedBox(height: 28),
          ],
        ),
      ),
    );
  }
}
