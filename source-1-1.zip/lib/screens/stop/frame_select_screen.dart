import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../services/session_controller.dart';
import '../../theme/app_theme.dart';
import '../../widgets/glass.dart';
import '../../widgets/help_mixin.dart';
import '../settings_sheet.dart';
import '../sync/sync_screen.dart';

class FrameSelectScreen extends StatefulWidget {
  const FrameSelectScreen({super.key});

  @override
  State<FrameSelectScreen> createState() => _FrameSelectScreenState();
}

class _FrameSelectScreenState extends State<FrameSelectScreen>
    with HelpPopupMixin {
  int _index = 0;

  @override
  void initState() {
    super.initState();
    maybeShowHelp(
      'Select frame',
      'Step frame by frame and confirm the moment the chest crosses the line.',
    );
    final stamps = context.read<SessionController>().cameraBuffer.frameStamps;
    if (stamps.isNotEmpty) _index = stamps.length ~/ 2;
  }

  @override
  Widget build(BuildContext context) {
    final session = context.watch<SessionController>();
    final stamps = session.cameraBuffer.frameStamps;
    final total = stamps.isEmpty ? 1 : stamps.length;

    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            AppTopBar(
              onBack: () => Navigator.of(context).maybePop(),
              onMenu: () => openSettings(context),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Glass(
                  borderRadius: 18,
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      Container(color: AppColors.black.withOpacity(0.08)),
                      Center(
                        child: Text(
                          '$_index / ${total - 1}',
                          style: const TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.w600,
                            color: AppColors.black,
                          ),
                        ),
                      ),
                      Center(
                        child: Container(
                          width: 2,
                          color: AppColors.black.withOpacity(0.35),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 0, 24, 8),
              child: CupertinoSlider(
                value: _index.toDouble().clamp(0, (total - 1).toDouble()),
                min: 0,
                max: (total - 1).toDouble().clamp(1, double.infinity),
                activeColor: AppColors.black,
                onChanged: (v) => setState(() => _index = v.round()),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Glass(
                  circle: true,
                  onTap: _index > 0 ? () => setState(() => _index--) : null,
                  padding: const EdgeInsets.all(14),
                  child: const Icon(Icons.chevron_left_rounded, size: 28),
                ),
                const SizedBox(width: 28),
                Glass(
                  circle: true,
                  onTap: _index < total - 1
                      ? () => setState(() => _index++)
                      : null,
                  padding: const EdgeInsets.all(14),
                  child: const Icon(Icons.chevron_right_rounded, size: 28),
                ),
              ],
            ),
            const SizedBox(height: 20),
            CheckButton(
              onPressed: () {
                session.recordFinishFromFrame(_index);
                Navigator.of(context).pushReplacement(
                  MaterialPageRoute(builder: (_) => const SyncScreen()),
                );
              },
            ),
            const SizedBox(height: 28),
          ],
        ),
      ),
    );
  }
}
