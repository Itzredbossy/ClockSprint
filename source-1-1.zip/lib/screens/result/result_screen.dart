import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../services/session_controller.dart';
import '../../theme/app_theme.dart';
import '../../widgets/glass.dart';
import '../role_select_screen.dart';
import '../settings_sheet.dart';

class ResultScreen extends StatelessWidget {
  const ResultScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final session = context.watch<SessionController>();
    final result = session.result;

    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            AppTopBar(
              onBack: () {
                session.reset();
                Navigator.of(context).pushAndRemoveUntil(
                  MaterialPageRoute(builder: (_) => const RoleSelectScreen()),
                  (_) => false,
                );
              },
              onMenu: () => openSettings(context),
            ),
            const Spacer(flex: 2),
            const Text(
              '100 METERS',
              style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w600,
                letterSpacing: 3,
                color: AppColors.secondaryLabel,
              ),
            ),
            const SizedBox(height: 16),
            Text(
              result?.formattedTime ?? '—',
              style: const TextStyle(
                fontSize: 72,
                fontWeight: FontWeight.w300,
                letterSpacing: -2,
                height: 1,
                color: AppColors.black,
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'SECONDS',
              style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w600,
                letterSpacing: 2,
                color: AppColors.secondaryLabel,
              ),
            ),
            const Spacer(flex: 3),
            Padding(
              padding: const EdgeInsets.fromLTRB(28, 0, 28, 28),
              child: AppleButton(
                label: 'New measurement',
                onPressed: () {
                  session.reset();
                  Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(builder: (_) => const RoleSelectScreen()),
                    (_) => false,
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
