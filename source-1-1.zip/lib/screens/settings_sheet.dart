import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../services/session_controller.dart';
import '../services/settings_service.dart';
import '../widgets/glass.dart';

void openSettings(BuildContext context) {
  showModalBottomSheet(
    context: context,
    backgroundColor: Colors.transparent,
    isScrollControlled: true,
    useSafeArea: true,
    builder: (_) {
      final session = context.read<SessionController>();
      return ChangeNotifierProvider<SettingsService>.value(
        value: session.settings,
        child: const SettingsSheet(),
      );
    },
  );
}

class SettingsSheet extends StatelessWidget {
  const SettingsSheet({super.key});

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<SettingsService>();
    final theme = Theme.of(context);
    final colors = theme.colorScheme;
    final isDark = theme.brightness == Brightness.dark;

    return Container(
      margin: const EdgeInsets.fromLTRB(12, 0, 12, 12),
      decoration: BoxDecoration(
        color: colors.surface,
        borderRadius: BorderRadius.circular(28),
        border: Border.all(
          color: isDark ? Colors.white.withOpacity(.10) : Colors.white,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(isDark ? .35 : .13),
            blurRadius: 28,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: SafeArea(
        top: false,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(height: 10),
              Container(
                width: 36,
                height: 5,
                decoration: BoxDecoration(
                  color: colors.outline.withOpacity(.55),
                  borderRadius: BorderRadius.circular(3),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 17, 20, 11),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    'Settings',
                    style: TextStyle(
                      fontSize: 21,
                      fontWeight: FontWeight.w700,
                      letterSpacing: -.35,
                      color: colors.onSurface,
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 4, 20, 14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Appearance',
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w600,
                        color: colors.onSurface,
                      ),
                    ),
                    const SizedBox(height: 10),
                    SizedBox(
                      width: double.infinity,
                      child: CupertinoSegmentedControl<ThemeMode>(
                        groupValue: settings.themeMode,
                        onValueChanged: settings.setThemeMode,
                        selectedColor: colors.primary,
                        unselectedColor: isDark
                            ? const Color(0xFF2C2C2E)
                            : const Color(0xFFF0F0F5),
                        pressedColor: colors.primary.withOpacity(.17),
                        borderColor: colors.outline.withOpacity(.35),
                        children: {
                          ThemeMode.system: Padding(
                            padding: const EdgeInsets.symmetric(vertical: 9),
                            child: Text('System', style: TextStyle(
                              color: settings.themeMode == ThemeMode.system
                                  ? Colors.white
                                  : colors.onSurface,
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                            )),
                          ),
                          ThemeMode.light: Padding(
                            padding: const EdgeInsets.symmetric(vertical: 9),
                            child: Text('Light', style: TextStyle(
                              color: settings.themeMode == ThemeMode.light
                                  ? Colors.white
                                  : colors.onSurface,
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                            )),
                          ),
                          ThemeMode.dark: Padding(
                            padding: const EdgeInsets.symmetric(vertical: 9),
                            child: Text('Dark', style: TextStyle(
                              color: settings.themeMode == ThemeMode.dark
                                  ? Colors.white
                                  : colors.onSurface,
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                            )),
                          ),
                        },
                      ),
                    ),
                  ],
                ),
              ),
              Divider(height: 1, color: colors.outline.withOpacity(.35)),
              _row(
                context,
                'Help pop-ups',
                CupertinoSwitch(
                  value: settings.helpPopupsEnabled,
                  activeColor: colors.primary,
                  trackColor: isDark
                      ? const Color(0xFF48484A)
                      : const Color(0xFFE5E5EA),
                  onChanged: settings.setHelpPopups,
                ),
              ),
              _row(
                context,
                'Haptics',
                CupertinoSwitch(
                  value: settings.hapticsEnabled,
                  activeColor: colors.primary,
                  trackColor: isDark
                      ? const Color(0xFF48484A)
                      : const Color(0xFFE5E5EA),
                  onChanged: settings.setHaptics,
                ),
              ),
              const SizedBox(height: 10),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                child: AppleButton(
                  label: 'Done',
                  onPressed: () => Navigator.pop(context),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _row(BuildContext context, String label, Widget trailing) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 9),
      child: Row(
        children: [
          Expanded(
            child: Text(
              label,
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w500,
                color: Theme.of(context).colorScheme.onSurface,
              ),
            ),
          ),
          trailing,
        ],
      ),
    );
  }
}
