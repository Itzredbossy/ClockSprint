import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/device_role.dart';
import '../services/session_controller.dart';
import '../theme/app_theme.dart';
import '../widgets/glass.dart';
import '../widgets/help_mixin.dart';
import 'settings_sheet.dart';
import 'start/start_home_screen.dart';
import 'stop/camera_screen.dart';

class RoleSelectScreen extends StatefulWidget {
  const RoleSelectScreen({super.key});

  @override
  State<RoleSelectScreen> createState() => _RoleSelectScreenState();
}

class _RoleSelectScreenState extends State<RoleSelectScreen>
    with HelpPopupMixin {
  @override
  void initState() {
    super.initState();
    maybeShowHelp(
      'Device role',
      'Choose START PHONE for the starting line or STOP PHONE for the finish line.',
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            AppTopBar(
              onBack: () {},
              onMenu: () => openSettings(context),
            ),
            const Spacer(flex: 2),
            const Text(
              '100 m',
              style: TextStyle(
                fontSize: 40,
                fontWeight: FontWeight.w700,
                letterSpacing: -1,
                color: AppColors.black,
              ),
            ),
            const SizedBox(height: 6),
            const Text(
              'Sprint Timer',
              style: TextStyle(
                fontSize: 17,
                fontWeight: FontWeight.w500,
                color: AppColors.secondaryLabel,
              ),
            ),
            const Spacer(flex: 2),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Column(
                children: [
                  _RoleTile(
                    role: DeviceRole.start,
                    onTap: () => _pick(DeviceRole.start),
                  ),
                  const SizedBox(height: 12),
                  _RoleTile(
                    role: DeviceRole.stop,
                    onTap: () => _pick(DeviceRole.stop),
                  ),
                ],
              ),
            ),
            const Spacer(flex: 3),
          ],
        ),
      ),
    );
  }

  void _pick(DeviceRole role) {
    context.read<SessionController>().selectRole(role);
    final page =
        role == DeviceRole.start ? const StartHomeScreen() : const CameraScreen();
    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        pageBuilder: (_, __, ___) => page,
        transitionsBuilder: (_, a, __, c) => FadeTransition(opacity: a, child: c),
        transitionDuration: const Duration(milliseconds: 280),
      ),
    );
  }
}

class _RoleTile extends StatelessWidget {
  const _RoleTile({required this.role, required this.onTap});
  final DeviceRole role;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Glass(
      borderRadius: 18,
      onTap: onTap,
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 22),
      child: Row(
        children: [
          Expanded(
            child: Text(
              role.label,
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w700,
                letterSpacing: 0.6,
                color: AppColors.black,
              ),
            ),
          ),
          const Icon(Icons.chevron_right_rounded, color: AppColors.black),
        ],
      ),
    );
  }
}
