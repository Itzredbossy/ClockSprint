package com.sprinttimer.sprint_timer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
