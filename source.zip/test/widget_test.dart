import 'package:flutter_test/flutter_test.dart';
import 'package:sprint_timer/main.dart';

void main() {
  testWidgets('Role select shows START and STOP options', (tester) async {
    await tester.pumpWidget(const SprintTimerApp());
    expect(find.text('START PHONE'), findsOneWidget);
    expect(find.text('STOP PHONE'), findsOneWidget);
    expect(find.text('100 m'), findsOneWidget);
  });
}
