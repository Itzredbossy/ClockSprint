import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../services/session_controller.dart';
import '../../theme/app_theme.dart';
import '../../widgets/primary_button.dart';
import '../sync/sync_screen.dart';

class PrepareScreen extends StatefulWidget {
  const PrepareScreen({super.key});

  @override
  State<PrepareScreen> createState() => _PrepareScreenState();
}

class _PrepareScreenState extends State<PrepareScreen> {
  bool _armed = false;
  bool _fired = false;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _arm());
  }

  Future<void> _arm() async {
    if (_armed) return;
    _armed = true;
    final session = context.read<SessionController>();
    await session.startSignal.preload();
    if (!mounted) return;
    setState(() => _busy = true);
    await session.startSignal.armAndFire();
    await session.recordStartTimestamp();
    if (!mounted) return;
    setState(() {
      _fired = true;
      _busy = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(
            children: [
              const Spacer(flex: 3),
              AnimatedOpacity(
                opacity: _fired ? 0.35 : 1,
                duration: const Duration(milliseconds: 500),
                child: Text(
                  'ΕΤΟΙΜΑΣΟΥ',
                  style: Theme.of(context).textTheme.displaySmall?.copyWith(
                        fontWeight: FontWeight.w600,
                        letterSpacing: 1.5,
                        color: AppTheme.primary,
                      ),
                ),
              ),
              const SizedBox(height: 16),
              Text(
                _fired
                    ? 'Signal fired · start time locked'
                    : (_busy ? 'Hold steady…' : 'Preparing…'),
                style: const TextStyle(color: AppTheme.muted),
              ),
              const Spacer(flex: 3),
              if (_fired)
                CheckCircleButton(
                  onPressed: () {
                    Navigator.of(context).pushReplacement(
                      MaterialPageRoute(builder: (_) => const SyncScreen()),
                    );
                  },
                ),
              const SizedBox(height: 32),
            ],
          ),
        ),
      ),
    );
  }
}
