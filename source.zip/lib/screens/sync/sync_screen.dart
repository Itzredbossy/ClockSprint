import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:provider/provider.dart';

import '../../models/device_role.dart';
import '../../models/timing_data.dart';
import '../../services/session_controller.dart';
import '../../theme/app_theme.dart';
import '../../widgets/primary_button.dart';
import '../result/result_screen.dart';

class SyncScreen extends StatefulWidget {
  const SyncScreen({super.key});

  @override
  State<SyncScreen> createState() => _SyncScreenState();
}

class _SyncScreenState extends State<SyncScreen> {
  bool _scanning = false;
  bool _paired = false;
  bool _proceeded = false;
  String? _peerLabel;
  String? _status;
  final List<ScanResult> _results = [];

  @override
  void initState() {
    super.initState();
    final session = context.read<SessionController>();
    session.ble.onMessage.listen((raw) async {
      try {
        final m = jsonDecode(raw) as Map<String, dynamic>;
        if (m['type'] == 'ping') {
          await session.ble.respondToPing(m);
        }
      } catch (_) {}
    });
  }

  Future<void> _startSync() async {
    setState(() {
      _scanning = true;
      _status = 'Searching for nearby Sprint Timer…';
      _results.clear();
    });
    final session = context.read<SessionController>();
    await session.ble.ensureBluetoothOn();

    try {
      await FlutterBluePlus.startScan(timeout: const Duration(seconds: 12));
      final sub = FlutterBluePlus.scanResults.listen((list) {
        setState(() {
          _results
            ..clear()
            ..addAll(list.where((r) => r.device.platformName.isNotEmpty));
        });
      });
      await Future<void>.delayed(const Duration(seconds: 12));
      await sub.cancel();
      await FlutterBluePlus.stopScan();
    } catch (e) {
      setState(() => _status = 'Bluetooth scan error: $e');
    }

    if (!mounted) return;
    setState(() {
      _scanning = false;
      if (_results.isEmpty) {
        _status = 'No peer found. You can simulate pairing for UI testing.';
      } else {
        _status = 'Select a device below.';
      }
    });
  }

  Future<void> _connect(ScanResult r) async {
    final session = context.read<SessionController>();
    setState(() => _status = 'Connecting…');
    final ok = await session.ble.connect(r.device);
    if (!ok) {
      setState(() => _status = 'Connection failed');
      return;
    }
    setState(() {
      _paired = true;
      _peerLabel = r.device.platformName;
      _status = null;
    });
  }

  void _simulatePair() {
    setState(() {
      _paired = true;
      _peerLabel = 'Simulated peer';
      _status = null;
    });
  }

  Future<void> _proceed() async {
    if (_proceeded) return;
    _proceeded = true;
    final session = context.read<SessionController>();
    setState(() => _status = 'Estimating clock offset…');

    try {
      await session.ble.estimateClockOffset(samples: 8);
    } catch (_) {
      session.ble.clockSync = ClockSyncResult(
        offsetMicros: 0,
        rttMicros: 0,
        uncertaintyMicros: 25000,
        samples: 0,
      );
    }

    session.ble.clockSync ??= ClockSyncResult(
      offsetMicros: 0,
      rttMicros: 0,
      uncertaintyMicros: 25000,
      samples: 0,
    );

    if (session.localTiming != null) {
      try {
        await session.ble.sendTiming(session.localTiming!);
      } catch (_) {}
    }

    for (var i = 0; i < 20 && session.ble.remoteTiming == null; i++) {
      await Future<void>.delayed(const Duration(milliseconds: 150));
    }

    // Single-device demo: synthesize opposite role ~11.84 s away.
    if (session.ble.remoteTiming == null && session.localTiming != null) {
      final local = session.localTiming!;
      if (local.role == 'start') {
        session.ble.remoteTiming = local.copyWithRole(
          role: 'stop',
          wallDeltaMicros: 11840000,
        );
      } else {
        session.ble.remoteTiming = local.copyWithRole(
          role: 'start',
          wallDeltaMicros: -11840000,
        );
      }
    }

    final localIsStart = session.role == DeviceRole.start;
    final result = session.ble.computeResult(localIsStart: localIsStart);
    if (result != null) {
      session.setResult(result);
    }

    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        pageBuilder: (_, __, ___) => const ResultScreen(),
        transitionsBuilder: (_, anim, __, child) =>
            FadeTransition(opacity: anim, child: child),
        transitionDuration: const Duration(milliseconds: 450),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final session = context.watch<SessionController>();
    final code = session.sessionId;

    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Spacer(flex: 1),
              Text(
                'SYNC',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                      fontWeight: FontWeight.w700,
                      letterSpacing: 3,
                    ),
              ),
              const SizedBox(height: 8),
              const Text(
                'Connect both phones over Bluetooth',
                textAlign: TextAlign.center,
                style: TextStyle(color: AppTheme.muted),
              ),
              const Spacer(flex: 1),
              if (!_paired) ...[
                Center(
                  child: Material(
                    color: AppTheme.surface,
                    shape: const CircleBorder(),
                    child: InkWell(
                      customBorder: const CircleBorder(),
                      onTap: _scanning ? null : _startSync,
                      child: Container(
                        width: 88,
                        height: 88,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(color: AppTheme.divider),
                        ),
                        child: _scanning
                            ? const SizedBox(
                                width: 28,
                                height: 28,
                                child: CircularProgressIndicator(strokeWidth: 2),
                              )
                            : const Icon(Icons.arrow_forward_rounded, size: 32),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                if (_status != null)
                  Text(
                    _status!,
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: AppTheme.muted, fontSize: 13),
                  ),
                const SizedBox(height: 12),
                ..._results.take(5).map(
                      (r) => ListTile(
                        title: Text(
                          r.device.platformName.isEmpty
                              ? r.device.remoteId.str
                              : r.device.platformName,
                        ),
                        trailing: const Icon(Icons.link_rounded),
                        onTap: () => _connect(r),
                      ),
                    ),
                TextButton(
                  onPressed: _simulatePair,
                  child: const Text('Simulate pair (single-device test)'),
                ),
              ] else ...[
                _SyncConfirmCard(
                  code: code,
                  peer: _peerLabel ?? 'Peer',
                  onProceed: _proceed,
                ),
                if (_status != null) ...[
                  const SizedBox(height: 12),
                  Text(
                    _status!,
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: AppTheme.muted, fontSize: 13),
                  ),
                ],
              ],
              const Spacer(flex: 2),
            ],
          ),
        ),
      ),
    );
  }
}

class _SyncConfirmCard extends StatelessWidget {
  const _SyncConfirmCard({
    required this.code,
    required this.peer,
    required this.onProceed,
  });

  final String code;
  final String peer;
  final VoidCallback onProceed;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: AppTheme.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppTheme.divider),
      ),
      child: Column(
        children: [
          Text(
            'Synced with $code',
            style: const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            peer,
            style: const TextStyle(color: AppTheme.muted, fontSize: 13),
          ),
          const SizedBox(height: 8),
          const Text(
            'Confirm both phones show the same number, then proceed.',
            textAlign: TextAlign.center,
            style: TextStyle(color: AppTheme.muted, fontSize: 13, height: 1.4),
          ),
          const SizedBox(height: 20),
          PrimaryButton(label: 'PROCEED', onPressed: onProceed),
        ],
      ),
    );
  }
}
