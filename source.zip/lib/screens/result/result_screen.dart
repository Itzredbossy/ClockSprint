import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../services/session_controller.dart';
import '../../theme/app_theme.dart';
import '../../widgets/primary_button.dart';
import '../role_select_screen.dart';

class ResultScreen extends StatelessWidget {
  const ResultScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final session = context.watch<SessionController>();
    final result = session.result;

    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Spacer(flex: 2),
              Text(
                '100 METERS',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      letterSpacing: 3,
                      fontWeight: FontWeight.w600,
                      color: AppTheme.muted,
                    ),
              ),
              const SizedBox(height: 20),
              Text(
                result?.formattedTime ?? '—',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.displayLarge?.copyWith(
                      fontWeight: FontWeight.w300,
                      fontSize: 72,
                      letterSpacing: -2,
                      height: 1,
                    ),
              ),
              const SizedBox(height: 8),
              const Text(
                'SECONDS',
                textAlign: TextAlign.center,
                style: TextStyle(
                  letterSpacing: 2,
                  fontWeight: FontWeight.w600,
                  color: AppTheme.muted,
                ),
              ),
              if (result != null) ...[
                const SizedBox(height: 24),
                Text(
                  '±${(result.uncertaintySeconds * 1000).toStringAsFixed(0)} ms estimated uncertainty',
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 12,
                    color: AppTheme.muted,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  'Session ${result.sessionCode}',
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 12, color: AppTheme.muted),
                ),
              ],
              const Spacer(flex: 3),
              PrimaryButton(
                label: 'New measurement',
                onPressed: () {
                  session.reset();
                  Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(builder: (_) => const RoleSelectScreen()),
                    (_) => false,
                  );
                },
              ),
              const SizedBox(height: 12),
              PrimaryButton(
                label: 'Done',
                filled: false,
                onPressed: () {
                  session.reset();
                  Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(builder: (_) => const RoleSelectScreen()),
                    (_) => false,
                  );
                },
              ),
              const SizedBox(height: 16),
            ],
          ),
        ),
      ),
    );
  }
}
