import 'dart:io';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../services/session_controller.dart';
import '../../theme/app_theme.dart';
import '../../widgets/primary_button.dart';
import '../sync/sync_screen.dart';

class FrameSelectScreen extends StatefulWidget {
  const FrameSelectScreen({super.key});

  @override
  State<FrameSelectScreen> createState() => _FrameSelectScreenState();
}

class _FrameSelectScreenState extends State<FrameSelectScreen> {
  int _index = 0;

  @override
  void initState() {
    super.initState();
    final stamps = context.read<SessionController>().cameraBuffer.frameStamps;
    if (stamps.isNotEmpty) {
      // Start near the middle (user mark).
      _index = stamps.length ~/ 2;
    }
  }

  @override
  Widget build(BuildContext context) {
    final session = context.watch<SessionController>();
    final stamps = session.cameraBuffer.frameStamps;
    final path = session.cameraBuffer.finalizedPath;
    final total = stamps.isEmpty ? 1 : stamps.length;
    final fps = session.cameraBuffer.reportedFps;

    return Scaffold(
      backgroundColor: AppTheme.background,
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 12),
            Text(
              'Select finish frame',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
            ),
            const SizedBox(height: 4),
            Text(
              'Frame $_index / ${total - 1}  ·  ${fps.toStringAsFixed(0)} fps',
              style: const TextStyle(color: AppTheme.muted, fontSize: 13),
            ),
            const SizedBox(height: 16),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      Container(color: Colors.black),
                      if (path != null && File(path).existsSync())
                        // Video file preview placeholder: show path note.
                        // Frame-accurate scrubbing of arbitrary video needs
                        // a video player with seek; we expose index + stamps.
                        Center(
                          child: Padding(
                            padding: const EdgeInsets.all(24),
                            child: Text(
                              'Clip ready\n${path.split('/').last}\n\n'
                              'Use ◀ ▶ to step frames.\n'
                              'Confirm when the chest first\n'
                              'crosses the white line.',
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                color: Colors.white70,
                                height: 1.4,
                              ),
                            ),
                          ),
                        )
                      else
                        const Center(
                          child: Text(
                            'No clip — stamps still usable for timing demo',
                            style: TextStyle(color: Colors.white54),
                          ),
                        ),
                      Center(
                        child: Container(
                          width: 2,
                          color: Colors.white.withOpacity(0.9),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Column(
                children: [
                  Slider(
                    value: _index.toDouble().clamp(0, (total - 1).toDouble()),
                    min: 0,
                    max: (total - 1).toDouble().clamp(1, double.infinity),
                    divisions: total > 1 ? total - 1 : 1,
                    onChanged: (v) => setState(() => _index = v.round()),
                    activeColor: AppTheme.primary,
                    inactiveColor: AppTheme.divider,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      IconButton.filledTonal(
                        onPressed: _index > 0
                            ? () => setState(() => _index--)
                            : null,
                        icon: const Icon(Icons.chevron_left_rounded),
                        iconSize: 32,
                      ),
                      const SizedBox(width: 24),
                      IconButton.filledTonal(
                        onPressed: _index < total - 1
                            ? () => setState(() => _index++)
                            : null,
                        icon: const Icon(Icons.chevron_right_rounded),
                        iconSize: 32,
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  CheckCircleButton(
                    onPressed: () {
                      session.recordFinishFromFrame(_index);
                      Navigator.of(context).pushReplacement(
                        MaterialPageRoute(builder: (_) => const SyncScreen()),
                      );
                    },
                  ),
                  const SizedBox(height: 24),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
