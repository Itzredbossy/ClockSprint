import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:provider/provider.dart';

import '../../services/session_controller.dart';
import '../../theme/app_theme.dart';
import '../../widgets/primary_button.dart';
import 'frame_select_screen.dart';

class CameraScreen extends StatefulWidget {
  const CameraScreen({super.key});

  @override
  State<CameraScreen> createState() => _CameraScreenState();
}

class _CameraScreenState extends State<CameraScreen> {
  String? _error;
  bool _ready = false;
  bool _marking = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _init());
  }

  Future<void> _init() async {
    final cam = await Permission.camera.request();
    if (!cam.isGranted) {
      setState(() => _error = 'Camera permission is required.');
      return;
    }
    try {
      final session = context.read<SessionController>();
      await session.cameraBuffer.initialize();
      await session.cameraBuffer.startRollingBuffer();
      if (!mounted) return;
      setState(() => _ready = true);
    } catch (e) {
      setState(() => _error = 'Camera init failed: $e');
    }
  }

  Future<void> _onMark() async {
    if (_marking) return;
    setState(() => _marking = true);
    final session = context.read<SessionController>();
    await session.cameraBuffer.markAndFinalize(
      monoNow: () => session.clock.monotonicMicros,
    );
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => const FrameSelectScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    final session = context.watch<SessionController>();
    final controller = session.cameraBuffer.controller;

    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          if (_ready && controller != null && controller.value.isInitialized)
            CameraPreview(controller)
          else
            Center(
              child: Text(
                _error ?? 'Opening camera…',
                style: const TextStyle(color: Colors.white70),
                textAlign: TextAlign.center,
              ),
            ),
          // Finish-line reference
          Center(
            child: Container(
              width: 2,
              color: Colors.white.withOpacity(0.85),
            ),
          ),
          Positioned(
            top: MediaQuery.paddingOf(context).top + 16,
            left: 0,
            right: 0,
            child: const Text(
              'Align finish line · tap when chest crosses',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.white,
                fontSize: 13,
                fontWeight: FontWeight.w500,
                shadows: [Shadow(blurRadius: 8, color: Colors.black54)],
              ),
            ),
          ),
          Positioned(
            bottom: MediaQuery.paddingOf(context).bottom + 36,
            left: 0,
            right: 0,
            child: Column(
              children: [
                if (_marking)
                  const Text(
                    'Capturing +3 s…',
                    style: TextStyle(color: Colors.white70),
                  ),
                const SizedBox(height: 16),
                if (_ready && !_marking)
                  CheckCircleButton(onPressed: _onMark, size: 80),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
