import 'package:flutter/foundation.dart';

import '../models/device_role.dart';
import '../models/timing_data.dart';
import '../utils/precision_clock.dart';
import 'ble_sync_service.dart';
import 'camera_buffer_service.dart';
import 'start_signal_service.dart';

/// App-wide session state for one measurement cycle.
class SessionController extends ChangeNotifier {
  SessionController() {
    clock = PrecisionClock();
    startSignal = StartSignalService(clock: clock);
    cameraBuffer = CameraBufferService();
    ble = BleSyncService(clock: clock);
  }

  late final PrecisionClock clock;
  late final StartSignalService startSignal;
  late final CameraBufferService cameraBuffer;
  late final BleSyncService ble;

  DeviceRole? role;
  String sessionId = '';
  TimingData? localTiming;
  SprintResult? result;
  int? selectedFrameIndex;

  void selectRole(DeviceRole r) {
    role = r;
    sessionId = ble.generateSessionCode();
    notifyListeners();
  }

  Future<void> recordStartTimestamp() async {
    final mono = startSignal.startMonotonicMicros;
    final wall = startSignal.startWallMicros;
    if (mono == null || wall == null) return;
    localTiming = TimingData(
      role: 'start',
      sessionId: sessionId,
      monotonicMicros: mono,
      wallClockMicros: wall,
      uncertaintyMicros: 2000, // audio/torch scheduling uncertainty
    );
    notifyListeners();
  }

  void recordFinishFromFrame(int frameIndex) {
    selectedFrameIndex = frameIndex;
    final wall = cameraBuffer.captureWallMicrosForFrame(frameIndex);
    if (wall == null) return;
    localTiming = TimingData(
      role: 'stop',
      sessionId: sessionId,
      monotonicMicros: clock.monotonicMicros,
      wallClockMicros: wall,
      frameIndex: frameIndex,
      frameRate: cameraBuffer.reportedFps,
      uncertaintyMicros: (1e6 / (cameraBuffer.reportedFps * 2)).round(),
    );
    notifyListeners();
  }

  void setResult(SprintResult r) {
    result = r;
    notifyListeners();
  }

  void reset() {
    localTiming = null;
    result = null;
    selectedFrameIndex = null;
    sessionId = ble.generateSessionCode();
    notifyListeners();
  }

  @override
  void dispose() {
    startSignal.dispose();
    cameraBuffer.dispose();
    ble.dispose();
    super.dispose();
  }
}
