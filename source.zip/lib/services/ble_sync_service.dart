import 'dart:async';
import 'dart:convert';
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:uuid/uuid.dart';

import '../models/timing_data.dart';
import '../utils/precision_clock.dart';

/// BLE service UUID namespace for this app (custom 128-bit).
class BleUuids {
  static final Guid service = Guid('6e400001-b5a3-f393-e0a9-e50e24dcca9e');
  static final Guid syncChar = Guid('6e400002-b5a3-f393-e0a9-e50e24dcca9e');
  static final Guid dataChar = Guid('6e400003-b5a3-f393-e0a9-e50e24dcca9e');
}

/// Discovers a peer phone, exchanges a 4-digit session code, estimates clock
/// offset via multi-sample RTT, then exchanges TimingData payloads.
class BleSyncService {
  BleSyncService({PrecisionClock? clock}) : _clock = clock ?? PrecisionClock();

  final PrecisionClock _clock;
  final _uuid = const Uuid();

  String localSessionCode = '';
  String? peerName;
  TimingData? localTiming;
  TimingData? remoteTiming;
  ClockSyncResult? clockSync;

  BluetoothDevice? _device;
  BluetoothCharacteristic? _syncChar;
  BluetoothCharacteristic? _dataChar;
  StreamSubscription<List<int>>? _syncSub;
  StreamSubscription<List<int>>? _dataSub;

  final _peerFound = StreamController<String>.broadcast();
  Stream<String> get onPeerFound => _peerFound.stream;

  final _message = StreamController<String>.broadcast();
  Stream<String> get onMessage => _message.stream;

  /// Generate a shared-looking 4-digit code (both sides generate; user confirms match).
  String generateSessionCode() {
    localSessionCode = (1000 + Random.secure().nextInt(9000)).toString();
    return localSessionCode;
  }

  Future<bool> ensureBluetoothOn() async {
    try {
      final state = await FlutterBluePlus.adapterState.first;
      if (state != BluetoothAdapterState.on) {
        await FlutterBluePlus.turnOn();
      }
      return true;
    } catch (e) {
      debugPrint('BT on failed: $e');
      return false;
    }
  }

  /// Scan for peripherals advertising our service.
  Future<void> startScan() async {
    await ensureBluetoothOn();
    await FlutterBluePlus.startScan(
      withServices: [BleUuids.service],
      timeout: const Duration(seconds: 15),
    );

    FlutterBluePlus.scanResults.listen((results) {
      for (final r in results) {
        final name = r.device.platformName;
        if (name.isEmpty) continue;
        if (name.startsWith('SprintTimer')) {
          peerName = name;
          _peerFound.add(name);
        }
      }
    });
  }

  Future<void> stopScan() async {
    try {
      await FlutterBluePlus.stopScan();
    } catch (_) {}
  }

  /// Connect to a discovered device and discover characteristics.
  Future<bool> connect(BluetoothDevice device) async {
    try {
      await stopScan();
      _device = device;
      await device.connect(timeout: const Duration(seconds: 12));
      final services = await device.discoverServices();
      for (final s in services) {
        if (s.uuid == BleUuids.service) {
          for (final c in s.characteristics) {
            if (c.uuid == BleUuids.syncChar) _syncChar = c;
            if (c.uuid == BleUuids.dataChar) _dataChar = c;
          }
        }
      }
      if (_syncChar != null) {
        await _syncChar!.setNotifyValue(true);
        _syncSub = _syncChar!.onValueReceived.listen(_onSyncBytes);
      }
      if (_dataChar != null) {
        await _dataChar!.setNotifyValue(true);
        _dataSub = _dataChar!.onValueReceived.listen(_onDataBytes);
      }
      return true;
    } catch (e) {
      debugPrint('Connect failed: $e');
      return false;
    }
  }

  void _onSyncBytes(List<int> bytes) {
    try {
      final map = jsonDecode(utf8.decode(bytes)) as Map<String, dynamic>;
      _message.add(jsonEncode(map));
    } catch (e) {
      debugPrint('Sync parse error: $e');
    }
  }

  void _onDataBytes(List<int> bytes) {
    try {
      final map = jsonDecode(utf8.decode(bytes)) as Map<String, dynamic>;
      if (map['type'] == 'timing') {
        remoteTiming = TimingData.fromJson(map['payload'] as Map<String, dynamic>);
      }
      _message.add(jsonEncode(map));
    } catch (e) {
      debugPrint('Data parse error: $e');
    }
  }

  Future<void> writeSync(Map<String, dynamic> payload) async {
    final bytes = utf8.encode(jsonEncode(payload));
    await _syncChar?.write(bytes, withoutResponse: false);
  }

  Future<void> writeData(Map<String, dynamic> payload) async {
    final bytes = utf8.encode(jsonEncode(payload));
    await _dataChar?.write(bytes, withoutResponse: false);
  }

  /// Multi-sample NTP-style offset estimation over BLE.
  ///
  /// Each sample: local T1 → remote replies with its wall time T2/T3 → local T4.
  /// offset ≈ ((T2 - T1) + (T3 - T4)) / 2, rtt = (T4 - T1) - (T3 - T2).
  Future<ClockSyncResult> estimateClockOffset({int samples = 8}) async {
    final offsets = <int>[];
    final rtts = <int>[];

    for (var i = 0; i < samples; i++) {
      final t1 = _clock.wallClockMicros;
      final id = _uuid.v4();
      await writeSync({'type': 'ping', 'id': id, 't1': t1});

      // Wait for matching pong via message stream (with timeout).
      final completer = Completer<Map<String, dynamic>>();
      late StreamSubscription sub;
      sub = onMessage.listen((raw) {
        try {
          final m = jsonDecode(raw) as Map<String, dynamic>;
          if (m['type'] == 'pong' && m['id'] == id) {
            if (!completer.isCompleted) completer.complete(m);
          }
        } catch (_) {}
      });

      Map<String, dynamic>? pong;
      try {
        pong = await completer.future.timeout(const Duration(seconds: 2));
      } catch (_) {
        pong = null;
      }
      await sub.cancel();

      if (pong == null) continue;
      final t4 = _clock.wallClockMicros;
      final t2 = (pong['t2'] as num).toInt();
      final t3 = (pong['t3'] as num).toInt();
      final offset = ((t2 - t1) + (t3 - t4)) ~/ 2;
      final rtt = (t4 - t1) - (t3 - t2);
      offsets.add(offset);
      rtts.add(rtt);
      await Future<void>.delayed(const Duration(milliseconds: 40));
    }

    if (offsets.isEmpty) {
      clockSync = ClockSyncResult(
        offsetMicros: 0,
        rttMicros: 0,
        uncertaintyMicros: 50000,
        samples: 0,
      );
      return clockSync!;
    }

    offsets.sort();
    rtts.sort();
    final mid = offsets.length ~/ 2;
    final medianOffset = offsets[mid];
    final medianRtt = rtts[mid];
    final spread = offsets.last - offsets.first;

    clockSync = ClockSyncResult(
      offsetMicros: medianOffset,
      rttMicros: medianRtt,
      uncertaintyMicros: (spread ~/ 2).clamp(500, 200000) + medianRtt ~/ 2,
      samples: offsets.length,
    );
    return clockSync!;
  }

  /// Handle an incoming ping by writing a pong (call from UI layer on message).
  Future<void> respondToPing(Map<String, dynamic> ping) async {
    if (ping['type'] != 'ping') return;
    final t2 = _clock.wallClockMicros;
    final t3 = _clock.wallClockMicros;
    await writeSync({
      'type': 'pong',
      'id': ping['id'],
      't2': t2,
      't3': t3,
    });
  }

  Future<void> sendTiming(TimingData data) async {
    localTiming = data;
    await writeData({'type': 'timing', 'payload': data.toJson()});
  }

  /// Compute sprint time aligning remote timestamps onto local clock.
  SprintResult? computeResult({required bool localIsStart}) {
    final start = localIsStart ? localTiming : remoteTiming;
    final finish = localIsStart ? remoteTiming : localTiming;
    final sync = clockSync;
    if (start == null || finish == null || sync == null) return null;
    if (start.role != 'start' || finish.role != 'stop') return null;

    // Bring remote wall times onto the local timeline using estimated offset.
    // offset = remote_wall - local_wall  ⇒  local = remote - offset
    int align(TimingData t, bool isLocal) {
      if (isLocal) return t.wallClockMicros;
      return t.wallClockMicros - sync.offsetMicros;
    }

    final startAligned = align(start, localIsStart);
    final finishAligned = align(finish, !localIsStart);
    final deltaMicros = finishAligned - startAligned;
    final uncertainty =
        (sync.uncertaintyMicros + (start.uncertaintyMicros ?? 0) + (finish.uncertaintyMicros ?? 1000)) /
            1e6;

    return SprintResult(
      timeSeconds: deltaMicros / 1e6,
      uncertaintySeconds: uncertainty,
      sessionCode: start.sessionId,
      startWallMicros: startAligned,
      finishWallMicros: finishAligned,
      clockOffsetMicros: sync.offsetMicros,
    );
  }

  Future<void> disconnect() async {
    await _syncSub?.cancel();
    await _dataSub?.cancel();
    try {
      await _device?.disconnect();
    } catch (_) {}
    _device = null;
  }

  Future<void> dispose() async {
    await disconnect();
    await _peerFound.close();
    await _message.close();
  }
}
